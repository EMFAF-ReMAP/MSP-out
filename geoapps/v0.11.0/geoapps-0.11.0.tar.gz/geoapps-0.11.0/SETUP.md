# 🚀 Quick Setup Guide

## Production Setup (Linux Server)

```bash
# 1. Clone e entra nella directory
git clone https://github.com/CNR-ISMAR/geoapps.git && cd geoapps

# 2. Configura secrets (password database, API keys)
cp config/secrets.yaml.example secrets.yaml
nano secrets.yaml

# 3. Avvia (usa automaticamente i file .default committati)
docker-compose up -d
```

**Note:** I file `config.default.yaml` e `docker-compose.default.yml` sono già nel repository con valori production. Se vuoi personalizzarli, copiali come `config.yaml` e `docker-compose.yml`.

## Development Setup (Windows/Mac)

```bash
# 1. Clone
git clone https://github.com/CNR-ISMAR/geoapps.git && cd geoapps

# 2. Copia template development
cp config/config.development.yaml config.yaml
cp docker/docker-compose.local.yaml docker-compose.yml

# 3. Avvia
docker-compose up -d

# 4. Apri http://localhost:8503
```

## � Switch Environments

**Development → Production:**
```bash
cp config.default.yaml config.yaml
cp docker-compose.default.yml docker-compose.yml
docker-compose restart
```

**Production → Development:**
```bash
cp config/config.development.yaml config.yaml
cp docker/docker-compose.local.yaml docker-compose.yml
docker-compose restart
```

## 📚 Documentation

- **[Complete Guide](docs/README.md)** - Full documentation index
- **[Docker Setup](docs/DOCKER_SETUP.md)** - Docker details
- **[Config Guide](docs/CONFIG_GUIDE.md)** - Configuration system
