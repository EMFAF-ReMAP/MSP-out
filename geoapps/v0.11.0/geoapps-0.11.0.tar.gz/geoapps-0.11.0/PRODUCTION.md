# 🚀 Production Deployment Guide

## First Time Setup

```bash
# 1. Clone repository
git clone https://github.com/CNR-ISMAR/geoapps.git && cd geoapps

# 2. Configure secrets (database password, API keys)
cp config/secrets.yaml.example secrets.yaml
nano secrets.yaml  # Edit with your production values

# 3. Start services
docker-compose up -d
```

**That's it!** The repository includes `config.default.yaml` and `docker-compose.default.yml` with production values.

## Updating Production

```bash
# 1. Pull latest changes
git pull origin main

# 2. Restart services
docker-compose restart
```

## Custom Configuration (Optional)

To customize beyond defaults:

```bash
# Copy defaults as local files
cp config.default.yaml config.yaml
cp docker-compose.default.yml docker-compose.yml

# Edit and restart
nano config.yaml && docker-compose restart
```

## Troubleshooting

**App doesn't start:**
```bash
docker-compose logs -f
```

**Database connection failed:**
Check `secrets.yaml` has correct password.

**Reset to defaults:**
```bash
rm config.yaml docker-compose.yml && docker-compose restart
```

📚 **More:** [Complete Documentation](docs/README.md)
