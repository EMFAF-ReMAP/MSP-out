# 🚀 Deployment sul Server - Guida Aggiornamenti

## ✨ TL;DR - Aggiornare Password sul Server

```bash
# È semplicissimo ora!
git pull origin main
docker-compose restart
# ✅ FATTO! Le password si aggiornano automaticamente
```

---

## 📋 Come Funziona l'Auto-Update

### 🔄 Meccanismo Automatico

Quando l'app si avvia (o fa restart), `init_database()` viene chiamato e:

```python
for username, password, full_name, email, role in sample_users:
    if user_exists:
        # ✅ UPDATE: Aggiorna password esistenti
        UPDATE users SET password_hash = ?, full_name = ?, email = ?, role = ?
    else:
        # INSERT: Crea nuovi utenti
        INSERT INTO users (username, password_hash, full_name, email, role)
```

**Risultato:**
- 🔄 Password nel codice (`sample_users`) → sempre sincronizzate con DB
- ✅ Nessuno script manuale da eseguire
- 🚀 Deploy semplificato

---

## 🎯 Procedure di Deployment

### Scenario 1: Aggiornamento Password/Codice

```bash
# 1. Pull latest code
git pull origin main

# 2. Restart containers
docker-compose restart

# 3. Verifica log
docker-compose logs -f streamlit | grep "password"
```

**Cosa succede:**
- Container si riavvia
- `init_database()` viene chiamato
- Password aggiornate automaticamente da `sample_users`
- ✅ Pronto!

---

### Scenario 2: Fresh Deploy (nuovo server)

```bash
# 1. Clone repository
git clone https://github.com/CNR-ISMAR/geoapps.git
cd geoapps

# 2. Create storage directory
mkdir -p geoapps_storage

# 3. Start containers
docker-compose up -d

# 4. Check logs
docker-compose logs -f
```

**Cosa succede:**
- Database creato da zero
- Tutti gli utenti in `sample_users` vengono inseriti
- Password già corrette dal codice
- ✅ Pronto!

---

### Scenario 3: Rebuild Completo (problemi gravi)

```bash
# 1. Pull latest
git pull origin main

# 2. Stop and remove
docker-compose down

# 3. Optional: Remove volumes (⚠️ cancella tutti i dati!)
# rm -rf geoapps_storage/auth.db

# 4. Rebuild and start
docker-compose build --no-cache
docker-compose up -d

# 5. Check logs
docker-compose logs -f
```

---

## 📝 Checklist Deploy Password Update

### Pre-Deploy
- [ ] Verificato le nuove password in locale
- [ ] Testato login con admin, guest1, guest2
- [ ] Commit e push del codice
- [ ] Tag versione (opzionale): `git tag v1.1.0-password-update`

### Durante Deploy
- [ ] SSH sul server
- [ ] `git pull origin main`
- [ ] `docker-compose restart`
- [ ] Attendi 10-20 secondi per startup

### Post-Deploy
- [ ] Verifica app accessibile: `curl http://localhost:8501`
- [ ] Test login admin con nuova password
- [ ] Test login guest1 con nuova password
- [ ] Verifica log per errori: `docker-compose logs --tail=50`

---

## 🔍 Troubleshooting

### Problema: Password non aggiornate dopo restart

**Soluzione 1: Forza reinit**
```bash
docker-compose down
docker-compose up -d
```

**Soluzione 2: Script manuale**
```bash
docker-compose exec streamlit python scripts/update_passwords.py
docker-compose restart
```

**Soluzione 3: Verifica database**
```bash
# Controlla hash password nel DB
docker-compose exec streamlit sqlite3 geoapps_storage/auth.db \
  "SELECT username, substr(password_hash, 1, 20) FROM users WHERE username IN ('admin', 'guest1', 'guest2');"
```

---

### Problema: Container non si avvia dopo update

**Check 1: Errori nei log**
```bash
docker-compose logs streamlit
```

**Check 2: Syntax error nel codice**
```bash
# Testa localmente
python -m py_compile geoapps/auth/auth.py
```

**Check 3: Rollback temporaneo**
```bash
git log --oneline -5  # Vedi ultimi commit
git checkout HEAD~1   # Torna indietro di 1 commit
docker-compose restart
```

---

### Problema: Utenti non riescono a loggarsi

**Diagnostica:**
```bash
# 1. Verifica password hash nel database
docker-compose exec streamlit python -c "
from auth.auth import hash_password
print('Admin hash:', hash_password('Admin2025!'))
"

# 2. Compara con DB
docker-compose exec streamlit sqlite3 geoapps_storage/auth.db \
  "SELECT username, password_hash FROM users WHERE username = 'admin';"

# 3. Se diversi → forza update
docker-compose exec streamlit python scripts/update_passwords.py
```

---

## 🛡️ Sicurezza in Production

### Best Practices

1. **Non committare database con password reali**
   ```bash
   # In .gitignore
   geoapps_storage/auth.db
   ```

2. **Backup database prima di update**
   ```bash
   cp geoapps_storage/auth.db geoapps_storage/auth.db.backup.$(date +%Y%m%d)
   ```

3. **Usa password diverse per production**
   ```python
   # In production, considera:
   # - Variabili d'ambiente per password admin
   # - Vault service (HashiCorp Vault, AWS Secrets Manager)
   # - Password più complesse per admin
   ```

4. **Monitor login failures**
   ```bash
   # Aggiungi logging per tentativi falliti
   docker-compose logs | grep "Failed login"
   ```

---

## 📊 Monitoring Post-Deploy

### Check Salute Sistema

```bash
# 1. App risponde?
curl -I http://localhost:8501

# 2. Container running?
docker-compose ps

# 3. Database accessibile?
docker-compose exec streamlit sqlite3 geoapps_storage/auth.db "SELECT COUNT(*) FROM users;"

# 4. Sessioni attive?
docker-compose exec streamlit sqlite3 geoapps_storage/auth.db "SELECT COUNT(*) FROM user_sessions WHERE is_active = 1;"
```

### Log Monitoring

```bash
# Errori recenti
docker-compose logs --tail=100 | grep -i error

# Login activity
docker-compose logs --tail=100 | grep -i "login\|logout\|authenticated"

# Database operations
docker-compose logs --tail=100 | grep -i "database\|init_database"
```

---

## 🔄 Workflow Completo

### Workflow Ideale per Update Password

```mermaid
graph TD
    A[Modifica password in auth.py] --> B[Test locale]
    B --> C[Commit & Push]
    C --> D[SSH sul server]
    D --> E[git pull]
    E --> F[Backup DB opzionale]
    F --> G[docker-compose restart]
    G --> H[Verifica log startup]
    H --> I[Test login utenti]
    I --> J{Tutto OK?}
    J -->|Sì| K[✅ Deploy completo]
    J -->|No| L[Check logs]
    L --> M[Rollback se necessario]
```

### Comandi Sequenziali

```bash
# 1. Sviluppo locale
vim geoapps/auth/auth.py  # Modifica password
git add .
git commit -m "Update admin and guest passwords"
git push origin main

# 2. Deploy production
ssh user@server
cd /path/to/geoapps
git pull origin main
cp geoapps_storage/auth.db geoapps_storage/auth.db.backup  # Backup
docker-compose restart

# 3. Verifica
sleep 10
curl http://localhost:8501  # App risponde?
docker-compose logs --tail=20  # Check errori

# 4. Test manuale
# Apri browser → http://server:8501
# Login con: admin / Admin2025!
# ✅ Se funziona → Deploy OK!
```

---

## ⚡ Quick Reference

### Comandi Essenziali

```bash
# Update normale
git pull && docker-compose restart

# Update con rebuild
git pull && docker-compose down && docker-compose up -d

# Force password sync
docker-compose exec streamlit python scripts/update_passwords.py

# Verifica password hash
docker-compose exec streamlit python -c "from auth.auth import hash_password; print(hash_password('Admin2025!'))"

# Backup DB
cp geoapps_storage/auth.db geoapps_storage/auth.db.backup

# Ripristino backup
cp geoapps_storage/auth.db.backup geoapps_storage/auth.db
docker-compose restart

# Cancella DB e ricrea (⚠️ perde dati!)
rm geoapps_storage/auth.db
docker-compose restart
```

---

## 📞 Supporto

### Contatti in Caso di Problemi

1. **Check documentazione**: `docs/PASSWORD_UPDATE.md`
2. **Log dettagliati**: `docker-compose logs -f > debug.log`
3. **Rollback**: `git checkout <previous-commit>`
4. **Contatta team dev**: Invia log e descrizione errore

---

**✨ Con l'auto-update, il deploy è semplicissimo: `git pull` + `restart`!** 🚀
