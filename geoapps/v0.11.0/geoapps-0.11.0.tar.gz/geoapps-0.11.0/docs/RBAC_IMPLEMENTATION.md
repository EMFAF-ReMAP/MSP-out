# 🔐 RBAC Implementation Summary

## ✅ Completed Implementation

Sistema di Role-Based Access Control (RBAC) **completo** con ruoli memorizzati nel database.

---

## 🗄️ Database Schema

### Tabella `users` - Aggiornata

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    email TEXT,
    role TEXT DEFAULT 'guest',  -- ← NUOVO CAMPO
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Valori `role` Validi

- `admin` - Amministratore (tutti i permessi)
- `scientist` - Scienziato (view, download, upload, publish_request)
- `researcher` - Ricercatore (view, download, upload, publish_request)
- `analyst` - Analista (view, download, publish_request)
- `guest` - Ospite (view, download)
- `demo` - Demo (solo view, limite accessi simultanei)

---

## 📁 File Creati/Modificati

### ✅ Moduli Core

1. **`geoapps/auth/auth.py`**
   - Aggiunto campo `role` alla tabella users
   - Funzione `_ensure_role_column()` - migrazione automatica
   - Funzione `get_user_role_from_db()` - lettura role dal DB
   - Funzione `update_user_role()` - modifica role utente
   - Funzione `create_user()` - creazione utente con role
   - `authenticate_user()` - ora ritorna anche il role
   - `get_all_users()` - ora include il role

2. **`geoapps/auth/roles.py`**
   - `_get_role_from_database()` - fetch role dal DB (non più inferenza)
   - `get_current_user_role()` - usa il database
   - `get_user_role()` - usa il database
   - Tutti gli enum e permessi invariati

3. **`geoapps/auth/__init__.py`**
   - Esportate nuove funzioni: `get_user_role_from_db`, `update_user_role`, `create_user`

### ✅ Scripts

1. **`scripts/migrate_rbac.py`** ⭐ NUOVO
   - Script di migrazione per database esistenti
   - Idempotente (può essere eseguito multiple volte)

2. **`scripts/test_rbac.py`** ⭐ NUOVO
   - Test suite completa per RBAC
   - Verifica migrazione, autenticazione, permissions
   - Mostra matrix permessi

### ✅ Pagine Esempio

1. **`geoapps/pages/RBAC_Example.py`** ⭐ AGGIORNATO
   - Sezione admin con modifica ruoli utente
   - Mostra dataframe utenti con ruoli
   - Select box per modificare role
   - Tutti gli esempi di uso RBAC

### ✅ Documentazione

1. **`docs/RBAC_GUIDE.md`** ⭐ ESISTENTE
   - Guida completa RBAC (già creata prima)
   - Include sezione migrazione futura → ORA IMPLEMENTATA

---

## 🚀 Come Usare

### 1. Migrazione Database Esistente

Se hai già un database `auth.db` esistente:

```bash
# Dalla root del progetto
python scripts/migrate_rbac.py
```

Questo script:
- Aggiunge la colonna `role` se non esiste
- Popola i ruoli basandosi sui pattern username (admin, scientist*, ecc.)
- È idempotente (sicuro da eseguire multiple volte)

### 2. Verifica Funzionamento

```bash
python scripts/test_rbac.py
```

Output aspettato:
```
🚀 RBAC System Test Suite
═══════════════════════════════════════════════════════════════

🔧 Testing Database Migration
✅ Database initialized
👥 Found 15 users:
...

🔐 Testing Authentication with Roles
✅ admin: role=admin (expected: admin)
✅ scientist1: role=scientist (expected: scientist)
...

✅ All tests passed!
```

### 3. Usare RBAC nelle Pagine

#### Pattern 1: Check Permission UI

```python
from auth import has_permission, Permission

if has_permission(Permission.PUBLISH_DIRECT):
    st.button("🚀 Publish Now")
elif has_permission(Permission.PUBLISH_REQUEST):
    st.button("📨 Request Publication")
else:
    st.warning("No publishing permissions")
```

#### Pattern 2: Guard Function

```python
from auth import require_permission, Permission

# Blocca esecuzione se non ha permesso
require_permission(Permission.UPLOAD_DATA)

# Codice qui eseguito solo se ha permesso
uploaded_file = st.file_uploader("Upload")
```

#### Pattern 3: Admin Check

```python
from auth import is_admin

if is_admin():
    # Mostra pannello admin
    show_admin_tools()
```

#### Pattern 4: Get Current Role

```python
from auth import get_current_user_role, UserRole

role = get_current_user_role()

if role == UserRole.SCIENTIST:
    # Logica specifica per scientist
    pass
```

### 4. Modificare Ruoli (Admin)

Due modi:

**A. Via pagina RBAC_Example:**
1. Loggati come admin
2. Vai su `http://localhost:8503/RBAC_Example`
3. Sezione "⚙️ Administration"
4. Seleziona utente e nuovo ruolo
5. Click "💾 Update"

**B. Via script Python:**

```python
from auth import update_user_role

# Promuovi un utente ad admin
update_user_role("scientist1", "admin")

# Declassa un utente a guest
update_user_role("user123", "guest")
```

### 5. Creare Nuovi Utenti con Role

```python
from auth import create_user

create_user(
    username="newuser",
    password="secure_password",
    full_name="New User",
    email="newuser@example.com",
    role="scientist"  # Specifica ruolo direttamente
)
```

---

## 🔑 Permessi per Ruolo

| Permission | Admin | Scientist | Researcher | Analyst | Guest | Demo |
|-----------|:-----:|:---------:|:----------:|:-------:|:-----:|:----:|
| VIEW_DATA | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| DOWNLOAD_DATA | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ |
| UPLOAD_DATA | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| DELETE_DATA | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| PUBLISH_DIRECT | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| PUBLISH_REQUEST | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| MANAGE_USERS | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| VIEW_LOGS | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| SYSTEM_CONFIG | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

---

## 🎯 Esempio Pratico: Pubblicazione Dataset

```python
import streamlit as st
from auth import (
    require_app_login,
    has_permission,
    Permission
)

st.set_page_config(page_title="Data Publishing", layout="wide")

# Guard: richiede login
require_app_login()

st.title("📤 Data Publishing")

# Form upload
uploaded_file = st.file_uploader("Choose dataset")

if uploaded_file:
    # Process file...
    st.success("File processed!")
    
    # Sezione pubblicazione DIFFERENZIATA per ruolo
    st.subheader("Publish Options")
    
    # ADMIN: Pubblicazione diretta
    if has_permission(Permission.PUBLISH_DIRECT):
        st.success("✅ You have ADMIN rights - Direct publishing")
        
        if st.button("🚀 Publish Now", type="primary"):
            publish_to_portal(uploaded_file)
            st.success("✅ Dataset published successfully!")
            send_notification_to_users()
    
    # SCIENTIST/RESEARCHER/ANALYST: Richiesta pubblicazione
    elif has_permission(Permission.PUBLISH_REQUEST):
        st.info("📋 You can request publication approval from admin")
        
        reason = st.text_area("Reason for publishing")
        
        if st.button("📨 Request Publication", type="primary"):
            request_id = send_publish_request(uploaded_file, reason)
            st.success(f"✅ Request #{request_id} sent to admin")
            st.info("You will be notified when approved")
    
    # GUEST/DEMO: Nessun permesso
    else:
        st.warning("🚫 You don't have publishing permissions")
        st.info("Contact administrator to request access")
        
        # Ma possono scaricare il risultato se hanno il permesso
        if has_permission(Permission.DOWNLOAD_DATA):
            csv = process_data_to_csv(uploaded_file)
            st.download_button(
                label="⬇️ Download Processed Data",
                data=csv,
                file_name="processed_data.csv"
            )
```

---

## 🔄 Migrazione da Vecchio Sistema

Se avevi implementato l'inferenza da username:

1. **Nessuna modifica necessaria al codice applicazione**
   - Le funzioni `get_user_role()`, `has_permission()` ecc. hanno stessa interfaccia
   - Ora leggono dal DB invece di inferire

2. **Database esistenti vengono migrati automaticamente**
   - `init_database()` chiama `_ensure_role_column()`
   - Popola ruoli da pattern username

3. **Test che tutto funziona**
   ```bash
   python scripts/test_rbac.py
   ```

---

## 📊 Testing

### Test Automatici

```bash
# Test completo RBAC
python scripts/test_rbac.py

# Output:
# ✅ Database migration
# ✅ Authentication with roles
# ✅ Role lookup
# ✅ Permissions matrix
# ✅ Role-specific features
```

### Test Manuali

1. **Login con diversi ruoli:**
   - admin / Admin2025!
   - scientist1 / password123
   - guest1 / Guest@CNR1
   - demo / demo

2. **Verifica comportamenti:**
   - Admin vede tutte le opzioni
   - Scientist vede "Request Publication"
   - Guest non vede opzioni pubblicazione
   - Demo non può scaricare

3. **Test modifica ruoli:**
   - Login come admin
   - Vai a RBAC_Example
   - Cambia ruolo di un utente
   - Logout e login come quell'utente
   - Verifica nuovi permessi

---

## 🐛 Troubleshooting

### Problema: "role column not found"

**Soluzione:**
```bash
python scripts/migrate_rbac.py
```

### Problema: Utente ha role None/null

**Soluzione:**
```python
from auth import update_user_role
update_user_role("username", "guest")  # o altro ruolo appropriato
```

### Problema: Vecchi utenti senza role

**Soluzione:** La migrazione popola automaticamente:
- Pattern username → role
- Fallback a "guest" se non matcha

### Verifica manuale DB:

```bash
sqlite3 geoapps_storage/auth.db
```

```sql
-- Mostra tutti gli utenti con ruoli
SELECT username, role FROM users;

-- Aggiorna manualmente un ruolo
UPDATE users SET role = 'admin' WHERE username = 'myuser';
```

---

## ✨ Feature Complete

- ✅ Campo `role` nel database
- ✅ Migrazione automatica database esistenti
- ✅ Creazione utenti con ruolo
- ✅ Modifica ruoli via codice
- ✅ Modifica ruoli via UI (admin panel)
- ✅ Autenticazione include ruolo
- ✅ Lookup ruolo dal DB
- ✅ Sistema permessi completo
- ✅ Test suite completa
- ✅ Documentazione completa
- ✅ Esempio pratico pubblicazione differenziata

---

## 🎉 Ready to Use!

Il sistema RBAC è **production-ready**:

1. ✅ Database con campo `role`
2. ✅ Migrazione automatica
3. ✅ API completa per gestione ruoli
4. ✅ UI admin per modifica ruoli
5. ✅ Pattern d'uso documentati
6. ✅ Test automatici
7. ✅ Esempio pratico funzionante

**Prossimi passi:**
1. Esegui migrazione: `python scripts/migrate_rbac.py`
2. Testa: `python scripts/test_rbac.py`
3. Avvia app: `docker-compose up -d`
4. Testa esempio: `http://localhost:8503/RBAC_Example`
5. Implementa logica differenziata nelle tue pagine!
