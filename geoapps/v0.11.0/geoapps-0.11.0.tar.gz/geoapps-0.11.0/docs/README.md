# 📚 Documentation Index

Complete documentation for GeoApps platform.

## 🚀 Getting Started

| Document | Description |
|----------|-------------|
| **[SETUP.md](../SETUP.md)** | Quick setup guide |
| **[PRODUCTION.md](../PRODUCTION.md)** | Production deployment |
| **[DEV_SETUP.md](DEV_SETUP.md)** | Development environment setup |

## ⚙️ Configuration

| Document | Description |
|----------|-------------|
| **[CONFIG_GUIDE.md](CONFIG_GUIDE.md)** | Configuration system guide |
| **[CONFIGURATION.md](CONFIGURATION.md)** | Technical ConfigManager docs |
| **[config/README.md](../config/README.md)** | Config templates |
| **[docker/README.md](../docker/README.md)** | Docker templates |

## 🐳 Docker

| Document | Description |
|----------|-------------|
| **[DOCKER_SETUP.md](DOCKER_SETUP.md)** | Complete Docker guide |

## 📁 Project Structure

```
geoapps/
├── config.default.yaml          # Production defaults (committed)
├── docker-compose.default.yml   # Production Docker (committed)
│
├── config/                      # Configuration templates
├── docker/                      # Docker Compose templates
├── docs/                        # Documentation (you are here)
│
├── config.yaml                  # Active config (local, not committed)
├── docker-compose.yml           # Active Docker (local, not committed)
└── secrets.yaml                 # Secrets (local, not committed)
```

## 🔧 Quick Commands

**Development:**
```bash
cp config/config.development.yaml config.yaml
cp docker/docker-compose.local.yaml docker-compose.yml
docker-compose up -d
```

**Production:**
```bash
# Uses committed defaults automatically
docker-compose up -d
```

## 📝 Notes

- Files with `.default` suffix are production-ready defaults
- Templates in `config/` and `docker/` are environment-specific
- Local `config.yaml`, `docker-compose.yml`, `secrets.yaml` are NOT committed
