# 📋 Sistema di Configurazione - Guida Completa

## 🎯 Filosofia del Sistema

**Semplice e Chiaro**: 
- Template di riferimento in `config/` (committati su Git)
- Config attivo `config.yaml` nella root (locale, non committato)
- Secrets in `secrets.yaml` nella root (locale, non committato)

## 📁 Struttura File

```
geoapps/
├── config/                              # 📚 Template di riferimento
│   ├── README.md                        # Guida ai template
│   ├── config.development.yaml          # Template per Windows/Mac
│   ├── config.production.yaml           # Template per Linux server
│   └── secrets.yaml.example             # Template per secrets
│
├── config.yaml                          # ⚙️ Config ATTIVO (locale, non committato)
├── secrets.yaml                         # 🔒 Secrets (locale, non committato)
│
├── geoapps/
│   └── core/
│       ├── config.py                    # ConfigManager (legge config.yaml)
│       └── defaults.py                  # Valori di fallback hardcoded
│
└── docker-compose-local.yml             # Dev: GEOAPPS_ENV=development
```

## 🚀 Setup Iniziale

### Prima volta - Development

```powershell
# 1. Copia il template development
Copy-Item config\config.development.yaml config.yaml

# 2. (Opzionale) Crea secrets.yaml
Copy-Item config\secrets.yaml.example secrets.yaml
notepad secrets.yaml  # Inserisci password reali

# 3. Avvia Docker
docker-compose -f docker-compose-local.yml up
```

### Prima volta - Production

```bash
# 1. Copia il template production
cp config/config.production.yaml config.yaml

# 2. Crea secrets.yaml con credenziali reali
cp config/secrets.yaml.example secrets.yaml
nano secrets.yaml  # Inserisci password production

# 3. Avvia Docker
docker-compose up -d
```

## 📝 File di Configurazione

### 1. Template in `config/` (committati)

#### `config/config.development.yaml`
- Template per sviluppo locale (Windows/Mac)
- Host: `host.docker.internal:5436`
- Debug abilitato, log verbose
- NON modificare questo file per config personali

#### `config/config.production.yaml`
- Template per server production (Linux)
- Host: `172.17.0.1:5432`
- Debug disabilitato, ottimizzato
- NON modificare questo file per config personali

#### `config/secrets.yaml.example`
- Template per secrets
- Mostra la struttura richiesta
- Copia come `secrets.yaml` e inserisci valori reali

### 2. Config Attivo: `config.yaml` (NON committato)

**Dove**: Nella root del progetto

**Come crearlo**:
```powershell
# Copia uno dei template
Copy-Item config\config.development.yaml config.yaml
```

**Puoi modificarlo** per:
- Cambiare host/porta database
- Modificare percorsi locali
- Abilitare/disabilitare features
- Aggiustamenti specifici per la tua macchina

**È nel .gitignore**: ✅ Sì, è specifico per ogni sviluppatore/server

### 3. Secrets: `secrets.yaml` (NON committato)

**Dove**: Nella root del progetto

**Come crearlo**:
```powershell
Copy-Item config\secrets.yaml.example secrets.yaml
```

**Contiene**:
```yaml
database:
  password: "tua-password-reale"

security:
  secret_key: "chiave-segreta-min-32-caratteri"

api:
  key: "tua-api-key"
```

**È nel .gitignore**: ✅ Sì, MAI committare secrets!

### 4. Defaults: `geoapps/core/defaults.py` (committato)

**Scopo**: Valori di fallback hardcoded

**Quando usati**:
- Se `config.yaml` non esiste
- Per valori non specificati in `config.yaml`
- Come ultima risorsa

**Chi modifica**: Solo per cambiare default globali del progetto

## 🔄 Priorità di Caricamento

```
1️⃣ config.yaml (se esiste)
    ↓
2️⃣ secrets.yaml (merge per password/keys)
    ↓
3️⃣ defaults.py (fallback per valori mancanti)
```

### Esempio Pratico

```yaml
# config.yaml
database:
  host: "host.docker.internal"
  port: 5436
  # username non specificato → usa defaults.py
  # password non specificata → usa secrets.yaml

# secrets.yaml
database:
  password: "my_secret_pass"

# defaults.py
DATABASE_USERNAME = "remap"  # ← Usato se manca in config.yaml
```

**Risultato finale**:
- host: `host.docker.internal` (da config.yaml)
- port: `5436` (da config.yaml)
- username: `remap` (da defaults.py)
- password: `my_secret_pass` (da secrets.yaml)

## 🔧 Operazioni Comuni

### Cambiare Ambiente

**Da Development a Production**:
```bash
# Backup della tua config development
cp config.yaml config.yaml.dev

# Usa template production
cp config/config.production.yaml config.yaml

# Aggiorna secrets per production
nano secrets.yaml
```

**Tornare a Development**:
```bash
# Ripristina backup
cp config.yaml.dev config.yaml
```

### Aggiungere Nuovo Template

Se vuoi creare un template per "staging":

```bash
# 1. Copia un template esistente
cp config/config.production.yaml config/config.staging.yaml

# 2. Modifica per staging
nano config/config.staging.yaml

# 3. Aggiorna config/README.md
# 4. Committa il nuovo template
git add config/config.staging.yaml
git commit -m "Add staging config template"
```

### Debug Configurazione

Per vedere quale config viene caricata:

```powershell
# Guarda i log del container
docker-compose -f docker-compose-local.yml logs geoapps | Select-String "ConfigManager"
```

Output atteso:
```
🔧 [ConfigManager] Environment: development
✅ [ConfigManager] Loaded config.yaml successfully
```

## ✅ Vantaggi di Questo Sistema

| Vantaggio | Descrizione |
|-----------|-------------|
| **Semplicità** | Un solo file attivo (`config.yaml`) |
| **Chiarezza** | Template separati per riferimento |
| **Sicurezza** | Secrets mai committati |
| **Flessibilità** | Ogni dev/server ha la sua config |
| **Manutenibilità** | Template centralizzati e versionati |

## ❌ Cosa NON Fare

❌ **NON committare** `config.yaml` o `secrets.yaml`
❌ **NON modificare** i template in `config/` per config personali
❌ **NON mettere** secrets nei template
❌ **NON usare** variabili d'ambiente per DATABASE_URL (usa config.yaml)

## ✅ Cosa Fare

✅ **Usa** i template come base
✅ **Modifica** `config.yaml` per le tue esigenze
✅ **Crea** `secrets.yaml` per password reali
✅ **Committa** modifiche ai template se migliorano il progetto
✅ **Documenta** nuovi parametri nei template

## 🆘 Troubleshooting

### "Config file not found"

**Problema**: `config.yaml` non esiste

**Soluzione**:
```powershell
Copy-Item config\config.development.yaml config.yaml
```

### "Database connection failed"

**Problema**: Host/porta sbagliati

**Soluzione**:
1. Verifica `config.yaml`:
   ```yaml
   database:
     host: "host.docker.internal"  # Windows/Mac
     port: 5436
   ```

2. Verifica che PostgreSQL sia in ascolto sulla porta corretta

### "Missing password"

**Problema**: Password non configurata

**Soluzione**:
1. Crea `secrets.yaml`:
   ```powershell
   Copy-Item config\secrets.yaml.example secrets.yaml
   ```

2. Inserisci password reale:
   ```yaml
   database:
     password: "tua-password"
   ```

## 📚 Documentazione Correlata

- [SETUP.md](../SETUP.md) - Quick start
- [docs/DEV_SETUP.md](../docs/DEV_SETUP.md) - Setup sviluppo
- [docs/CONFIGURATION.md](../docs/CONFIGURATION.md) - Dettagli tecnici ConfigManager
- [config/README.md](README.md) - Guida ai template
