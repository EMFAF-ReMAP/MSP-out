# GeoApps — CNR-ISMAR Multi-Application Platform

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.x-red.svg)](https://streamlit.io/)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue.svg)](https://www.docker.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

Piattaforma multi-applicazione per analisi geospaziali e gestione dati marittimi, sviluppata da **CNR-ISMAR** (Consiglio Nazionale delle Ricerche - Istituto di Scienze Marine).

---

## 📱 Applicazioni

### 🗺️ CKAN Explorer
Interfaccia avanzata per filtrare, visualizzare e analizzare dataset CKAN con:
- Filtri spaziali per domain area
- Filtri per cluster/class/subclass
- Visualizzazione interattiva su mappa GIS
- Export e analisi dati

### 📊 ReMAP MSP out
Strumento di analisi per Maritime Spatial Planning:
- Analisi output pianificazione marittima
- Visualizzazione sankey diagrams
- Statistiche e metriche di copertura

### 🌊 ReMAP MSP & MSFD
Integrazione tra Maritime Spatial Planning e Marine Strategy Framework Directive:
- Analisi comparative MSP/MSFD
- Identificazione zone di sovrapposizione
- Report di conformità

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- PostgreSQL database (accessibile)
- Git

### Development (Windows/Mac)

```bash
# 1. Clone repository
git clone https://github.com/CNR-ISMAR/geoapps.git
cd geoapps

# 2. Setup configurazione
cp config/config.development.yaml config.yaml

# 3. Setup Docker Compose
cp docker/docker-compose.local.yaml docker-compose.yml

# 4. (Opzionale) Setup secrets
cp config/secrets.yaml.example secrets.yaml
# Modifica secrets.yaml con le tue credenziali

# 5. Avvia l'applicazione
docker-compose up -d

# 6. Apri il browser
# http://localhost:8503
```

### Production (Linux)

```bash
# 1. Clone repository
git clone https://github.com/CNR-ISMAR/geoapps.git
cd geoapps

# 2. Setup file di configurazione (OPZIONALE - già presenti come default)
# I file config.default.yaml e docker-compose.default.yml sono già pronti
# Se vuoi personalizzare:
cp config.default.yaml config.yaml
cp docker-compose.default.yml docker-compose.yml

# 3. Setup secrets per produzione
cp config/secrets.yaml.example secrets.yaml
nano secrets.yaml  # Configura per produzione

# 5. Avvia in background
docker-compose up -d

# 6. L'app sarà disponibile su:
# https://geoapps.tools4msp.eu
```

---

## 📚 Documentazione

Tutta la documentazione è organizzata nella cartella [`docs/`](docs/):

| Documento | Descrizione |
|-----------|-------------|
| **[📖 docs/README.md](docs/README.md)** | **Indice completo documentazione** |
| [🚀 DEV_SETUP.md](docs/DEV_SETUP.md) | Setup ambiente development Windows/Mac |
| [🐳 DOCKER_SETUP.md](docs/DOCKER_SETUP.md) | Guida Docker completa |
| [📋 CONFIG_FILES_EXPLAINED.md](docs/CONFIG_FILES_EXPLAINED.md) | Spiegazione file di configurazione |
| [⚙️ CONFIGURATION.md](docs/CONFIGURATION.md) | Sistema configurazione centralizzato |

**➡️ Inizia da qui: [docs/README.md](docs/README.md)**

---

## 🏗️ Architettura

```
geoapps/
├── geoapps/                    # Codice sorgente applicazione
│   ├── streamlit_app_demo.py  # Entry point principale
│   ├── auth/                   # Sistema autenticazione
│   ├── core/                   # Moduli core (config, datasets, etc.)
│   ├── database/               # Connessione database e query
│   ├── pages/                  # Pagine Streamlit
│   └── tools/                  # Utility e helper functions
├── geoapps_storage/            # Storage dati (Parquet, JSON, static files)
├── docs/                       # 📚 Documentazione completa
├── scripts/                    # Script utility
├── config.yaml                 # Configurazione applicazione
├── secrets.yaml               # Secrets (NON committato)
├── docker-compose.yml         # Production deployment
└── docker-compose-local.yml   # Development local
```

---

## ⚙️ Tecnologie

- **Frontend**: Streamlit 1.x
- **Backend**: Python 3.11
- **Database**: PostgreSQL + PostGIS, SQLite (auth)
- **Data Processing**: Pandas, GeoPandas, Plotly
- **Deployment**: Docker, Docker Compose
- **Web Server**: Nginx (static files), Traefik (reverse proxy)

---

## 🔐 Autenticazione

Il sistema supporta due modalità di accesso:

### 1. Demo Slots (Accesso Temporaneo)
- Login anonimo con slot temporanei
- Gestione coda se tutti gli slot sono occupati
- Timeout automatico dopo inattività

### 2. Login con Credenziali
- Autenticazione utente/password
- Persistent login con cookie crittografati
- Gestione sessioni multiutente

---

## 🔧 Configurazione

### File Principali

| File | Scopo | Git |
|------|-------|-----|
| `config.yaml` | Configurazione per environment | ✅ Committato |
| `secrets.yaml` | Password, API keys | ❌ NON committato |
| `core/defaults.py` | Default produzione Linux | ✅ Committato |

### Variabili d'Ambiente

**Development (docker-compose-local.yml)**:
```yaml
environment:
  - GEOAPPS_ENV=development
  - DATABASE_URL=postgresql://user:pass@host.docker.internal:5436/db
```

**Production (docker-compose.yml)**:
```yaml
# Nessuna variabile necessaria
# Usa automaticamente defaults.py per Linux
```

📖 **Dettagli completi**: [docs/CONFIG_FILES_EXPLAINED.md](docs/CONFIG_FILES_EXPLAINED.md)

---

## 🧪 Testing

```bash
# Test configurazione database
docker-compose -f docker-compose-local.yml run --rm streamlit python -c "
from geoapps.database.dbconn import DATABASE_URL
print('Database URL:', DATABASE_URL)
"

# Test import moduli
docker-compose -f docker-compose-local.yml run --rm streamlit python -c "
from geoapps.core import config
print('Environment:', config.config.environment)
"
```

---

## 🐛 Troubleshooting

### Errore connessione database

**Windows/Mac**:
```bash
# Verifica che DATABASE_URL sia configurato
docker-compose -f docker-compose-local.yml config | grep DATABASE_URL
```

**Linux**:
```bash
# Verifica che PostgreSQL sia accessibile
docker exec geoapps-streamlit-1 ping -c 1 172.17.0.1
```

### Config non viene caricato

```bash
# Verifica presenza config.yaml nel container
docker-compose -f docker-compose-local.yml exec streamlit ls -la /var/geoapps/config.yaml

# Controlla i log
docker-compose logs streamlit
```

📖 **Guida completa troubleshooting**: [docs/README.md#troubleshooting](docs/README.md#troubleshooting)

---

## 📦 Deployment

### Development
```bash
docker-compose -f docker-compose-local.yml up
```
- Porta: `http://localhost:8503`
- Hot reload: ✅ Abilitato
- Debug mode: ✅ Attivo

### Production
```bash
docker-compose up -d
```
- URL: `https://geoapps.tools4msp.eu`
- SSL: ✅ Let's Encrypt (Traefik)
- Hot reload: ❌ Disabilitato

📖 **Guida deployment completa**: [docs/DOCKER_SETUP.md](docs/DOCKER_SETUP.md)

---

## 🤝 Contributing

1. Fork il repository
2. Crea un branch per la tua feature (`git checkout -b feature/AmazingFeature`)
3. Commit le modifiche (`git commit -m 'Add some AmazingFeature'`)
4. Push al branch (`git push origin feature/AmazingFeature`)
5. Apri una Pull Request

### Development Guidelines
- Segui le convenzioni Python PEP 8
- Documenta le nuove funzionalità
- Testa le modifiche localmente prima del commit
- Aggiorna la documentazione se necessario

---

## 📄 License

Questo progetto è licenziato sotto MIT License - vedi il file [LICENSE](LICENSE) per i dettagli.

---

## 👥 Credits

Sviluppato da **CNR-ISMAR** (Consiglio Nazionale delle Ricerche - Istituto di Scienze Marine)

### Contatti
- **Email**: ismar@cnr.it
- **Website**: [www.ismar.cnr.it](https://www.ismar.cnr.it/)
- **GitHub**: [github.com/CNR-ISMAR](https://github.com/CNR-ISMAR)

---

## 🔗 Link Utili

- [Streamlit Documentation](https://docs.streamlit.io/)
- [Docker Documentation](https://docs.docker.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [GeoPandas Documentation](https://geopandas.org/)

---

<p align="center">
  Made with ❤️ by CNR-ISMAR
</p>
