import streamlit as st
import plotly.graph_objects as go
import pandas as pd

def bar(labels, series, title, color="royalblue"):
    vals = [int(series.get(x, 0)) for x in labels]
    fig = go.Figure(go.Bar(
        x=vals, y=labels, orientation="h",
        marker_color=color, width=0.6
    ))
    fig.update_layout(
        title=title,
        height=max(300, 25 * len(labels)),
        width=1000,
        margin=dict(l=100, r=40, t=40, b=40)
    )
    st.plotly_chart(fig, use_container_width=False)

def vega_bar(labels, series, title, color="steelblue"):
    """Create horizontal bar chart using Vega-Lite"""
    vals = [int(series.get(x, 0)) for x in labels]
    
    # Prepare data for Vega-Lite
    data = pd.DataFrame({
        'category': labels,
        'value': vals
    })
    
    # Vega-Lite chart configuration
    chart_spec = {
        "mark": {"type": "bar", "color": color},
        "encoding": {
            "x": {"field": "value", "type": "quantitative", "title": "Count"},
            "y": {"field": "category", "type": "ordinal", "title": "Category", "sort": "-x"}
        },
        "title": title,
        "width": 600,
        "height": max(300, 25 * len(labels))
    }
    
    st.vega_lite_chart(data, chart_spec, use_container_width=True)
