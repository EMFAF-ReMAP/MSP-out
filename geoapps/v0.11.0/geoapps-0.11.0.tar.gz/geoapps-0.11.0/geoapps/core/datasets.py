import json, requests
from collections import defaultdict
from typing import Dict, List
import streamlit as st
from pathlib import Path

# Import defaults first
try:
    from .defaults import (
        SCHEMA_PATH as DEFAULT_SCHEMA_PATH,
        CKAN_API_URL as DEFAULT_API_URL
    )
except ImportError:
    DEFAULT_SCHEMA_PATH = "/var/geoapps/geoapps_storage/schema.json"
    DEFAULT_API_URL = "https://catalogue.tools4msp.eu/api"

# Initialize with None
SCHEMA_PATH = None
API_URL = None
API_KEY = None

# Try to get from configuration
try:
    from .config import get_data_path, get_api_config
    SCHEMA_PATH = get_data_path("schema")
    api_config = get_api_config()
    if api_config:
        API_URL = api_config.get("url")
        API_KEY = api_config.get("key")
except ImportError:
    pass
except Exception:
    pass

# If config returned None or failed, try legacy config
if SCHEMA_PATH is None or API_URL is None:
    try:
        from . import config
        if SCHEMA_PATH is None and hasattr(config, 'SCHEMA_PATH'):
            SCHEMA_PATH = config.SCHEMA_PATH
        if API_URL is None and hasattr(config, 'API_URL'):
            API_URL = config.API_URL
        if API_KEY is None and hasattr(config, 'API_KEY'):
            API_KEY = config.API_KEY
    except ImportError:
        pass

# Try absolute import if still None
if SCHEMA_PATH is None or API_URL is None:
    try:
        import config
        if SCHEMA_PATH is None and hasattr(config, 'SCHEMA_PATH'):
            SCHEMA_PATH = config.SCHEMA_PATH
        if API_URL is None and hasattr(config, 'API_URL'):
            API_URL = config.API_URL
        if API_KEY is None and hasattr(config, 'API_KEY'):
            API_KEY = config.API_KEY
    except ImportError:
        pass

# Final fallback to defaults
if SCHEMA_PATH is None:
    SCHEMA_PATH = Path(DEFAULT_SCHEMA_PATH)
else:
    SCHEMA_PATH = Path(SCHEMA_PATH) if not isinstance(SCHEMA_PATH, Path) else SCHEMA_PATH

if API_URL is None:
    API_URL = DEFAULT_API_URL

if API_KEY is None:
    API_KEY = "your-api-key-here"  # Will be overridden by secrets.yaml if available

import tools.logger as log

# 🔧 Parse cluster structure from schema.json
@st.cache_data(ttl=24*60*60)
def parse_cluster_structure() -> Dict[str, Dict[str, List[str]]]:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    cluster_structure = defaultdict(dict)
    for f in schema["dataset_fields"]:
        cl = f.get("cluster")
        if cl and f.get("choices"):
            cluster_structure[cl][f["field_name"]] = [c["value"] for c in f["choices"]]
    log.logger.info("Parsed schema with %d clusters", len(cluster_structure))
    return dict(cluster_structure)

# 🔧 Fetch organizations list
@st.cache_data(ttl=6*60*60)
def fetch_orgs() -> List[str]:
    log.logger.debug("Fetching organization list from CKAN API")
    r = requests.get(f"{API_URL}/3/action/organization_list",
                     headers={"Authorization": API_KEY})
    return sorted(r.json()["result"], key=str.lower) if r.ok else []

# 🔧 Fetch datasets from CKAN
@st.cache_data(ttl=6*60*60)
def fetch_datasets(org_id, cluster_structure, _to_label_func) -> Dict[str, Dict]:
    params = {"rows": 1000}
    if org_id:
        params["fq"] = f"organization:{org_id}"

    log.logger.debug("Fetching datasets from CKAN API")
    raw = requests.get(f"{API_URL}/3/action/package_search",
                       headers={"Authorization": API_KEY},
                       params=params).json()["result"]["results"]

    out = {}
    for ds in raw:
        ds_id = ds.get("id") or ds.get("name")
        name = ds.get("name")
        title = ds.get("title") or name or "Untitled"
        url = f"https://catalogue.tools4msp.eu/msp-data/{name}" if name else ""

        das = ds.get("domain_area", [])
        domain_areas = sorted({_to_label_func(x) for x in (das if isinstance(das, list) else [das])} - {None})

        cats = []
        for cluster, classes in cluster_structure.items():
            for cls in classes:
                vals = ds.get(cls, [])
                if isinstance(vals, list) and vals:
                    cats.extend((cluster, cls, v) for v in vals)

        if not cats:
            cats = []

        out[ds_id] = {
            "title": title,
            "domain_areas": domain_areas,
            "categories": cats,
            "url": url
        }

    log.logger.info("Fetched %d datasets", len(out))
    return out
