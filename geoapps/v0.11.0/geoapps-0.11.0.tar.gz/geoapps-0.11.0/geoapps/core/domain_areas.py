#domain_areas.py

import json
import pandas as pd
from shapely.geometry import box
from unidecode import unidecode
import streamlit as st
from pathlib import Path

# Import defaults first
try:
    from .defaults import DOMAIN_AREAS_SIMPLIFIED_PATH as DEFAULT_PATH
except ImportError:
    DEFAULT_PATH = "/var/geoapps/geoapps_storage/domain_areas_simplified.json"

# Try to get path from configuration
DOMAIN_SIMPL_PATH = None

try:
    from .config import get_data_path
    DOMAIN_SIMPL_PATH = get_data_path("domain_simplified")
except ImportError:
    pass
except Exception:
    pass

# If config returned None or failed, try legacy config
if DOMAIN_SIMPL_PATH is None:
    try:
        from . import config
        if hasattr(config, 'DOMAIN_SIMPL_PATH'):
            DOMAIN_SIMPL_PATH = config.DOMAIN_SIMPL_PATH
    except ImportError:
        pass

# If still None, try absolute import
if DOMAIN_SIMPL_PATH is None:
    try:
        import config
        if hasattr(config, 'DOMAIN_SIMPL_PATH'):
            DOMAIN_SIMPL_PATH = config.DOMAIN_SIMPL_PATH
    except ImportError:
        pass

# Final fallback to default
if DOMAIN_SIMPL_PATH is None:
    DOMAIN_SIMPL_PATH = Path(DEFAULT_PATH)
else:
    # Ensure it's a Path object
    DOMAIN_SIMPL_PATH = Path(DOMAIN_SIMPL_PATH) if not isinstance(DOMAIN_SIMPL_PATH, Path) else DOMAIN_SIMPL_PATH

import tools.logger as log

@st.cache_data(ttl=24*60*60)
def load_domain_areas() -> pd.DataFrame:
    data = json.loads(DOMAIN_SIMPL_PATH.read_text())
    recs = []
    for da in data:
        ext = da.get("extent")
        if ext and len(ext) == 4:
            recs.append({
                "domain_area": da["label"],
                "bbox": box(*ext),
                "geo_simplified": da.get("geo_simplified"),
                "id": da["id"],
            })
    log.logger.info("Loaded %d domain areas", len(recs))
    return pd.DataFrame(recs)

def slug(txt: str) -> str:
    return unidecode(str(txt)).lower().replace(" ", "_")

def build_lookups(df: pd.DataFrame):
    DA_BY_LABEL = {row["domain_area"]: row for _, row in df.iterrows()}
    DA_BY_ID    = {str(row["id"]): row for _, row in df.iterrows()}
    DA_BY_SLUG  = {slug(row["domain_area"]): row for _, row in df.iterrows()}
    return DA_BY_LABEL, DA_BY_ID, DA_BY_SLUG

def to_label(val, DA_BY_LABEL, DA_BY_ID, DA_BY_SLUG) -> str | None:
    if val in DA_BY_LABEL:
        return val
    sval = str(val)
    if sval in DA_BY_ID:
        return DA_BY_ID[sval]["domain_area"]
    return DA_BY_SLUG.get(slug(sval), {}).get("domain_area")
