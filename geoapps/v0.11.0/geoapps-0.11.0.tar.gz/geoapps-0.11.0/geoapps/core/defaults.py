"""
Central configuration defaults for GeoApps.
This file contains all fallback values used when configuration is not available.
"""

# ──────────────────────────────────────────────────────────────
# Authentication & Session Management
# ──────────────────────────────────────────────────────────────
MAX_CONCURRENT_USERS = 5           # Maximum number of concurrent DEMO users
SESSION_TIMEOUT_MINUTES = 10       # Session timeout for activity heartbeat
DEMO_QUEUE_TIMEOUT_MINUTES = 30    # Time before a queued user is removed
MAX_DEMO_QUEUE_SIZE = 20           # Maximum number of users allowed in demo queue (anti-spam)
PERSISTENT_LOGIN_DAYS = 7          # Days before persistent login token expires
AUTO_REFRESH_QUEUE_SECONDS = 15    # Auto-refresh interval for queue page

# ──────────────────────────────────────────────────────────────
# Database Configuration
# ──────────────────────────────────────────────────────────────
DATABASE_PATH = "geoapps_storage/auth.db"
DATABASE_URL = "postgresql://remap:remap@172.17.0.1:5432/remap"  # PostgreSQL connection URL (Linux Docker default)
SQLITE_TIMEOUT = 10.0              # seconds
SQLITE_MAX_RETRIES = 5
SQLITE_RETRY_SLEEP = 0.2           # seconds

# ──────────────────────────────────────────────────────────────
# Security
# ──────────────────────────────────────────────────────────────
UTILS_SECRET = "d201931ffe4698a5a089f3e1380c27b9"
COOKIE_SECRET = "change_this_secret_key"

# ──────────────────────────────────────────────────────────────
# Cookie Management
# ──────────────────────────────────────────────────────────────
COOKIE_PREFIX = "cnr_demo_"

# ──────────────────────────────────────────────────────────────
# Storage Paths
# ──────────────────────────────────────────────────────────────
STATIC_DIR = "/var/geoapps/geoapps_storage/statics/published/"
STORAGE_DIR = "geoapps_storage"

# Data file paths (Docker container paths)
DOMAIN_AREAS_SIMPLIFIED_PATH = "/var/geoapps/geoapps_storage/domain_areas_simplified.json"
DOMAIN_AREAS_PATH = "/var/geoapps/geoapps_storage/domain_areas.json"
PARQUET_DATA_DIR = "/var/geoapps/geoapps_storage/remap/parquetdata"
SCHEMA_PATH = "/var/geoapps/geoapps_storage/schema.json"

# ──────────────────────────────────────────────────────────────
# Application Settings
# ──────────────────────────────────────────────────────────────
APP_TITLE = "CNR-ISMAR GeoApps"
APP_LOGO_URL = "https://catalogue.tools4msp.eu/logo.png"
PAGE_TITLE_HOME = "CNR-ISMAR Demo Dashboard"
PAGE_TITLE_CKAN = "CKAN Spatial Filter"

# ──────────────────────────────────────────────────────────────
# Data Analysis
# ──────────────────────────────────────────────────────────────
SANKEY_DEFAULT_OPACITY = 0.6

# ──────────────────────────────────────────────────────────────
# UI Settings
# ──────────────────────────────────────────────────────────────
DEMO_SLOTS_PER_ROW = 3             # Number of demo slot buttons per row
QUEUE_ESTIMATED_WAIT_PER_PERSON = 10  # Minutes estimated wait per person in queue

# ──────────────────────────────────────────────────────────────
# API Settings
# ──────────────────────────────────────────────────────────────
CKAN_API_URL = "https://catalogue.tools4msp.eu/api"
