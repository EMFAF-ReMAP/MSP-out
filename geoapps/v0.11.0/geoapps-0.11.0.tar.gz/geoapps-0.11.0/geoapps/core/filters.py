import pandas as pd
import streamlit as st

# Core filtering logic (pandas safe filters)
def apply_filters(df_long, sel_cluster, sel_class, sel_sub, search_text):
    mask = pd.Series(True, index=df_long.index)

    if sel_cluster != "All":
        mask &= df_long["cluster"].fillna("—") == sel_cluster

    if sel_class != "All":
        mask &= df_long["class_"].fillna("—") == sel_class

    if sel_sub != "All":
        mask &= df_long["subclass"].fillna("—") == sel_sub

    if search_text:
        mask &= df_long["title"].str.contains(search_text, case=False, na=False)

    return df_long[mask]

# Sidebar filters for Cluster/Class/Subclass
def sidebar_filters(cluster_structure):
    clusters = sorted(cluster_structure.keys(), key=str.lower)
    sel_cluster = st.sidebar.selectbox("Cluster", ["All"] + clusters)

    sel_class, sel_sub = "All", "All"
    if sel_cluster == "All":
        st.sidebar.selectbox("Class", ["All"], disabled=True)
        st.sidebar.selectbox("Subclass", ["All"], disabled=True)
    else:
        classes = sorted(cluster_structure[sel_cluster].keys(), key=str.lower)
        sel_class = st.sidebar.selectbox("Class", ["All"] + classes)
        if sel_class == "All":
            st.sidebar.selectbox("Subclass", ["All"], disabled=True)
        else:
            subs = sorted(cluster_structure[sel_cluster][sel_class], key=str.lower)
            sel_sub = st.sidebar.selectbox("Subclass", ["All"] + subs)

    return sel_cluster, sel_class, sel_sub

# Sidebar layers for Domain Areas (with Select All / Deselect All + scrollable box)
def domain_area_layer_sidebar(da_counts_full):
    if "da_layer_state" not in st.session_state:
        st.session_state.da_layer_state = {da: True for da in da_counts_full}

    with st.sidebar.expander("Domain Areas", expanded=True):
        col_select_all, col_deselect_all = st.columns(2)
        if col_select_all.button("Select All"):
            for da in da_counts_full:
                st.session_state.da_layer_state[da] = True
        if col_deselect_all.button("Deselect All"):
            for da in da_counts_full:
                st.session_state.da_layer_state[da] = False

        st.markdown("<div style='max-height:400px; overflow-y:auto; padding-right:5px;'>", unsafe_allow_html=True)

        for da, count in sorted(da_counts_full.items(), key=lambda x: x[0]):
            col1, col2 = st.columns([0.85, 0.15])
            with col1:
                checked = st.session_state.da_layer_state.get(da, True)
                st.session_state.da_layer_state[da] = st.checkbox(da, value=checked, key=f"layer_{da}")
            with col2:
                st.markdown(f"<div style='text-align:right'>{count}</div>", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    return st.session_state.da_layer_state.copy(), st.session_state.get("applied_layer_state", {})
