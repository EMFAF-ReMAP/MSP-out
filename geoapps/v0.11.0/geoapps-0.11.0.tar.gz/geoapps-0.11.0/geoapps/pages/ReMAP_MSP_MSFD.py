#1_📈_ReMAP_MSP_MSFD_v2.py

import io
from matplotlib import pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.cm as cm
# from matplotlib.backends.backend_agg import RendererAgg

import streamlit as st
from tools.utils import make_login, make_header, set_sankey_data, publish_result, check_pageload

import os
import uuid
import pyarrow as pa
import geopandas as gpd
import pydeck as pdk
import streamlit as st
import pandas as pd
import contextily as cx
import time
import matplotlib.patches as mpatches
import streamlit as st
import folium
from streamlit_folium import st_folium
from streamlit.components.v1 import html
from branca.element import Element
import matplotlib.pyplot as plt
from sankeyflow import Sankey
import json
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
pio.templates.default = "seaborn" # "plotly"
import zipfile
import json
import io
from tools.importer import *
from database.dbconn import QueryManager, ZoningAreas, Plans, add_where, engine, CoverageUF, AreasOfInterest, GESNonov, MRUNonov, GESNonov2024, MRUNonov2024, ZoningAreasMRUNonv, ZoningAreasMRUNonv2024
from sqlalchemy import select, func, distinct, and_, or_, not_, case
from geoalchemy2 import Geometry, functions as geofunc
from core.map_utils import make_map, set_map_state
from threading import RLock
_lock = RLock()

from auth.access_guard import require_app_login
require_app_login()  # redirect se non loggato

qm = QueryManager(engine)
qmconf = QueryManager(engine)

from pathlib import Path
MAP_CRITERIA_LABELS_PATH = Path("/var/geoapps/geoapps_storage/map_criteria_labels.json")
with open(MAP_CRITERIA_LABELS_PATH) as f:
    d = json.load(f)

CRITERIAS = {r['target']: r['Criteria_Name'] for r in d}
CRITERIAS_R = {r['Criteria_Name']: r['target'] for r in d}
        
##################################
# utils function
GES = {
    '(?)':'#d3d3d3',
    'GES later than 2024, Art14ExceptionNotReported': '#b83230',
    'GES later than 2024, Art14ExceptionReported': '#b83230',
    'GES not achieved by 2018': '#b83230',
    'GES achieved by 2012': '#0083e0',
    'GES achieved by 2018': '#0083e0',
    'GES achieved by 2024': '#0083e0',
    'Not assessed': '#d2b48c',
    'Not relevant': '#d2b48c',
    'Unknown': '#e6e7e8',
    # Element status
    'Not good': '#faa85f',
    # (None,),
    'Good': '#3b85b3',
    'Not assessed': '#a7a9ac',
    'Good, based on low risk': '#abd9c5',
    # Parameters
    'Yes': '#394e98',
    'No': '#e4ad69',
    'Yes, based on low risk': '#bad9c6',
    # Criteria
    'Contributes to assessment of another criterion/ele':  '#6a392d',
}

GES_ASSESSED = [
    'GES later than 2024, Art14ExceptionNotReported',
    'GES not achieved by 2018',
    'GES achieved by 2012',
    'GES achieved by 2018',
    'GES achieved by 2024',
    'Not good',
    'Good',
    'Good, based on low risk',
    'Yes',
    'No',
    'Yes, based on low risk',
    'Contributes to assessment of another criterion/ele',
]

GES_ASSESSED_POS = [
    'GES achieved by 2012',
    'GES achieved by 2018',
    'GES achieved by 2024',
    'Good',
    'Good, based on low risk',
    'Yes',
    'Yes, based on low risk',
]

GES_ASSESSED_NEG = [
    'GES later than 2024, Art14ExceptionNotReported',
    'GES not achieved by 2018',
    'Not good',
    'No',
]

GES_NOT_ASSESSED = [
    'Unknown',
    'Not relevant',
    'Not assessed',
]

GES_DESCRIPTORS_2024 = {
        "D1B": "D1 Biodiversity - birds",
        "D1M": "D1 Biodiversity - mammals",
        "D1R": "D1 Biodiversity - reptiles",
        "D1F": "D1 Biodiversity - fish",
        "D1C": "D1 Biodiversity - cephalopods",
        "D1P": "D1 Biodiversity – pelagic habitats",
        "D2": "D2 Non-indigenous species",
        "D3": "D3 Commercial fish and shellfish",
        "D4/D1": "D4 Food webs/D1 Biodiversity - ecosystems",
        "D5": "D5 Eutrophication",
        "D6/D1": "D6 Sea-floor integrity/D1 Biodiversity - benthic habitats",
        "D7": "D7 Hydrographical changes",
        "D8": "D8 Contaminants",
        "D9": "D9 Contaminants in seafood",
        "D10": "D10 Marine litter",
        "D11": "D11 Energy",
        "Not relevant": "GES component not relevant"
    }

GES_FEATURES_2024 = {
        "BirdsBenthicFeeding": "Benthic-feeding birds",
        "BirdsGrazing": "Grazing birds",
        "BirdsPelagicFeeding": "Pelagic-feeding birds",
        "BirdsSurfaceFeeding": "Surface-feeding birds",
        "BirdsWading": "Wading birds",
        "CephaCoastShelf": "Coastal/shelf cephalopods",
        "CephaDeepSea": "Deep-sea cephalopods",
        "CharaChem": "Chemical characteristics",
        "CharaPhyHydro": "Physical and hydrological characteristics",
        "EcosysCoastal": "Coastal ecosystems",
        "EcosysOceanic": "Oceanic/deep-sea ecosystems",
        "EcosysShelf": "Shelf ecosystems",
        "FishCoastal": "Coastal fish",
        "FishCommercial": "Commercially exploited fish and shellfish",
        "FishDeepSea": "Deep-sea fish",
        "FishDemersalShelf": "Demersal shelf fish",
        "FishPelagicShelf": "Pelagic shelf fish",
        "HabBenBHT": "Benthic broad habitats",
        "HabBenOther": "Other benthic habitats",
        "HabPelBHT": "Pelagic broad habitats",
        "HabPelOther": "Other pelagic habitats",
        "MamCetacBaleenWhales": "Baleen whales",
        "MamCetacDeepDiving": "Deep-diving toothed cetaceans",
        "MamCetacSmall": "Small toothed cetaceans",
        "MamSeals": "Seals",
        "RepTurtles": "Turtles",
        "Species": "Species",
        "SpeciesGroups": "Species groups",
        "PresBioIntroNIS": "Input or spread of non-indigenous species",
        "PresBioIntroMicroPath": "Input of microbial pathogens",
        "PresBioIntroGenModSpp": "Input of genetically modified species and translocation of native species",
        "PresBioCultHab": "Loss of, or change to, natural biological communities due to cultivation of animal or plant species",
        "PresBioDisturbSpp": "Disturbance of species (e.g. where they breed, rest and feed) due to human presence",
        "PresBioExtractSpp": "Extraction of, or mortality/injury to, wild species (by commercial and recreational fishing and other activities)",
        "PresInputNut": "Input of nutrients – diffuse sources, point sources, atmospheric deposition",
        "PresInputOrg": "Input of organic matter – diffuse sources and point sources",
        "PresInputCont": "Input of other substances (e.g. synthetic substances, non-synthetic substances, radionuclides) – diffuse sources, point sources, atmospheric deposition, acute events",
        "PresInputLitter": "Input of litter (solid waste matter, including micro-sized litter)",
        "PresInputSound": "Input of anthropogenic sound (impulsive, continuous)",
        "PresInputOthEnergy": "Input of other forms of energy (including electromagnetic fields, light and heat)",
        "PresInputWater": "Input of water – point sources (e.g. brine)",
        "PresEnvHydroChanges": "Hydrographical changes",
        "PresPhyDisturbSeabed": "Physical disturbance to seabed",
        "PresPhyLoss": "Physical loss of the seabed",
        "PresEnvAdvEffectsSppHab": "Adverse effects on species or habitats"
    }

def plot_ges2(gdf_coherence, assessment_col):
    # title = _get_title(seausename, component, feature, suffix)
    with _lock:
        fig, ax = plt.subplots(figsize=[10, 10])
        color_map = {g: GES.get(g, '#000000') for g in gdf_coherence[assessment_col].unique()}
        gdf_coherence['color'] = gdf_coherence[assessment_col].map(color_map)
        ax = gdf_coherence.to_crs(epsg=3857).plot(ax=ax, color=gdf_coherence.color, categorical=True)  
        legend_patches = [mpatches.Patch(color=color, label=ges) for ges, color in color_map.items()]
        ax.legend(handles=legend_patches, title="Assessment", loc='lower left')
        add_to_plot(ax, gdf_coherence)
        fig.tight_layout()
        st.pyplot(fig, width="content")
        if st.button("Publish", key="publish_assessment_map"):
            publish_result(fig, prefix='msfd_assessment_map')

def add_to_plot(ax, gdf):
    (gdf
     .to_crs(epsg=3857)
     .boundary.plot(ax=ax,
                    color='grey',
                    linewidth=0.5)
     )

    cx.add_basemap(ax, source=cx.providers.CartoDB.Positron)
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    return ax

def plot_spatial_coherence(gdf_coherence):
    with _lock:
        fig, ax = plt.subplots(figsize=[10, 10])
        ax = gdf_coherence.to_crs(epsg=3857).plot(ax=ax, column='coherence', cmap="viridis_r",
                                                  figsize=[10, 10],
                                                  vmax = 1,
                                                  )    
        colormap = cm.get_cmap('viridis_r', 6)  # Set3 ha colori adatti per categorie
        color_dict = {f"{category:.1f}": mcolors.to_hex(colormap(i)) for i, category in enumerate(np.arange(0, 1.2, 0.2))}

        # Creiamo la legenda automaticamente
        legend_patches = [mpatches.Patch(color=color, label=category) for category, color in color_dict.items()]
        ax.legend(handles=legend_patches, title="Coherence", loc='lower left')
    
        # comment this part to make the figure with the same size
        # cbar = ax.get_figure().get_axes()[1]
        add_to_plot(ax, gdf_coherence)

        fig.tight_layout()
        st.pyplot(fig, width="content")
        if st.button("Publish", key="publish_coherence_map"):
            publish_result(fig, prefix='msfd_coherence_map')


st.set_page_config(layout="wide")

make_header()
# st.sidebar.image('https://www.geoportal.ulpgc.es/remap/img/logoRemap.png', width=200)

# set defaults
if "font_size" not in st.session_state:
    st.session_state.font_size = 3
if "curvature" not in st.session_state:
    st.session_state.curvature = 3
if "color" not in st.session_state:
    st.session_state.color = "Pastel1"
if "flow_color_mode" not in st.session_state:
    st.session_state.flow_color_mode = "dest"


description_text = """
**Overall status**

GES has been achieved or not - 11
Descriptors, 52 “features”(e.g. species groups, habitat types,
ecosystems, anthropogenic pressures, etc.).
[More info](https://water.europa.eu/marine/resources/msfd-reporting-data-tools/ges-assessment-dashboards/overall-status-of-features-msfd-art-8-2018-chart)

**Element status**

e.g. specific species, habitats, fish stocks, eutrophication elements,
contaminants, etc, if they are in good status or not. (almost 3000
MSFD possible elements).
[More info](https://water.europa.eu/marine/resources/msfd-reporting-data-tools/ges-assessment-dashboards/element-status-msfd-art-8-2018-chart)

**Criteria status** 

The 42 criteria assessed are in good status or not for each one of the
associated elements.
[More info](https://water.europa.eu/marine/resources/msfd-reporting-data-tools/ges-assessment-dashboards/criteria-status-msfd-art-8-2018-chart)

**Parameter results**

For each one of the elements and criteria used, conclusion on whether
the different parameters assessed have been achieved
(e.g. concentration in water, sediment or biota, number of individuals
of a given species)
[More info](https://water.europa.eu/marine/resources/msfd-reporting-data-tools/ges-assessment-dashboards/parameter-results-msfd-art-8-2018-graph)

"""

# layout


def print_assessment_info():
    assessment_col = st.session_state.assessment_col
    st.write(f"## Assessment: {st.session_state.assesment_level_selected_filter}")
    with st.expander("ℹ️  See explanation"):
        st.write(description_text)

    st.info(f"""
**MSP Sea Use:** {st.session_state.seause_selected_filter}

**MSP Sea functions:** {", ".join(st.session_state.function_selected_filter)}

**MSFD Component:** {st.session_state.components_selected_filter}

**MSFD Feature:** {st.session_state.features_selected_filter}

**MSFD Element:** {st.session_state.elements_selected_filter or '-'}

**MSFD Parameter:** {st.session_state.parameters_selected_filter or '-'}

**MSFD Criterion:** {st.session_state.criteria_selected_filter or '-'}
""")

@st.fragment
def plot_treemap():

    assessment_col = st.session_state.assessment_col
    tree_columns = ['MS'] + st.session_state.assessment_columns_path

    gdf_coherence = st.session_state.gdf_coherence
    gdf_coherence['geoarea'] = gdf_coherence.area / 1000000

    # treemap color
    treemap_color_options = tree_columns
    treemap_color_selected = st.selectbox(
        "Color mode",
        options=treemap_color_options,
        key="treemap_color_selected",
    )

    df = gdf_coherence.fillna('Undefined') # df_ges.fillna('unknown')

    print("########################")
    print(df[tree_columns])
    fig = px.treemap(df, path=[px.Constant("GES")] + tree_columns,
                     values='geoarea',
                     # color='lifeExp', hover_data=['iso_alpha'],
                     # color_continuous_scale='RdBu',
                     # color_continuous_midpoint=np.average(df['lifeExp'], weights=df['pop'])
                     color_discrete_map=GES if treemap_color_selected == assessment_col else None,
                     color=st.session_state.treemap_color_selected,
                     )
    fig.update_layout(margin = dict(t=50, l=25, r=25, b=25))
    fig.update_traces(marker=dict(cornerradius=5))

    ftitle = f'MSFD {st.session_state.msfdrp_selected_filter} - {st.session_state.seause_selected_filter[0]}'
    fig.update_layout(
        title_text=ftitle,
        # font=dict(size=12),
        # title_font=dict(size=18, family="Arial", color="black"),
        # title_x=0.5  # centra il titolo
    )

    st.plotly_chart(fig, use_container_width=True)

    if st.button("Publish Treemap", key="publish_msfd_tree"):
        publish_result(fig)
    
    
@st.fragment
def sankey_plot():
    assessment_col = st.session_state.assessment_col
    
    c1, c2 = st.columns([8, 2])
    gdf_coherence = st.session_state.gdf_coherence
    # gdf_ges = st.session_state.gdf_ges
    gdf_coherence['geoarea'] = gdf_coherence.area / 1000000
    print('Flowsssssssssssssssssssssssssss')
    print(gdf_coherence.columns)
    print(assessment_col)
    print(gdf_coherence[assessment_col].unique())
    data = gdf_coherence.groupby(['MS', assessment_col]).sum('geoarea')[['geoarea']].reset_index()
    data['dest_color'] = data[assessment_col].map(lambda x: {'color': f"{GES.get(x)}80"}) # tolgo il # e aggiunto la trasparenza al 50% #80
    flows = data.values.tolist()
    print(flows)
    s = Sankey(flows=flows,
               cmap=plt.get_cmap(st.session_state.color),
               flow_color_mode=st.session_state.flow_color_mode,
               node_opts={"label_opts": {"fontsize": st.session_state.font_size}},
               flow_opts={"curvature": st.session_state.curvature / 10.0},
               )
    print("COHERENCE")
    print(gdf_coherence)
    for node in s.nodes[1]:
        node.color = GES.get(node.label)
    with c1:
        with _lock:
            fig, ax = plt.subplots()
            s.draw(ax)
            st.pyplot(fig, width="content")

    with c2:
        st.write("Sankey configuration")
        st.number_input("Font Size", 1, 8, st.session_state.font_size, 1, key="font_size")
        st.number_input("Curviness", 0, 10, st.session_state.curvature, 1, key="curvature")
        color_options = ["tab10", "tab20", "Pastel1", "Pastel2", "Set1", "Set2", "Set3"]
        st.selectbox(
            "Color Palette",
            index=color_options.index(st.session_state.color),
            options=color_options,
            key="color",
        )
        flow_color_mode_options = ["dest", "source"]
        st.selectbox("Flow Color Mode",
                     index=flow_color_mode_options.index(st.session_state.flow_color_mode),
                     options=flow_color_mode_options,
                     key="flow_color_mode"
                     )

def get_cache_key():
    return [
        st.session_state.msfdrp_selected_filter,
        st.session_state.ms_selected_filter,
        st.session_state.seause_selected_filter,
        st.session_state.function_selected_filter,
        st.session_state.assesment_level_selected_filter,
        st.session_state.components_selected_filter,
        st.session_state.features_selected_filter,
        st.session_state.elements_selected_filter,
        st.session_state.parameters_selected_filter,
        st.session_state.criteria_selected_filter,
        st.session_state.aoi_selected_filter,
        ]                                                                                                                                                                                          


@st.cache_data
def merge_data(cache_hash):
    reporting_period = st.session_state.get('msfdrp_selected_filter')
    if reporting_period == 2018:
        _GESNonov = GESNonov
        _MRUNonov = MRUNonov
        _ZoningAreasMRUNonv = ZoningAreasMRUNonv
    elif reporting_period == 2024:
        _GESNonov = GESNonov2024
        _MRUNonov = MRUNonov2024
        _ZoningAreasMRUNonv = ZoningAreasMRUNonv2024

    # # filtro sulla parte MSFD
    # ges_filtered_subq = (
    #     select(
    #         _GESNonov.nonov_id,
    #         _GESNonov.MS,
    #         _GESNonov.geoarea_mru,
    #         _GESNonov.MRU
    #     )
    #     .distinct(_GESNonov.nonov_id, GESNonov.MS)
    # )
    # ges_filtered_subq = add_where(ges_filtered_subq, _GESNonov, qm._filters)
    # sql = ges_filtered_subq.compile(
    #         compile_kwargs={"literal_binds": True}
    #     )
    # st.write(sql)
    # aa = qm.read(ges_filtered_subq, 'df')
    # st.write(aa.shape)
    # ges_filtered_subq = ges_filtered_subq.subquery("ges_filtered")

    # # viene aggiunto il filtro sulla parte MSP e caricamento geometrie precalcolate
    # stmt_by_intersection = (
    #     select(
    #         _MRUNonov.MS,
    #         _MRUNonov.nonov_id,
    #         ZoningAreas.Sea_use,
    #         ZoningAreas.SPID,
    #         ZoningAreas.Function,
    #         ges_filtered_subq.c.geoarea_mru,
    #         ges_filtered_subq.c.MRU,
    #         ZoningAreasMRUNonv.geometry,
    #         ZoningAreasMRUNonv.zoning_areas_index,
    #         ZoningAreasMRUNonv.mru_nonov_id,
    #     )
    #     .join(
    #         ges_filtered_subq,
    #         and_(
    #             _MRUNonov.MS == ges_filtered_subq.c.MS,
    #             _MRUNonov.nonov_id == ges_filtered_subq.c.nonov_id,
    #         )
    #     )
    #     .join(
    #         ZoningAreasMRUNonv,
    #         and_(ZoningAreasMRUNonv.mru_nonov_id==_MRUNonov.nonov_id)
    #     )
    #     .join(
    #         ZoningAreas,
    #         and_(ZoningAreasMRUNonv.zoning_areas_index==ZoningAreas.index)
    #         )
    # )
    # if st.session_state.aoi_selected_filter:
    #     stmt_by_intersection = stmt_by_intersection.join(AreasOfInterest,
    #                                                      and_(AreasOfInterest.label == st.session_state.aoi_selected_filter,
    #                                                           geofunc.ST_Intersects(ZoningAreasMRUNonv.geometry, AreasOfInterest.geometry),
    #                                                           )
    #                                                      )
    # stmt_by_intersection = add_where(stmt_by_intersection, _MRUNonov, qm._filters)
    # stmt_by_intersection = add_where(stmt_by_intersection, ZoningAreas, qm._filters)

    # st.write("Intersection")
    # sql = stmt_by_intersection.compile(
    #         compile_kwargs={"literal_binds": True}
    #     )
    # st.write(sql)
    # df1 = qm.read(stmt_by_intersection, 'gdf')
    # st.write(df1.shape)
        
    # stmt_subq = stmt_by_intersection.subquery('stmt_join')

    
    # _columns = [getattr(_GESNonov, col_name) for col_name in st.session_state.assessment_columns]    
    # stmt_big = (
    #     select(
    #         *_columns,
    #         stmt_subq.c.MS,
    #         stmt_subq.c.Sea_use,
    #         stmt_subq.c.SPID,
    #         stmt_subq.c.Function,
    #         stmt_subq.c.geometry,
    #         stmt_subq.c.geoarea_mru,
    #         stmt_subq.c.nonov_id,
    #         stmt_subq.c.MRU,
    #     )
    #     .join(stmt_subq,
    #           and_(
    #               _GESNonov.MS == stmt_subq.c.MS,
    #               _GESNonov.MRU == stmt_subq.c.MRU,
    #               _GESNonov.nonov_id == stmt_subq.c.nonov_id
    #               )
    #           )
    #     ).distinct(
    #         *_columns,
    #         stmt_subq.c.MS,
    #         stmt_subq.c.nonov_id
    #     )
    # stmt_big = add_where(stmt_big, _GESNonov, qm._filters)
    # sql = stmt_big.compile(
    #     compile_kwargs={"literal_binds": True}
    # )
    # st.write(sql)

    # _mru_ze = qm.read(stmt_big, 'gdf')
    # st.write(_mru_ze.shape)


    _columns = [getattr(_GESNonov, col_name) for col_name in st.session_state.assessment_columns]    
    stmt_all = (
        select(
            _GESNonov.MS,
            _GESNonov.MRU,
            _GESNonov.nonov_id,
            _GESNonov.geoarea_mru,
            *_columns,
            _ZoningAreasMRUNonv.geometry,
            _ZoningAreasMRUNonv.zoning_areas_index,
            _ZoningAreasMRUNonv.mru_nonov_id,
            ZoningAreas.Sea_use,
            ZoningAreas.SPID,
            ZoningAreas.Function,
        )
        .join(
            _ZoningAreasMRUNonv,
            and_(_ZoningAreasMRUNonv.mru_nonov_id==_GESNonov.nonov_id,
                 _ZoningAreasMRUNonv.MS==_GESNonov.MS)
        )
        .join(
            ZoningAreas,
            and_(_ZoningAreasMRUNonv.zoning_areas_index==ZoningAreas.index,
                 _ZoningAreasMRUNonv.MS==ZoningAreas.MS)
            )
        .distinct(
            *_columns,
            _GESNonov.MS,
            _GESNonov.nonov_id
        )
    )
    stmt_all = add_where(stmt_all, _GESNonov, qm._filters)
    stmt_all = add_where(stmt_all, ZoningAreas, qm._filters)
    if st.session_state.aoi_selected_filter:
        stmt_all = stmt_all.join(AreasOfInterest,
                                 and_(AreasOfInterest.label == st.session_state.aoi_selected_filter,
                                      geofunc.ST_Intersects(_ZoningAreasMRUNonv.geometry, AreasOfInterest.geometry),
                                      )
                                 )
    sql = stmt_all.compile(
        compile_kwargs={"literal_binds": True}
    )
    # st.write(sql)
    _mru_ze = qm.read(stmt_all, 'gdf')

    
    _mru_ze.crs = 'epsg:3035'
    _mru_ze['area_intersection'] = _mru_ze.area / 1000000
    _mru_ze['coherence'] = np.cbrt(_mru_ze['area_intersection'] / _mru_ze['geoarea_mru'])
    if reporting_period == 2024:
        _mru_ze["GESComponent"] = _mru_ze["GESComponent"].replace(GES_DESCRIPTORS_2024)
        _mru_ze["Feature"] = _mru_ze["Feature"].replace(GES_FEATURES_2024)
    
    return _mru_ze #, gdf_merged


def filter_data():
    st.session_state.ze_unary_polygon = st.session_state.gdf_ze.unary_union


def apply_filters():
    qm._filters = {}
    # apply filters  
    if len(st.session_state.ms_selected_filter) > 0:
        qm.set_filter('MS', st.session_state.ms_selected_filter)
    if len(st.session_state.seause_selected_filter) > 0:
        qm.set_filter('Sea_use', st.session_state.seause_selected_filter)
    if len(st.session_state.function_selected_filter) > 0:
        qm.set_filter('Function', st.session_state.function_selected_filter)
    if st.session_state.components_selected_filter:
        qm.set_filter('GESComponent', st.session_state.components_selected_filter)
    if st.session_state.features_selected_filter:
        qm.set_filter('Feature', st.session_state.features_selected_filter)
    if st.session_state.elements_selected_filter:
        qm.set_filter('Element', st.session_state.elements_selected_filter)
    if st.session_state.criteria_selected_filter:
        qm.set_filter('Criteria', st.session_state.criteria_selected_filter)
    if st.session_state.parameters_selected_filter:
        qm.set_filter('Parameter', st.session_state.parameters_selected_filter)
        
    # apply geofilter
    if st.session_state.aoi_selected_filter:
        # uso il filtre spaziale manualmente per evitare nested queries
        # subq = (
        #     select(AreasOfInterest.geometry)
        #     .where(AreasOfInterest.label == st.session_state.aoi_selected_filter)
        #     .subquery()
        # )
        # qm.set_filter('ST_intersects', subq.c.geometry)
        pass


def plot_msp_msfd_sankey():
    assessment_col = st.session_state.assessment_col

    tree_columns = ['MS'] + st.session_state.assessment_columns_path
    
    c1, c2 = st.columns([8, 2])
    gdf_coherence = st.session_state.gdf_coherence
    # gdf_ges = st.session_state.gdf_ges
    gdf_coherence['geoarea'] = gdf_coherence.area / 1000000
    __df = gdf_coherence
          
    sankey_columns = tree_columns

    labels, sources, targets, values, link_colors, sourceinfo = set_sankey_data(__df, sankey_columns, 'geoarea', flow_mode='dest', color_map=GES)

    # Creazione del grafico Sankey
    fig = go.Figure(go.Sankey(
        node=dict(
            # pad=15,
            # thickness=20,
            # line=dict(color='black', width=0.5),
            label=labels,
            color="grey",
        ),
        link=dict(
            source=sources,
            target=targets,
            value=values,
            color=link_colors,
            customdata = sourceinfo,
            hovertemplate='MS %{customdata}<br />'+
            'source: %{source.label}<br />'+
            'target: %{target.label}<br />' +
            'area: %{value}<br />',
        ),
        textfont=dict(
            color='black',
            shadow = "rgba(0, 0, 0, 0)",
        )
    ))

    for x_coordinate, column_name in enumerate(sankey_columns):
        fig.add_annotation(
            x=x_coordinate,#Plotly recognizes 0-5 to be the x range.
            
            y=1.075,#y value above 1 means above all nodes
            xref="x",
            yref="paper",
            text=column_name,#Text
            showarrow=False,
            align="left",
        )
    fig.update_traces(node_hoverlabel=dict(bgcolor="white"))
    # Mostrare il grafico
    # fig.update_layout(title_text='Diagramma di Sankey', font_size=10)

    ftitle = f'MSFD {st.session_state.msfdrp_selected_filter} - {st.session_state.seause_selected_filter[0]}'
    fig.update_layout(
        title_text=ftitle,
        xaxis=dict(showticklabels=False, visible=False),
        yaxis=dict(showticklabels=False, visible=False),
        plot_bgcolor='white',
        # font=dict(size=12),
        # title_font=dict(size=18, family="Arial", color="black"),
        # title_x=0.5  # centra il titolo
    )
    
    st.plotly_chart(fig, use_container_width=True)

    if st.button("Publish result", key="publish_msfd_sankey"):
        publish_result(fig, prefix='msfd_sankey')
        
    # st.dataframe(__df[sankey_columns])

    

@st.fragment
def make_analysis():
    analysis_header = st.empty()
    analysis_container = st.empty()
    assessment_col = st.session_state.assessment_col

    apply_filters()
    try:
        # _mru_ze, gdf_merged = merge_data(get_cache_key())
        _mru_ze = merge_data(get_cache_key())
    except pa.lib.ArrowTypeError as e:
        st.warning("No valid results found for the selected filter combination.", icon="⚠️")
        return

    if _mru_ze.empty:
        st.warning("No valid results found for the selected filter combination.", icon="⚠️")
        return
        
    st.session_state.gdf_coherence = _mru_ze
    # st.session_state.gdf_ges = gdf_merged

    tab_filter_column = st.session_state.assessment_name
    if st.session_state.assesment_level_selected_filter == 'Overall status':
        tab_names = st.session_state.features_selected_filter

    elif st.session_state.assesment_level_selected_filter == 'Element status':
        tab_names = st.session_state.elements_selected_filter

    elif st.session_state.assesment_level_selected_filter == 'Parameter results':
        tab_names = st.session_state.parameters_selected_filter

    elif st.session_state.assesment_level_selected_filter == 'Criteria status':
        tab_names = st.session_state.criteria_selected_filter


    excolumns = ['MS', 'SPID', 'Sea use', 'Function', 'MRU'] + st.session_state.assessment_columns
    
    # if st.session_state.assesment_level_selected_filter in ['Element status', 'Criteria status', 'Parameter results']:
    #     excolumns += ['Element', 'Element2', 'ElementStatus', 'DescriptionElement',]

    # if st.session_state.assesment_level_selected_filter in ['Criteria status', 'Parameter results']:
    #     excolumns += ['Criteria', 'CriteriaStatus',]

    # if st.session_state.assesment_level_selected_filter in ['Parameter results']:
    #     excolumns += ['Parameter', 'ParameterOther', 'ThresholdValueUpper',
    #                   'ThresholdValueLower', 'ThresholdQualitative',
    #                   'ThresholdValueSource', 'ValueAchievedUpper',
    #                   'ValueAchievedLower', 'ValueUnit',
    #                   'ValueUnitOther', 'Trend', 'ParameterAchieved',
    #                   ]

    gdf_coherence = st.session_state.gdf_coherence
    # st.write("gdf_coherence", gdf_coherence.shape)
    gdf_coherence_distinct = st.session_state.gdf_coherence[['nonov_id', 'geometry'] + excolumns].drop_duplicates().reset_index(drop=True)
    # st.write("gdf_coherence_distinct", gdf_coherence_distinct.shape)
    
    grouped_columns = ['nonov_id', 'MS', 'SPID']

    gdf_grouped = (
        gdf_coherence_distinct
        .groupby(grouped_columns)
        .agg(
            assessed_pos_count=(
                assessment_col,
                lambda x: x.isin(GES_ASSESSED_POS).sum()
            ),
            assessed_neg_count=(
                assessment_col,
                lambda x: x.isin(GES_ASSESSED_NEG).sum()
            ),
            not_assessed=(
                assessment_col,
                lambda x: x.isin(GES_NOT_ASSESSED).sum()
            ),
            geometry=('geometry', 'first')
        )
        .reset_index()
    )

    gdf_grouped = gpd.GeoDataFrame(gdf_grouped, geometry='geometry', crs=gdf_coherence_distinct.crs)
    # st.write("gdf_grouped", gdf_grouped.shape)
    # aggiungo la colonna totale
    gdf_grouped["assessed_count"] = (
            gdf_grouped["assessed_pos_count"] + gdf_grouped["assessed_neg_count"]
        )

    with analysis_header.container():
        print_assessment_info()   
        plot_msp_msfd_sankey()
        plot_treemap()

        if st.session_state.msfdsr_selected_filter == 'Assessment count (assessed)':
            map1_c, map2_c = st.columns([5, 5])
            with map1_c:
                st.write(f"#### Number of {st.session_state.assessment_name} where GES is achieved")
                with _lock:
                    fig, ax = plt.subplots(figsize=[10, 10])
                    ax = gdf_grouped.to_crs(epsg=3857).plot(ax=ax,
                                                            column="assessed_pos_count",
                                                            categorical=True,
                                                            legend=True,
                                                            legend_kwds={"loc": "upper right", "frameon": True},
                                                            cmap="plasma_r",)
                    add_to_plot(ax, gdf_grouped)
                    fig.tight_layout()
                    st.pyplot(fig, width="content")
                    if st.button("Publish", key="publish_assessed_pos_count_map"):
                        publish_result(fig, prefix='msfd_achieved_count')

            with map2_c:
                with _lock:
                    st.write(f"#### Number of {st.session_state.assessment_name} where GES is not achieved")
                    fig, ax = plt.subplots(figsize=[10, 10])
                    ax = gdf_grouped.to_crs(epsg=3857).plot(ax=ax, column="assessed_neg_count",
                                                            categorical=True,
                                                            legend=True,
                                                            legend_kwds={"loc": "upper right", "frameon": True},
                                                            cmap="plasma_r",)
                    add_to_plot(ax, gdf_grouped)
                    fig.tight_layout()
                    st.pyplot(fig, width="content")
                    if st.button("Publish", key="publish_assessed_neg_count_map"):
                        publish_result(fig, prefix='msfd_not_achieved_count')

        if st.session_state.msfdsr_selected_filter == 'Assessment count (not assessed)':
            map1_c, map2_c = st.columns([5, 5])
            with map1_c:
                st.write("#### Number of Feature where GES is not assessed")
                with _lock:
                    fig, ax = plt.subplots(figsize=[10, 10])
                    ax = gdf_grouped.to_crs(epsg=3857).plot(ax=ax,
                                                            column="not_assessed",
                                                            categorical=True,
                                                            legend=True,
                                                            legend_kwds={"loc": "upper right", "frameon": True},
                                                            cmap="plasma_r",)
                    add_to_plot(ax, gdf_grouped)
                    fig.tight_layout()
                    st.pyplot(fig, width="content")
                    if st.button("Publish", key="publish_not_assessed_count_map"):
                        publish_result(fig, prefix='msfd_not_assessed_count')


        if st.session_state.msfdsr_selected_filter == 'Assessment status':

            tab_names = tab_names + ["-"] * (4 - len(tab_names))
            print("TAB NAMES", tab_names)
            map_container_tabs = st.tabs(tab_names)
            for i, tab in enumerate(tab_names):
                tab_name = tab_names[i]
                print("TAB_NAME", tab_name)
                # gdf_ges = st.session_state.gdf_ges
                # gdf_ze = qm.run('ze_geo', mode='gdf')

                with map_container_tabs[i].container():
                    with st.spinner("Wait for it...", show_time=True):
                        map1_c, map2_c = st.columns([5, 5])
                        with map1_c.container():               
                            st.write('### Assessment')
                            if tab_name != '-':
                                print("Plot", tab_name)
                                plot_ges2(gdf_coherence[gdf_coherence[tab_filter_column]==tab_name], assessment_col=assessment_col)
                        with map2_c.container():
                            st.write('### Spatial coherence')
                            if tab_name != '-':
                                print("Plot coherence", tab_name)
                                plot_spatial_coherence(gdf_coherence[gdf_coherence[tab_filter_column]==tab_name])

        st.write("## Assessment data")

        _df = st.session_state.gdf_coherence[excolumns].drop_duplicates().reset_index(drop=True)
        st.dataframe(_df)
            
        cols = ['MS', 'MRU', 'GESComponent', 'Feature', 'GESAchieved',
                # 'DescriptionOverallStatus',
                'Element', 'Parameter',
                # 'ThresholdValueUpper', 'ThresholdValueLower', 'ValueAchievedUpper',
                # 'ValueAchievedLower', 'ValueUnit',
                'geoarea']


@st.fragment
def make_export_section():
    export_container = st.empty()

    with export_container.container():
        if st.button("Export GeoJSON (ZIP)"):
            fparts = ['MSP_MSFD',
                      str(st.session_state.msfdrp_selected_filter),
                      st.session_state.seause_selected_filter[0],
                      st.session_state.assesment_level_selected_filter,
                      st.session_state.components_selected_filter,
                      str(uuid.uuid4())[:4]
                      ]
            fname = '_'.join(fparts)

            with st.spinner("Preparing GeoJSON export... This may take a few seconds."):
                with io.BytesIO() as buffer:
                    with zipfile.ZipFile(buffer, "w") as zipf:
                        export_gdf = st.session_state.gdf_coherence.copy()
                        export_gdf.geometry = export_gdf.geometry.buffer(0)
                        zipf.writestr(f"{fname}.json", export_gdf.to_json())
                        
                    buffer.seek(0)

                    st.download_button(
                        label="Download ZIP file",
                        data=buffer,
                        file_name=f"{fname}.json.zip",
                        mime="application/octet-stream",
                    )

            st.success("GeoJSON export completed successfully.")

    # _gdf = gdf_coherence.copy()
    # _gdf["geometry"] = _gdf["geometry"].representative_point()
    # _gdf = _gdf[_gdf.area_intersection>25]
    # _columns = ['nonov_id', 'MS', 'MRU', 'GESComponent', 'Feature', assessment_col]
    # st.session_state['analysis_geo_results'] = _gdf[_columns + ['geometry']]
    # st.session_state['analysis_geo_results_tooltip'] = _columns

@st.fragment
def make_settings():
    _session_state = {}
    filter_array = []
    filter_array_geoplatform = []

    conf_ze = qmconf.run('ze_distinct')
    conf_aois = qmconf.run('aois', mode='list')
    conf_plans = qmconf.run('plans')

    st.image('https://www.shom.fr/sites/default/files/inline-images/logo_ReMAP_0.png', width=200)

    st.write("###  Settings")

    msfd_reporting_period = [2018,
                             2024]
    msfdrp_selected_filter = st.selectbox("MSFD Reporting period",
                                          options=msfd_reporting_period,
                                          # default=2018,
                                          key="conf_msfdrp_selected_filter",
                                          )
    _session_state['msfdrp_selected_filter'] = msfdrp_selected_filter
    if msfdrp_selected_filter == 2018:
        conf_ges = qmconf.run('ges_distinct')
    elif msfdrp_selected_filter == 2024:
        conf_ges = qmconf.run('ges_2024_distinct')
    
    uc_filter_options = [
        None,
        'Baltic sea use case',
        'North-Western Mediterranean sea use case',
        'Galicia use case',
    ]

    def update_defaults():
        profile_choice = st.session_state.conf_uc_selected_filter
        print("profile_choice", profile_choice)
        if profile_choice is None:
            st.session_state.conf_ms_selected_filter = []
            st.session_state.conf_aoi_selected_filter = None
        elif profile_choice == 'Baltic sea use case':
            st.session_state.conf_ms_selected_filter = ['Denmark', 'Estonia', 'Finland', 'Germany', 'Latvia', 'Lithuania', 'Poland', 'Sweden']
            st.session_state.conf_aoi_selected_filter = 'Baltic sea'
        elif profile_choice == 'North-Western Mediterranean sea use case':
            st.session_state.conf_ms_selected_filter = ['Spain', 'France', 'Italy']
            st.session_state.conf_aoi_selected_filter = 'North-Western Mediterranean Sea PSSA'
        elif profile_choice == 'Galicia use case':
            st.session_state.conf_ms_selected_filter = ['Spain']
            st.session_state.conf_aoi_selected_filter = 'Galicia'

    uc_selected_filter = st.selectbox("Profiles",
                                      key="conf_uc_selected_filter",
                                      options=uc_filter_options,
                                      on_change=update_defaults
                                      )
    # intersezione tra MSP e MSFD
    ms_filter_options = list(set(conf_ze.MS.unique()) & set(conf_ges.MS.unique())) # conf_ze.MS.unique()
    ms_selected_filter = st.multiselect("Member states", options=sorted(ms_filter_options), key="conf_ms_selected_filter", default=["Italy"])
    _session_state['ms_selected_filter'] = ms_selected_filter

    if len(ms_selected_filter) > 0:
        filter_array.append(" or ".join([f"ms LIKE '{ms}'" for ms in ms_selected_filter]))
        # replace value for France
        ms_selected_filter_fr = ['France-MED' if x == 'France' else x for x in ms_selected_filter]
        filter_array_geoplatform.append(" or ".join([f"MS LIKE '{ms}'" for ms in ms_selected_filter_fr]))

    # Spatial plans
    selected_plans = conf_plans[['MS', 'SPID', 'OffTitle']].copy()
    selected_plans.SPID = selected_plans.SPID.replace(map_spid)
    _session_state['selected_plans'] = selected_plans.copy()

   # Area of interest
    aoi_filter_options = conf_aois
    aoi_selected_filter = st.selectbox("Areas of interest / Transboundary areas",
                                       options=aoi_filter_options,
                                       index=None, 
                                       key="conf_aoi_selected_filter")
    _session_state['aoi_selected_filter'] = aoi_selected_filter

    # Sea use
    _gdf = conf_ze
    if len(ms_selected_filter) > 0:
        _gdf = _gdf[_gdf.MS.isin(ms_selected_filter)]

    seause_filter_options = _gdf['Sea use'].unique()
    seause_selected_filter = st.selectbox("MSP Sea use", options=seause_filter_options, key="conf_seause_selected_filter")
    # lo faccio diverntare una lista così poi è uguale all'altra app
    if seause_selected_filter is not None:
        seause_selected_filter = [seause_selected_filter]
    _session_state['seause_selected_filter'] = seause_selected_filter

    if len(seause_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausename = '{_seause}'" for _seause in seause_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseName = '{_seause}'" for _seause in seause_selected_filter]))
        _gdf = _gdf[_gdf['Sea use'].isin(seause_selected_filter)]

    # Function
    function_filter_options = _gdf['Function'].unique()
    function_selected_filter = st.multiselect("MSP Sea use function", options=function_filter_options, key="conf_function_selected_filter")
    _session_state['function_selected_filter'] = function_selected_filter

    if len(function_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausefct = '{_function}'" for _function in function_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseFct = '{_function}'" for _function in function_selected_filter]))
        _gdf = _gdf[_gdf.Function.isin(function_selected_filter)]

    assesment_level = [
        'Overall status',
        'Element status',
        'Criteria status',
        'Parameter results',
    ]
    assesment_level_selected_filter = st.selectbox("MSFD Assessment level",
                                                   options=assesment_level,
                                                   key="conf_assesment_level_selected_filter",
                                                   )
    _session_state['assesment_level_selected_filter'] = assesment_level_selected_filter
    
    #
    if assesment_level_selected_filter == 'Overall status':
        _session_state['assessment_col'] = 'GESAchieved'
        _session_state['assessment_name'] = 'Feature'
        _session_state['assessment_columns_path'] = ['GESComponent', 'Feature', 'GESAchieved']
    elif assesment_level_selected_filter == 'Element status':
        _session_state['assessment_col'] = 'ElementStatus'
        _session_state['assessment_name'] = 'Element'
        _session_state['assessment_columns_path'] = ['GESComponent', 'Feature', 'GESAchieved', 'Element', 'ElementStatus']
    elif assesment_level_selected_filter == 'Parameter results':
        _session_state['assessment_col'] = 'ParameterAchieved'
        _session_state['assessment_name'] = 'Parameter'
        _session_state['assessment_columns_path'] = ['GESComponent', 'Feature', 'GESAchieved', 'Element', 'Parameter', 'ParameterAchieved']
    elif assesment_level_selected_filter == 'Criteria status':
        _session_state['assessment_col'] = 'CriteriaStatus'    
        _session_state['assessment_name'] = 'Criteria'
        _session_state['assessment_columns_path'] = ['GESComponent', 'Feature', 'GESAchieved', 'Element', 'Criteria', 'CriteriaStatus']

    _session_state['assessment_columns'] = ['GESComponent', 'Feature', 'GESAchieved']
    if assesment_level_selected_filter in ['Element status', 'Criteria status', 'Parameter results']:
        _session_state['assessment_columns'] += ['Element', 'Element2', 'ElementStatus', 'DescriptionElement',]

    if assesment_level_selected_filter in ['Criteria status', 'Parameter results']:
        _session_state['assessment_columns'] += ['Criteria', 'CriteriaStatus',]

    if assesment_level_selected_filter in ['Parameter results']:
        _session_state['assessment_columns'] += ['Parameter', 'ParameterOther', 'ThresholdValueUpper',
                      'ThresholdValueLower', 'ThresholdQualitative',
                      'ThresholdValueSource', 'ValueAchievedUpper',
                      'ValueAchievedLower', 'ValueUnit',
                      'ValueUnitOther', 'Trend', 'ParameterAchieved',
                      ]
    
        
    df_ges_copy = conf_ges.copy()

    # append filter on MS
    if len(ms_selected_filter) > 0:
        # _filter = gdf_ges['Country_x'].isin(ms_selected_filter)
        _filter = df_ges_copy['MS'].isin(ms_selected_filter)
        _gdf = _gdf[_gdf['MS'].isin(ms_selected_filter)]
    else:
        _filter = [True] * len(df_ges_copy.index)
    # if assesment_level_selected_filter == 'Overall status':

    if msfdrp_selected_filter == 2024:
        components = df_ges_copy[_filter]['GESComponent'].replace(GES_DESCRIPTORS_2024).sort_values().unique()
    else:
        components = df_ges_copy[_filter]['GESComponent'].sort_values().unique()

    components_selected_filter = st.selectbox("MSFD GES Component",
                                              options=components,
                                              key="conf_components_selected_filter",
                                              # index=None
                                              )
    if msfdrp_selected_filter == 2024:
        components_selected_filter = next(k for k, v in GES_DESCRIPTORS_2024.items() if v == components_selected_filter)
    _session_state['components_selected_filter'] = components_selected_filter
        
    _filter = (_filter) & (df_ges_copy['GESComponent'] == components_selected_filter)
    features = df_ges_copy[_filter]["Feature"].unique()
    if len(features) == 0:
        features = None
    else:
        features = [features[0]]
    features_selected_filter = st.multiselect("MSFD Feature",
                                              options=features,
                                              key="conf_features_selected_filter",
                                              default=features,
                                            )
    _session_state['features_selected_filter'] = features_selected_filter

    if len(features_selected_filter) > 0:
        _filter = (_filter) & (df_ges_copy['Feature'].isin(features_selected_filter))
    
    if assesment_level_selected_filter in ('Element status', 'Criteria status', 'Parameter results'):
            print("#############################")
            print("Elements")
            elements = df_ges_copy[_filter]["Element"].dropna().unique()
            if elements is None:
                elements = []

            print(elements)
            elements_selected_filter = st.multiselect("MSFD Element",
                                                      options=elements,
                                                      key="conf_elements_selected_filter",
                                                      # default=[elements[0]]
                                                    )
            _session_state['elements_selected_filter'] = elements_selected_filter
    
            if len(elements_selected_filter) > 0:
                _filter = (_filter) & (df_ges_copy['Element'].isin(elements_selected_filter))
    else:
        _session_state['elements_selected_filter'] = [] # default for caching

    if assesment_level_selected_filter in ('Criteria status'):
            criteria = df_ges_copy[_filter]["Criteria"].unique()
            criteria = [CRITERIAS.get(c) for c in criteria]
            _criteria_selected_filter = st.multiselect("MSFD Criteria",
                                                      options=criteria,
                                                      key="conf_criteria_selected_filter",
                                                      # default=[criteria[0]]
                                                      )
            criteria_selected_filter = [CRITERIAS_R.get(_c) for _c in _criteria_selected_filter]
            _session_state['criteria_selected_filter'] = criteria_selected_filter
            _filter = (_filter) & (df_ges_copy['Criteria'].isin(criteria_selected_filter))
    else:
        _session_state['criteria_selected_filter'] = [] # default for caching

    if assesment_level_selected_filter in ('Parameter results'):
            parameters = df_ges_copy[_filter]["Parameter"].unique()
            parameters_selected_filter = st.multiselect("MSFD Parameter",
                                                    options=parameters,
                                                        key="conf_parameters_selected_filter",
                                                        # default=[parameter[0]]
                                                    )
            _session_state['parameters_selected_filter'] = parameters_selected_filter
            _filter = (_filter) & (df_ges_copy['Parameter'].isin(parameters_selected_filter))
    else:
        _session_state['parameters_selected_filter'] = [] # default for caching

    # add parenthesis
    filter_array = [f"({_f})" for _f in filter_array]
    filter_query = " and ".join(filter_array)

    filter_array_geoplatform = [f"({_f})" for _f in filter_array_geoplatform]
    filter_query_geoplatform = " and ".join(filter_array_geoplatform)

    
    _session_state['filter_query'] = filter_query
    _session_state['filter_query_geoplatform'] = filter_query_geoplatform

    msfd_spatial_representation = ["Assessment status",
                                   "Assessment count (assessed)",
                                   "Assessment count (not assessed)",
                                   ]
    msfdsr_selected_filter = st.selectbox("Spatial representation",
                                          options=msfd_spatial_representation,
                                          index=0,
                                          key="conf_msfdsr_selected_filter",
                                          )
    _session_state['msfdsr_selected_filter'] = msfdsr_selected_filter

    if check_pageload('msp_msfd'):
        for k, v in _session_state.items():
            st.session_state[k] = v
    
    # st.button("Process", on_click=filter_data)
    if st.button("Process"):
        for k, v in _session_state.items():
            st.session_state[k] = v
        first_analysis = False
        st.rerun()


    
with st.sidebar:
    make_settings()

with st.spinner("Wait for it...", show_time=True):
    set_map_state()
    make_map(qm, GES)
    make_analysis()
    make_export_section()
