"""
Esempio pratico di utilizzo del sistema di ruoli e permessi nelle pagine.
Questo file mostra diversi pattern di implementazione.
"""

import streamlit as st
from auth import (
    require_app_login,
    get_current_user_role, 
    has_permission,
    is_admin,
    require_permission,
    require_admin,
    Permission,
    UserRole,
    show_user_badge
)

# ═══════════════════════════════════════════════════════════════
# SETUP PAGINA
# ═══════════════════════════════════════════════════════════════

st.set_page_config(page_title="RBAC Example", layout="wide")

# Guard: richiede login
require_app_login()

# ═══════════════════════════════════════════════════════════════
# PATTERN 1: CHECK PERMISSION E MOSTRARE/NASCONDERE ELEMENTI UI
# ═══════════════════════════════════════════════════════════════

st.title("🔐 Role-Based Access Control - Examples")

# Mostra il badge utente
show_user_badge()

st.markdown("---")

# Get current user info
username = st.session_state.get("username", "Unknown")
role = get_current_user_role()

st.write(f"### Welcome, {username}!")
st.write(f"**Your role:** {role.value if role else 'Unknown'}")

st.markdown("---")

# ───────────────────────────────────────────────────────────────
# ESEMPIO 1: Pubblicazione con logica condizionale
# ───────────────────────────────────────────────────────────────

st.subheader("📤 Data Publishing")

col1, col2 = st.columns(2)

with col1:
    st.write("#### Prepare Data")
    data_to_publish = st.text_area(
        "Enter data to publish",
        placeholder="Your research data here...",
        height=150
    )

with col2:
    st.write("#### Publishing Options")
    
    # Admin: pubblicazione diretta
    if has_permission(Permission.PUBLISH_DIRECT):
        st.success("✅ You have DIRECT publishing rights")
        
        if st.button("🚀 Publish Now", type="primary"):
            st.success("✅ Data published successfully!")
            st.balloons()
    
    # Altri utenti: richiesta di pubblicazione
    elif has_permission(Permission.PUBLISH_REQUEST):
        st.info("📋 You can request publication approval")
        
        if st.button("📨 Request Publication"):
            st.success("✅ Publication request sent to admin for approval")
            st.info("You will be notified when approved")
    
    # Utenti senza permessi
    else:
        st.warning("🚫 You don't have publishing permissions")
        st.write("Contact an administrator to request access")

st.markdown("---")

# ───────────────────────────────────────────────────────────────
# ESEMPIO 2: Download con permessi
# ───────────────────────────────────────────────────────────────

st.subheader("💾 Data Download")

# Check download permission
if has_permission(Permission.DOWNLOAD_DATA):
    st.success("✅ You can download data")
    
    if st.button("⬇️ Download Dataset"):
        st.success("Downloaded: sample_dataset.csv")
else:
    st.error("🚫 Download not available for your role")
    st.info("Demo users cannot download data. Please create an account.")

st.markdown("---")

# ───────────────────────────────────────────────────────────────
# ESEMPIO 3: Sezione Admin Only
# ───────────────────────────────────────────────────────────────

st.subheader("⚙️ Administration")

if is_admin():
    st.success("👑 Admin Panel - Full Access")
    
    with st.expander("🔧 Admin Tools", expanded=True):
        col_a1, col_a2, col_a3 = st.columns(3)
        
        with col_a1:
            if st.button("👥 Manage Users"):
                st.info("User management interface would open here")
        
        with col_a2:
            if st.button("📊 View Logs"):
                st.info("System logs interface would open here")
        
        with col_a3:
            if st.button("⚙️ System Config"):
                st.info("System configuration interface would open here")
    
    # Lista di tutti gli utenti con i loro ruoli
    with st.expander("👥 User Roles Overview", expanded=True):
        from auth import get_all_users, update_user_role
        from auth.roles import get_role_display_name
        import pandas as pd
        
        users = get_all_users()
        
        # Create dataframe
        user_data = []
        for username, full_name, email, role, created_at in users:
            role_display = get_role_display_name(UserRole(role))
            user_data.append({
                "Username": username,
                "Full Name": full_name,
                "Email": email,
                "Role": role,
                "Display": role_display,
                "Created": created_at[:10] if created_at else ""
            })
        
        df = pd.DataFrame(user_data)
        st.dataframe(df[["Username", "Full Name", "Role", "Display"]], 
                     use_container_width=True, hide_index=True)
        
        # Role modification section
        st.markdown("#### 🔧 Modify User Role")
        col_mod1, col_mod2, col_mod3 = st.columns([2, 2, 1])
        
        with col_mod1:
            selected_user = st.selectbox(
                "Select User",
                options=[u["Username"] for u in user_data],
                key="role_mod_user"
            )
        
        with col_mod2:
            new_role = st.selectbox(
                "New Role",
                options=["admin", "scientist", "researcher", "analyst", "guest", "demo"],
                key="role_mod_role"
            )
        
        with col_mod3:
            st.write("")  # Spacer
            st.write("")  # Spacer
            if st.button("💾 Update", type="primary"):
                if update_user_role(selected_user, new_role):
                    st.success(f"✅ Updated {selected_user} to {new_role}")
                    st.rerun()
                else:
                    st.error("❌ Failed to update role")
else:
    st.warning("🚫 Admin panel access restricted")
    st.info("Only administrators can access this section")

st.markdown("---")

# ───────────────────────────────────────────────────────────────
# ESEMPIO 4: Tabella permessi per ruolo corrente
# ───────────────────────────────────────────────────────────────

st.subheader("🔑 Your Permissions Matrix")

if role:
    from auth.roles import ROLE_PERMISSIONS
    
    perms = ROLE_PERMISSIONS.get(role, [])
    
    st.write(f"As a **{role.value}**, you have access to:")
    
    # Create permission table
    perm_data = {
        "Permission": [p.value.replace('_', ' ').title() for p in perms],
        "Status": ["✅" for _ in perms]
    }
    
    import pandas as pd
    df = pd.DataFrame(perm_data)
    st.dataframe(df, use_container_width=True, hide_index=True)
    
    # Show what you DON'T have
    all_perms = set(Permission)
    missing_perms = all_perms - set(perms)
    
    if missing_perms:
        with st.expander("❌ Permissions you don't have"):
            for perm in missing_perms:
                st.write(f"- {perm.value.replace('_', ' ').title()}")

st.markdown("---")

# ───────────────────────────────────────────────────────────────
# INFO BOX: Come usare questi pattern
# ───────────────────────────────────────────────────────────────

with st.expander("📖 How to use RBAC in your pages"):
    st.markdown("""
    ### Quick Reference
    
    #### 1. Import necessari
    ```python
    from auth import (
        require_app_login,
        has_permission, 
        is_admin,
        Permission
    )
    ```
    
    #### 2. Pattern comuni
    
    **Check permission e mostrare/nascondere UI:**
    ```python
    if has_permission(Permission.PUBLISH_DIRECT):
        st.button("🚀 Publish Now")
    else:
        st.warning("No publishing rights")
    ```
    
    **Guard function (blocca esecuzione):**
    ```python
    from auth import require_permission
    
    # All'inizio della funzione/pagina
    require_permission(Permission.UPLOAD_DATA)
    # Se l'utente non ha il permesso, l'esecuzione si ferma qui
    ```
    
    **Check admin:**
    ```python
    if is_admin():
        # Mostra pannello admin
        pass
    ```
    
    **Get current role:**
    ```python
    from auth import get_current_user_role, UserRole
    
    role = get_current_user_role()
    if role == UserRole.SCIENTIST:
        # Logica specifica per scientist
        pass
    ```
    
    #### 3. Permessi disponibili
    
    - `Permission.VIEW_DATA` - Visualizzare dati
    - `Permission.DOWNLOAD_DATA` - Scaricare dati
    - `Permission.UPLOAD_DATA` - Caricare dati
    - `Permission.DELETE_DATA` - Eliminare dati
    - `Permission.PUBLISH_DIRECT` - Pubblicare senza approvazione (solo admin)
    - `Permission.PUBLISH_REQUEST` - Richiedere pubblicazione
    - `Permission.MANAGE_USERS` - Gestire utenti
    - `Permission.VIEW_LOGS` - Visualizzare log
    - `Permission.SYSTEM_CONFIG` - Configurare sistema
    
    #### 4. Ruoli disponibili
    
    - `UserRole.ADMIN` - Tutti i permessi
    - `UserRole.SCIENTIST` - Visualizzare, scaricare, caricare, richiedere pubblicazione
    - `UserRole.RESEARCHER` - Come scientist
    - `UserRole.ANALYST` - Visualizzare, scaricare, richiedere pubblicazione
    - `UserRole.GUEST` - Solo visualizzare e scaricare
    - `UserRole.DEMO` - Solo visualizzare (no download)
    """)
