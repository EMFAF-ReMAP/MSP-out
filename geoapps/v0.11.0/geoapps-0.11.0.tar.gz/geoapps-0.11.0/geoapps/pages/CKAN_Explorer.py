import sys, pathlib
from collections import defaultdict
import pandas as pd
import streamlit as st

from folium import Map, TileLayer
from folium.plugins import Draw
from streamlit_folium import st_folium
from shapely.geometry import box


st.set_page_config(page_title="CKAN Spatial Filter", layout="wide")

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from core import domain_areas, datasets, filters, map_utils, bar_charts
from auth.auth import  is_logged_in, get_current_user, auto_logout_check, logout_user
from tools.utils import make_header

import pickle
import json

from auth.access_guard import require_app_login

require_app_login()  # redirect se non loggato

DOMAIN_AREAS_GRID_PATH = "geoapps_storage/domain_area_grid.pkl"
MAP_VIEWS = ["Domain map", "Raster grid"]  # Grid map kept in code but not selectable

# ───────────── Authentication Check ─────────────
# Check for auto-logout before any other operations
auto_logout_check()

# ───────────── Sidebar Header ─────────────
make_header()

# ─────────── Healthcheck ───────────
if "healthcheck" in st.query_params:
    st.write("ok")
    st.stop()

# ─────────── Static data ───────────
@st.cache_data(ttl=24 * 60 * 60)
def load_static():
    da_df = domain_areas.load_domain_areas()
    da_lbl, da_id, da_slug = domain_areas.build_lookups(da_df)
    cluster_structure = datasets.parse_cluster_structure()
    return da_df, da_lbl, da_id, da_slug, cluster_structure

da_df, DA_BY_LABEL, DA_BY_ID, DA_BY_SLUG, cluster_structure = load_static()

# ─────────── Organization ───────────
org_opts = ["All"] + datasets.fetch_orgs()
sel_org = st.sidebar.selectbox("Organization", org_opts, index=0)
org_id = None if sel_org == "All" else sel_org

# ─────────── Cluster/Class/Sub filters ───────────
sel_cluster, sel_class, sel_sub = filters.sidebar_filters(cluster_structure)



# ─────────── Dialog for Map Selection ───────────
@st.dialog("Map Selection")
def map_selection_dialog():
    """Dialog for domain areas selection via map"""
    
    # Add CSS to fix layout issues in dialog
    st.markdown("""
        <style>
        .stDialog .element-container {
            margin-bottom: 0.5rem !important;
        }
        .stDialog iframe {
            margin-bottom: 0 !important;
            margin-top: 0 !important;
        }
        .stDialog .stContainer {
            padding: 0 !important;
        }
        div[data-testid="stVerticalBlock"] > div {
            gap: 0.5rem !important;
        }
        </style>
    """, unsafe_allow_html=True)
    
    st.markdown("### Select areas by drawing on the map")
    
    # Spatial mode selection before the map
    spatial_mode = st.radio(
        "Spatial rule", 
        ["intersect", "contain"], 
        horizontal=True,
        key="spatial_mode_dialog"
    )

    smap = Map(location=[43, 12], zoom_start=4)
    TileLayer("CartoDB positron", control=False).add_to(smap)
    Draw(
        export=False,
        draw_options={"polyline": False, "circle": False, "marker": False, "circlemarker": False}
    ).add_to(smap)

    # Use a container with explicit spacing to better control the map layout
    col1, col2, col3 = st.columns([1, 8, 1])
    with col2:
        draw_res = st_folium(
            smap, 
            height=350, 
            width=550, 
            key="dialog_map", 
            returned_objects=["all_drawings"],
            feature_group_to_add=None,
            use_container_width=False
        )
    
    # Calculate selected areas
    selected_areas_map = []
    draw_geom = None
    
    # Check if we have any drawings and they're not from a reset
    has_drawings = (draw_res and 
                   draw_res["all_drawings"] and 
                   len(draw_res["all_drawings"]) > 0)
    
    if has_drawings:
        geojson = draw_res["all_drawings"][-1]["geometry"]
        if geojson["type"] == "Polygon":
            xs, ys = zip(*geojson["coordinates"][0])
            draw_geom = box(min(xs), min(ys), max(xs), max(ys))

    for da, row in DA_BY_LABEL.items():
        bb = row["bbox"]
        if draw_geom:
            if spatial_mode == "intersect" and not bb.intersects(draw_geom):
                continue
            if spatial_mode == "contain" and not draw_geom.contains(bb):
                continue
        selected_areas_map.append(da)
    
    # Show selected areas
    if draw_geom and selected_areas_map:
        st.markdown("### Selected areas:")
        st.write(f"**{len(selected_areas_map)} areas found**")
        with st.expander("Show areas"):
            for area in sorted(selected_areas_map):
                st.write(f"• {area}")
    elif draw_geom and not selected_areas_map:
        st.warning("No areas found in the drawn geometry")
    else:
        st.info("Draw an area on the map to select domain areas")
    
    col1, col2 = st.columns(2)
    
    if col1.button("Apply Selection", type="primary", use_container_width=True):
        st.session_state.map_selected_areas = selected_areas_map
        st.session_state.selection_confirmed = True
        st.rerun()
    
    if col2.button("Cancel", use_container_width=True):
        st.session_state.selection_confirmed = False
        st.rerun()

# ─────────── Domain Area selection mode ───────────
st.sidebar.markdown("### Domain Area Selection")
selection_mode = st.sidebar.radio("Selection mode", ["List view", "Map view"], horizontal=True, key="da_mode")

selected_areas = []

if selection_mode == "List view":
    all_domain_areas = sorted(DA_BY_LABEL.keys())
    da_options = ["All"] + all_domain_areas

    # Reset selection if mode changes
    if "selected_das" not in st.session_state:
        st.session_state.selected_das = ["All"]
    
    # Reset map selection if mode changes
    if st.session_state.get("last_mode") != "List view":
        st.session_state.map_selected_areas = []
        st.session_state.selection_confirmed = False
    
    st.session_state.last_mode = "List view"

    selected_das = st.sidebar.multiselect(
        "Domain Areas", 
        options=da_options,
        default=st.session_state.selected_das,
        key="da_dropdown",
        label_visibility="collapsed"
    )

    # Logic: if you select something that is not "All", remove "All"
    if "All" in selected_das and len(selected_das) > 1:
        selected_das = [d for d in selected_das if d != "All"]

    # If you deselect everything, put back "All"
    if not selected_das:
        selected_das = ["All"]

    # Set actually selected areas
    selected_areas = all_domain_areas if "All" in selected_das else selected_das
    st.session_state.selected_das = selected_das

elif selection_mode == "Map view":
    st.session_state.last_mode = "Map view"
    
    # Initialize state variables if they don't exist
    if "map_selected_areas" not in st.session_state:
        st.session_state.map_selected_areas = []
    if "selection_confirmed" not in st.session_state:
        st.session_state.selection_confirmed = False
    
    # Button to open dialog
    if st.sidebar.button("🗺️ Open Map for Selection", use_container_width=True):
        map_selection_dialog()
    
    # Show current selection status
    if st.session_state.selection_confirmed and st.session_state.map_selected_areas:
        st.sidebar.success(f"✅ {len(st.session_state.map_selected_areas)} areas selected")
        selected_areas = st.session_state.map_selected_areas
        
        # Show preview of selected areas
        with st.sidebar.expander("Selected areas"):
            for area in sorted(st.session_state.map_selected_areas[:5]):  # Show only first 5
                st.write(f"• {area}")
            if len(st.session_state.map_selected_areas) > 5:
                st.write(f"... and {len(st.session_state.map_selected_areas) - 5} others")
                
        # Button to reset selection
        if st.sidebar.button("🗑️ Reset Selection"):
            st.session_state.map_selected_areas = []
            st.session_state.selection_confirmed = False
            st.rerun()
    else:
        st.sidebar.info("No area selected from map")
        selected_areas = []

# ─────────── Apply Filters ───────────
if "filter_applied" not in st.session_state:
    st.session_state.filter_applied = False

def apply_sidebar_filters():
    st.session_state.filter_values = {
        "org": sel_org,
        "cluster": sel_cluster,
        "class": sel_class,
        "subclass": sel_sub,
        "search_text": "",
        "selected_areas": selected_areas,
    }
    st.session_state.filter_applied = True

if st.sidebar.button("Search", key="apply_btn"):
    apply_sidebar_filters()
    st.session_state.current_page = 1

if not st.session_state.filter_applied:
    st.stop()

# ─────────── Load & Filter Datasets ───────────
@st.cache_data(ttl=6 * 60 * 60)
def load_datasets(org_id_):
    return datasets.fetch_datasets(
        org_id_,
        cluster_structure,
        lambda v: domain_areas.to_label(v, DA_BY_LABEL, DA_BY_ID, DA_BY_SLUG),
    )

datasets_dict_full = load_datasets(org_id)

@st.cache_data
def apply_all_filters(dset_full, filt_vals):
    dset = {
        k: v for k, v in dset_full.items()
        if not filt_vals["selected_areas"]
        or any(d in filt_vals["selected_areas"] for d in v["domain_areas"])
    }
    rows = []
    for ds_id, d in dset.items():
        cats = d["categories"]
        if not cats:
            rows.append({"dataset_id": ds_id, "title": d["title"], "cluster": None, "class_": None, "subclass": None})
        else:
            for clu, cls, sub in cats:
                rows.append({
                    "dataset_id": ds_id, "title": d["title"],
                    "cluster": clu, "class_": cls, "subclass": sub
                })
    df_long = pd.DataFrame(rows)
    df_long = filters.apply_filters(
        df_long,
        filt_vals["cluster"], filt_vals["class"],
        filt_vals["subclass"], filt_vals["search_text"]
    )
    return df_long, dset

filter_vals = st.session_state.filter_values
df_long, datasets_dict = apply_all_filters(datasets_dict_full, filter_vals)

if df_long.empty:
    st.warning("No datasets match current filters.")
    st.stop()

# ─────────── Tabs ───────────
tab_charts, tab_map, tab_dset = st.tabs(["📊 Charts", "🗺️ Map", "📦 Datasets"])

with tab_charts:
    # Chart type selector
    chart_type = st.selectbox(
        "Chart library", 
        ["Plotly", "Vega-Lite"], 
        index=0,
        key="chart_type_selector"
    )
    
    clusters = sorted(cluster_structure.keys(), key=str.lower)
    
    if chart_type == "Plotly":
        bar_charts.bar(clusters, df_long.groupby("cluster")["dataset_id"].nunique(), "Datasets per Cluster", "royalblue")
        
        if filter_vals["cluster"] != "All":
            classes = sorted(cluster_structure[filter_vals["cluster"]].keys(), key=str.lower)
            class_counts = df_long[df_long.cluster == filter_vals["cluster"]].groupby("class_")["dataset_id"].nunique()
            bar_charts.bar(classes, class_counts, f"Classes in '{filter_vals['cluster']}'", "teal")

            if filter_vals["class"] != "All":
                subs = sorted(cluster_structure[filter_vals["cluster"]][filter_vals["class"]], key=str.lower)
                sub_counts = df_long[
                    (df_long.cluster == filter_vals["cluster"]) & (df_long.class_ == filter_vals["class"])
                ].groupby("subclass")["dataset_id"].nunique()
                bar_charts.bar(subs, sub_counts, f"Subclasses in '{filter_vals['class']}'", "seagreen")
    
    else:  # Vega-Lite
        bar_charts.vega_bar(clusters, df_long.groupby("cluster")["dataset_id"].nunique(), "Datasets per Cluster", "steelblue")

        if filter_vals["cluster"] != "All":
            classes = sorted(cluster_structure[filter_vals["cluster"]].keys(), key=str.lower)
            class_counts = df_long[df_long.cluster == filter_vals["cluster"]].groupby("class_")["dataset_id"].nunique()
            bar_charts.vega_bar(classes, class_counts, f"Classes in '{filter_vals['cluster']}'", "orange")

            if filter_vals["class"] != "All":
                subs = sorted(cluster_structure[filter_vals["cluster"]][filter_vals["class"]], key=str.lower)
                sub_counts = df_long[
                    (df_long.cluster == filter_vals["cluster"]) & (df_long.class_ == filter_vals["class"])
                ].groupby("subclass")["dataset_id"].nunique()
                bar_charts.vega_bar(subs, sub_counts, f"Subclasses in '{filter_vals['class']}'", "green")

with tab_map:
    # ─────────── Map view selection dentro la tab ───────────
    map_view = st.selectbox("Map visualization", MAP_VIEWS, index=0, key="map_view_tab")
    
    sel_areas = filter_vals["selected_areas"]
    da_counts_filtered = defaultdict(set)
    for ds_id in df_long["dataset_id"].unique():
        for da in datasets_dict[ds_id]["domain_areas"]:
            if not sel_areas or da in sel_areas:
                da_counts_filtered[da].add(ds_id)
    da_counts_filtered = {k: len(v) for k, v in da_counts_filtered.items()}
    
    # Create a filtered datasets_dict containing only datasets that pass the filters
    filtered_dataset_ids = set(df_long["dataset_id"].unique())
    datasets_dict_filtered = {
        ds_id: ds_info for ds_id, ds_info in datasets_dict.items() 
        if ds_id in filtered_dataset_ids
    }
    
    if map_view == "Grid map":
        map_utils.draw_grid_map(DOMAIN_AREAS_GRID_PATH, datasets_dict_filtered)
    elif map_view == "Raster grid":
        map_utils.draw_grid_raster(DOMAIN_AREAS_GRID_PATH, datasets_dict_filtered)
    else:
        map_utils.draw_domain_map(da_counts_filtered, DA_BY_LABEL)

with tab_dset:
    # ─────────── Paginazione migliorata ───────────
    PAGE_SIZE = 20
    total_items = len(df_long["dataset_id"].unique())
    total_pages = (total_items - 1) // PAGE_SIZE + 1
    if "current_page" not in st.session_state:
        st.session_state.current_page = 1

    start_idx = (st.session_state.current_page - 1) * PAGE_SIZE
    end_idx = start_idx + PAGE_SIZE
    paged_ids = list(df_long["dataset_id"].unique())[start_idx:end_idx]

    st.markdown("### Datasets")
    for ds_id in paged_ids:
        info = datasets_dict[ds_id]
        st.markdown("---")
        st.markdown(f"#### **{info['title']}**")
        st.markdown(f"**Domain areas:** {', '.join(info['domain_areas']) or '—'}")
        if info["url"]:
            st.markdown(f"**URL:** [{info['url']}]({info['url']})")
        with st.expander(f"Categories ({len(info['categories'])})"):
            if not info["categories"]:
                st.markdown("— No categories —")
            else:
                for clu, cls, sub in info["categories"]:
                    st.markdown(f"- **Cluster:** {clu or '—'} | **Class:** {cls or '—'} | **Subclass:** {sub or '—'}")

    # ─────────── Improved pagination controls ───────────
    if total_pages > 1:
        st.markdown("---")
        
        # Pagination information
        start_item = start_idx + 1
        end_item = min(end_idx, total_items)
        st.markdown(f"**Showing {start_item}-{end_item} of {total_items} datasets**")
        
        # Pagination controls layout
        col1, col2, col3, col4, col5 = st.columns([1, 1, 3, 1, 1])
        
        # First Page Button
        with col1:
            if st.button("⏮️ First", disabled=(st.session_state.current_page == 1), use_container_width=True):
                st.session_state.current_page = 1
                st.rerun()
        
        # Pulsante Pagina Precedente
        with col2:
            if st.button("◀️ Prev", disabled=(st.session_state.current_page == 1), use_container_width=True):
                st.session_state.current_page -= 1
                st.rerun()
        
        # Direct page selection (center column)
        with col3:
            # Show some pages around the current one
            current = st.session_state.current_page
            
            # Calculate page range to display
            window = 3  # Show 3 pages before and after current one
            start_page = max(1, current - window)
            end_page = min(total_pages, current + window)
            
            # If at the beginning, show more pages to the right
            if start_page == 1:
                end_page = min(total_pages, start_page + 2 * window)
            
            # If at the end, show more pages to the left
            if end_page == total_pages:
                start_page = max(1, end_page - 2 * window)
            
            page_cols = st.columns(min(7, end_page - start_page + 1))
            
            # Show "..." if we don't start from page 1
            col_idx = 0
            if start_page > 1:
                if page_cols[col_idx].button("1", key="page_1_jump"):
                    st.session_state.current_page = 1
                    st.rerun()
                col_idx += 1
                if col_idx < len(page_cols) and start_page > 2:
                    page_cols[col_idx].write("...")
                    col_idx += 1
            
            # Show pages in range
            for page in range(start_page, min(end_page + 1, len(page_cols) - col_idx + start_page)):
                if col_idx < len(page_cols):
                    is_current = page == current
                    
                    # Create button parameters
                    button_params = {
                        "label": f"{page}",
                        "key": f"page_{page}",
                        "disabled": is_current,
                        "use_container_width": True
                    }
                    
                    # Add type only if page is current
                    if is_current:
                        button_params["type"] = "primary"
                    
                    if page_cols[col_idx].button(**button_params):
                        st.session_state.current_page = page
                        st.rerun()
                    col_idx += 1
            
            # Mostra "..." se non arriviamo all'ultima pagina
            if end_page < total_pages and col_idx < len(page_cols):
                if end_page < total_pages - 1:
                    page_cols[col_idx].write("...")
                    col_idx += 1
                if col_idx < len(page_cols):
                    if page_cols[col_idx].button(f"{total_pages}", key=f"page_{total_pages}_jump"):
                        st.session_state.current_page = total_pages
                        st.rerun()
        
        # Pulsante Pagina Successiva
        with col4:
            if st.button("Next ▶️", disabled=(st.session_state.current_page == total_pages), use_container_width=True):
                st.session_state.current_page += 1
                st.rerun()
        
        # Pulsante Ultima Pagina
        with col5:
            if st.button("Last ⏭️", disabled=(st.session_state.current_page == total_pages), use_container_width=True):
                st.session_state.current_page = total_pages
                st.rerun()
        
        # Direct input to jump to specific page
        st.markdown("")
        col_jump1, col_jump2, col_jump3 = st.columns([2, 1, 2])
        with col_jump2:
            jump_page = st.number_input(
                "Go to page:",
                min_value=1,
                max_value=total_pages,
                value=st.session_state.current_page,
                key="jump_to_page"
            )
            if st.button("Go", use_container_width=True):
                st.session_state.current_page = int(jump_page)
                st.rerun()
    else:
        st.write(f"Total datasets: {total_items}")