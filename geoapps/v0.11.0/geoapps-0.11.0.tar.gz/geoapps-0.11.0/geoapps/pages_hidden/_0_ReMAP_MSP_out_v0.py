from matplotlib import pyplot as plt
from matplotlib.backends.backend_agg import RendererAgg
from time import sleep

import streamlit as st
import geopandas as gpd
import pydeck as pdk
import streamlit as st
import pandas as pd
import copy
import numpy as np

import streamlit as st
import folium
from streamlit_folium import st_folium
from streamlit.components.v1 import html
from branca.element import Element
from tools.utils import make_login, make_header, set_sankey_data
import plotly.express as px
import plotly.graph_objects as go

import seaborn as sns
import numpy as np
from upsetplot import from_memberships, UpSet

from auth.access_guard import require_app_login

require_app_login(home_page="streamlit_app_demo.py")  # redirect se non loggato

from tools.importer import *
datasets = Datasets()

# Page config removed - handled by main app

explanations = {

"Zoning Elements":
"""According to EMODnet, Zoning Elements (ZEs) are spatial objects,
part of a spatial plan, defining activities and uses in a specific
area. This analysis offers insights on the number of ZEs, and the
relative Disjoint Index""",
"n_ze":
"""The graph and table display the number of Zoning Elements for each
country or spatial plan, as present in EMODnet.""",
"disjoint":
"""The graph and table display the Disjoint Index for each country or
spatial plan. The Disjoint Index ranges from 0 to 1, where 0 indicates
perfect overlapping between Zoning Elements, while 1 indicated absence
of overlapping.""",

"Sea use":
"""This analysis offers a visual idea of which activities are present
or absent in a plan, and their relative spatial coverage.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.  """,

"Sea use & Function":
"""This analysis offers an overview of the Sea uses present in a plan,
and their relative Functions.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.

Another Zoning Elements’ attribute can be the Function, describing the
regulatory framework of a given activity in the area. The model
provides six possible Functions:

* Reserved: areas specifically designated for the development of certain activities 
* Priority: activities with precedence over any other 
* Allowed: activities with permission to be developed 
* Potential: activities that could be developed according to the characteristics of the area 
* Restricted: specific activities that can not be carried out in a given area 
* Forbidden: activities that cannot be developed according to the plan 

The Function Undefined was added by the module developers to cover
those Zoning Elements that were missing the Function attribute.  """,

"Multi-source overlay":
"""This analysis adds European-wide geospatial layers, such as
bathymetry and vessel density, to offer a comprehensive understanding
of the maritime context.  """
                }

make_header()
# make_login()

aois = datasets.load_aoi()
plans = datasets.load_plans()
plans['SPID_ORIG'] = plans.SPID
plans.SPID = plans.SPID.replace(map_spid)

gdf_ze = datasets.load_ze()
# remove undefined sea uses
# gdf_ze['Sea use'] = gdf_ze["Sea use"].fillna('Undefined').values
gdf_ze = gdf_ze.dropna(subset=["Sea use"])
gdf_ze.SPID = gdf_ze.SPID.replace(map_spid)
gdf_ze['Function'] = gdf_ze["Function"].replace(' ', 'Undefined')

# print(gdf_ze.Function.unique())

coverage = datasets.load_coverage()
coverage.SPID = coverage.SPID.replace(map_spid)

coverage_stats = datasets.load_coverage_stats()

gdf_uf = coverage[['MS', 'SPID', 'geoarea', 'use_function', 'geometry']].explode('use_function')
split = pd.DataFrame(gdf_uf['use_function'].to_list(), columns = ['Sea use', 'Function'])
# removing undefined sea uses
# gdf_uf['Sea use'] = split["Sea use"].fillna('Undefined').values
gdf_uf['Sea use'] = split["Sea use"].values

gdf_uf['Function'] = split["Function"].fillna('Undefined').values
gdf_uf['Sea use'] = gdf_uf['Sea use'].replace('Aquaculture (include algae)', 'Aquaculture')

# removing undefined sea uses
gdf_uf = gdf_uf.dropna(subset=["Sea use"])

# questo non dipende dal filtro e da la copertura per stato membro o SPID senza i boundaries
_coverage_noboundaries = gdf_uf[gdf_uf['Sea use'] != 'Boundaries']
_coverage_noboundaries = _coverage_noboundaries[~_coverage_noboundaries.index.duplicated()]

# Initialize the Streamlit app
# Initialize session state for map position and zoom level
def set_map_state():
    if not st.session_state.get('new_map_state', False):
        st.session_state.new_map_state = {"center": {"lat": 50, "lng": 15}, "zoom": 4}
    st.session_state.map_state = copy.deepcopy(st.session_state.new_map_state)

def process_data(analysis=True):
    set_map_state()
    with st.spinner("Wait for it...", show_time=True):
        make_map()
    if analysis:
        with st.spinner("Wait for it...", show_time=True):
            todo()

@st.fragment
def make_conf():
    ms_filter_options = gdf_ze.MS.unique()

    # with st.popover("Instructions"):
    #    st.write("desc")

    st.write("###  Settings")
    uc_filter_options = [
        None,
        'Baltic sea use case',
        'North-Western Mediterranean sea use case',
        'Galicia use case',
    ]

    filter_array = []
    filter_array_geoplatform = []
    
    uc_selected_filter = st.selectbox("Profiles", options=uc_filter_options)

    st.write("####  Area of Analysis")
    ms_selected_default = None
    aoi_selected_default = None
    if uc_selected_filter is not None:
        if uc_selected_filter == 'Baltic sea use case':
            ms_selected_default = ['Denmark', 'Estonia', 'Finland', 'Germany', 'Latvia', 'Lithuania', 'Poland', 'Sweden']
            aoi_selected_default = ['Baltic sea']
        elif uc_selected_filter == 'North-Western Mediterranean sea use case':
            ms_selected_default = ['Spain', 'France', 'Italy']
            aoi_selected_default = ['North-Western Mediterranean Sea PSSA']
        elif uc_selected_filter == 'Galicia use case':
            ms_selected_default = ['Spain']
            aoi_selected_default = ['Galicia']
            

    ms_selected_filter = st.multiselect("Member states", options=sorted(ms_filter_options),
                                        default=ms_selected_default,
                                        key="ms_selected_filter")
    if len(ms_selected_filter) > 0:
        filter_array.append(" or ".join([f"ms LIKE '{ms}'" for ms in ms_selected_filter]))
        # replace value for France
        ms_selected_filter_fr = ['France-MED' if x == 'France' else x for x in ms_selected_filter]
        filter_array_geoplatform.append(" or ".join([f"MS LIKE '{ms}'" for ms in ms_selected_filter_fr]))

    if len(ms_selected_filter) > 0:
        spid_filter_options = gdf_ze[gdf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    else:
        spid_filter_options = gdf_ze.SPID.unique()
    spid_selected_filter = st.multiselect("Spatial Plan (SPID)", options=sorted(spid_filter_options), key="spid_selected_filter")
    # if filter is None select the SPID from selected member states (if any)
    ms_spid_selected_filter = spid_selected_filter
    if len(spid_selected_filter) == 0 and len(ms_selected_filter) > 0:
        ms_spid_selected_filter = gdf_ze[gdf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    st.session_state.ms_spid_selected_filter = ms_spid_selected_filter
    # Spatial plans
    selected_plans = plans[['MS', 'SPID', 'OffTitle']].copy()
    if len(spid_selected_filter) > 0:
        selected_plans = selected_plans[selected_plans.SPID.isin(spid_selected_filter)]
    selected_plans.SPID = selected_plans.SPID.replace(map_spid)
    st.session_state.selected_plans = selected_plans.copy()

    # Area of interest
    aoi_filter_options = aois.label.unique()
    aoi_selected_filter = st.multiselect("Areas of Interest / Transboundary areas",
                                         default=aoi_selected_default,
                                         options=aoi_filter_options,
                                         key="aoi_selected_filter")

    # Spatial scale
    sc_filter_options = ['Member State', 'Spatial Plan']
    sc_selected_filter = st.selectbox("Spatial scale", options=sc_filter_options, key="sc_selected_filter")

    if sc_selected_filter == 'Spatial Plan' and len(spid_selected_filter) > 0:
        spid_orig = [k for k, v in map_spid.items() if v in spid_selected_filter]
        filter_array.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig]))

        # replace value for France
        spid_orig_fr = ['FRA-MED' if x == 'DSF_MED' else x for x in spid_orig]

        filter_array_geoplatform.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig_fr]))

    st.divider()
    st.write("####  Kind of Analysis")
    analysis_filter_options = ['Zoning Elements',
                               'Sea use',
                               'Sea use & Function',
                               'Coexistence',
                               # 'Transboundary (draft)',
                               'Multi-source overlay',
                               'Diagnosis',
                               ]
    analysis_selected_filter = st.selectbox("Analysis", options=analysis_filter_options, key="analysis_selected_filter")

    
    st.divider()
    st.write("#### Focus")

    spid_filter_options = gdf_ze['Sea use'].unique()
    _gdf = gdf_ze
    if len(ms_selected_filter) > 0:
        _gdf = _gdf[_gdf.MS.isin(ms_selected_filter)]
    if len(spid_selected_filter) > 0:
        _gdf = _gdf[_gdf.SPID.isin(spid_selected_filter)]

    seause_filter_options = _gdf['Sea use'].unique()
    seause_selected_filter = st.multiselect("Sea use", options=seause_filter_options, key="seause_selected_filter")

    if len(seause_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausename = '{_seause}'" for _seause in seause_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseName = '{_seause}'" for _seause in seause_selected_filter]))
        _gdf = _gdf[_gdf['Sea use'].isin(seause_selected_filter)]

    ##
    function_filter_options = _gdf['Function'].unique()
    function_selected_filter = st.multiselect("Sea use function", options=function_filter_options, key="function_selected_filter")

    if len(function_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausefct = '{_function}'" for _function in function_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseFct = '{_function}'" for _function in function_selected_filter]))

    # add parenthesis
    filter_array = [f"({_f})" for _f in filter_array]
    filter_query = " and ".join(filter_array)

    filter_array_geoplatform = [f"({_f})" for _f in filter_array_geoplatform]
    filter_query_geoplatform = " and ".join(filter_array_geoplatform)

    
    st.session_state.filter_query = filter_query
    st.session_state.filter_query_geoplatform = filter_query_geoplatform
    
    st.button("Process", on_click=process_data)

with st.sidebar:
    #st.image('https://www.geoportal.ulpgc.es/remap/img/logoRemap.png', width=200)
    st.image('https://www.shom.fr/sites/default/files/inline-images/logo_ReMAP_0.png', width=200)

        
    make_conf()

@st.fragment
def make_map():
    if len(st.session_state.aoi_selected_filter) >0:
        aoi_filtered = aois[aois.label.isin(st.session_state.aoi_selected_filter)].to_crs(epsg=4326)
    else:
        aoi_filtered = None
    filter_query = st.session_state.filter_query
    filter_query_geoplatform = st.session_state.filter_query_geoplatform
    # Get the last known map state
    last_location = [st.session_state.map_state['center']["lat"],
                     st.session_state.map_state['center']["lng"]
                     ]
    last_zoom = st.session_state.map_state['zoom']
    
    # Create a folium map using the last known state
    m = folium.Map(location=last_location, zoom_start=last_zoom)

    human_activities_wms_url = "https://ows.emodnet-humanactivities.eu/wms?"
    tools4msp_geoplatform_wms_url =  "https://geoplatform.tools4msp.eu/geoserver/wms?"
    bathymetry_wms_url = "https://ows.emodnet-bathymetry.eu/wms?"

    folium.raster_layers.WmsTileLayer(
        url=bathymetry_wms_url,
        name="Bathymetry",
        layers="emodnet:mean_atlas_land",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=False,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (All vessels)",
        layers="routedensity_allavg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Tanker)",
        layers="routedensity_04avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    
    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Cargo)",
        layers="routedensity_01avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    # Add WMS layer with the selected filter
    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Spatial Plan",
        layers="geonode:EMODnet_EU_SpatialPlans",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Zoning Elements",
        layers="geonode:EMODnet_EU_ZoningElements",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query_geoplatform
    ).add_to(m)

    if aoi_filtered is not None:
        geo_j = aoi_filtered.to_json()
        geo_j = folium.GeoJson(data=geo_j, style_function=lambda x: {"fillColor": "orange"})
        geo_j.add_to(m)
        bounds = aoi_filtered.total_bounds
        m.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])

    # Add LayerControl
    folium.LayerControl().add_to(m)

    st.write("# Maritime Spatial Plans (EMODnet)")
    col1, col2 = st.columns([7, 3])
    with col1:
        # Display the map in Streamlit
        map_data = st_folium(m,
                             width=1200,
                             height=500,
                             use_container_width=True,
                             key="new_map_state")
    with col2:
        st.write("### Spatial Plan IDs (SPID)")
        st.dataframe(st.session_state.selected_plans.sort_values(['MS', 'SPID']), hide_index=True)

def get_filter_column():
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        column = 'SPID'
    elif st.session_state.sc_selected_filter == 'Member State':
        column = 'MS'
    return column
    
def apply_filters(_df):
    _selected_filter = None
    column = get_filter_column()
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        _selected_filter = st.session_state.ms_spid_selected_filter
    elif st.session_state.sc_selected_filter == 'Member State':
        _selected_filter = st.session_state.ms_selected_filter

    # apply filters  
    if len(_selected_filter) > 0:
        _df = _df[_df[column].isin(_selected_filter)]
    if len(st.session_state.seause_selected_filter) > 0:
        _df = _df[_df['Sea use'].isin(st.session_state.seause_selected_filter)]
    if len(st.session_state.function_selected_filter) > 0:
        _df = _df[_df['Function'].isin(st.session_state.function_selected_filter)]
    # apply geofilter
    
    if len(st.session_state.aoi_selected_filter) > 0:
        # print("Spatial filter")
        filter_geo = aois[aois.label.isin(st.session_state.aoi_selected_filter)].unary_union
        _df = _df[_df.intersects(filter_geo)]
    return _df.copy()
    
@st.fragment
def todo():
    analysis_header = st.empty()
    analysis_container = st.empty()
    col1, col2 = st.columns([5, 5])
    col1r0 = col1.empty()
    col1r1 = col1.empty()
    col1r2 = col1.empty()
    col1r3 = col1.empty()
    col2r0 = col2.empty()
    col2r1 = col2.empty()
    col2r2 = col2.empty()
    col2r3 = col2.empty()

    with analysis_header.container():
        st.write(f"## {st.session_state.analysis_selected_filter} Analysis")
        explanation = explanations.get(st.session_state.analysis_selected_filter)
        if explanation is not None:
            with st.popover("ℹ️ "):
                st.write(explanation)

    column = get_filter_column()
    _gdf_ze = apply_filters(gdf_ze)
    _gdf_uf = apply_filters(gdf_uf)
    # ricostruisco la coverage dopo aver filtrato gdf_uf
    _coverage = _gdf_uf[~_gdf_uf.index.duplicated()]
    del _coverage['Sea use']
    del _coverage['Function']

    # _lock = RendererAgg.lock

    if st.session_state.analysis_selected_filter == 'Sea use':
        col1r0.write("")
        col2r0.write("")

        # remove duplicates: we just need statistics without overlaps whe use is present with different functions
        _gdf_uf.index.name = 'coverage_id'
        _df = _gdf_uf.reset_index('coverage_id')
        _df = _df.drop_duplicates(['coverage_id', 'Sea use'])
        _df = _df.set_index('coverage_id')
        
        #%% Analise function
        _df = (_df.groupby([column, 'Sea use']).sum('geoarea')
               .join(_coverage_noboundaries.groupby(column).sum('geoarea'), rsuffix='_coverage')
               .join(plans.groupby(column).sum('geoarea')[['geoarea']], rsuffix='_plan')
               .reset_index().fillna(0)
            )
        _df['coverage %'] = _df.geoarea / _df.geoarea_coverage * 100
        _df['coverage_plan %'] = _df.geoarea / _df.geoarea_plan * 100

        #aggregate on Function
        # u_df = _df.groupby([column, 'Sea use'])['coverage %'].sum().to_frame().reset_index()
        u_df = _df
        # if len(ms_selected_filter) > 0:
        #    _df = _df[_df.MS.isin(ms_selected_filter)].copy()
        u_df = u_df.pivot(columns='Sea use', index=column, values='coverage %')  # .fillna(0)
        u_df = u_df.dropna(how='all').round(0)

        # Display the plot in Streamlit
        with col1r1.container():
            fig = px.imshow(u_df, text_auto=True, aspect="auto", color_continuous_scale="aggrnyl_r",
                            title="Percentage of sea use surfaces relative to Zoning Elements coverage")
            fig = fig.update_traces(xgap=2, ygap=2)
            st.plotly_chart(fig, theme="streamlit", use_container_width=True)
        col1r2.dataframe(u_df.T)

        #aggregate on Function
        u_df = _df.groupby([column, 'Sea use'])['coverage_plan %'].sum().to_frame().reset_index()

        # if len(ms_selected_filter) > 0:
        #    _df = _df[_df.MS.isin(ms_selected_filter)].copy()
        u_df = u_df.pivot(columns='Sea use', index=column, values='coverage_plan %')  # .fillna(0)
        u_df = u_df.dropna(how='all').round(0)

        # Display the plot in Streamlit
        with col2r1.container():
            fig = px.imshow(u_df, text_auto=True, aspect="auto", color_continuous_scale="aggrnyl_r",
                            title="Percentage of sea use surfaces relative to Spatial Plan coverage")
            fig = fig.update_traces(xgap=2, ygap=2)
            st.plotly_chart(fig, theme="streamlit", use_container_width=True)
            
            
        col2r2.dataframe(u_df.T)

    elif st.session_state.analysis_selected_filter == 'Zoning Elements':
        with col1r0.container():
            st.write("**Number of Zoning Elements**")
            with st.expander("ℹ️  See explanation"):
                st.write(explanations.get("n_ze"))

        with col2r0.container():
            st.write("**Disjoint Index**")
            with st.expander("ℹ️  See explanation"):
                st.write(explanations.get("disjoint"))
            
        __df = _gdf_ze.groupby(column).size().to_frame("Number_ZE")
        with col1r1.container():
            st.bar_chart(__df)
        col1r2.dataframe(__df)

        ##############
        __df = (_gdf_ze.groupby([column]).sum('geoarea')
               .join(_coverage.groupby(column).sum('geoarea'), rsuffix='_coverage')
               .join(plans.groupby(column).sum('geoarea')[['geoarea']], rsuffix='_plan')
            )
        
        field = 'Disjoint_index'
        # rimuovere il moltiplicatore quando ci saranno i dati giusti
        # print(_gdf_ze.groupby([column]).sum('geoarea'))
        # print("######################")
        # print(_coverage.groupby(column).sum('geoarea'))
        # print(__df.columns)

        ___df = (__df.geoarea_coverage / __df.geoarea).to_frame(field)

        ___df['ZE Coverage (%)'] = ((__df.geoarea_coverage / __df.geoarea_plan) * 100).round(1)

        col2r1.bar_chart(___df[field])

        col2r2.dataframe(___df)

        # aggiungere % zoning element coverage
        # u_df = _df.groupby([column, 'Sea use'])['coverage_plan %'].sum().to_frame().reset_index()


    
    elif st.session_state.analysis_selected_filter == 'Sea use & Function':
        
        #%% Analise function (excluding Boundaries use)
        _df = (_gdf_uf.groupby([column, 'Sea use', 'Function']).sum('geoarea')
               .join(_coverage_noboundaries.groupby(column).sum('geoarea'), rsuffix='_coverage')
               .join(plans.groupby(column).sum('geoarea')[['geoarea']], rsuffix='_plan')
               .reset_index(['Function']).reset_index().fillna(0)
            )
        _df.Function = _df.Function.replace(' ', 'Undefined')

        _df['coverage %'] = _df.geoarea / _df.geoarea_coverage * 100

        SORTED_FUNCTIONS = ['Reserved', 'Priority', 'Allowed', 'Potential', 'Restricted', 'Forbidden', 'Undefined']
        SORTED_SEAUSES = gdf_uf['Sea use'].sort_values().unique()

        def stacked_barplot(data, **kwargs):
            __df = (data.groupby(['Sea use', 'Function'])
                    .sum()
                    .reset_index()
                    .pivot(columns='Function', index='Sea use', values='coverage %')
                    )
            # add missing columns
            for sc in SORTED_FUNCTIONS:
                if sc not in __df.columns:
                    __df[sc] = 0
            # add missing rows
            for sc in SORTED_SEAUSES:
                if sc not in __df.index:
                    __df.loc[sc] = 0

            ax = plt.gca()
            __df.columns = pd.CategoricalIndex(__df.columns.values,
                                               ordered=True,
                                               categories=SORTED_FUNCTIONS)
            __df = __df.sort_index(axis=1)
            __df = __df.sort_index(axis=0)
            __df.plot(kind='barh', stacked=True,
                      ax=ax,
                      # color=colors,
                      # **kwargs
                      ) ## Plot


        # get number of groups
        dfg = _df.groupby(column)
        ngroups = dfg.ngroups
        col_wrap = ngroups if ngroups < 3 else 3
        
        #with _lock:
        g = sns.FacetGrid(_df, col=column, col_wrap=col_wrap, aspect=2)
        g.map_dataframe(stacked_barplot)
        g.add_legend()
        col1r1.pyplot(plt.gcf())

        col2r1.dataframe(_df)
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Coexistence':

        with analysis_container.container():
            plot_upset(_gdf_uf, _coverage, column)
            
        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Multi-source overlay':

        _coverage[coverage_stats.columns] = coverage_stats.loc[_coverage.index]

        n = coverage_stats.columns.shape[0]
        fig, axes = plt.subplots(nrows=n, ncols=1, figsize=(5, n * 3))  # Imposta la dimensione per adattare
        for i, ax in enumerate(axes):
            c = coverage_stats.columns[i]
            _coverage.plot(ax=ax, column=c, legend=True)
            ax.set_title(c)
        plt.tight_layout()            
        col1r1.pyplot(plt.gcf())

        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Diagnosis':
        # print(_gdf_ze.columns)
        with analysis_container.container():
            plot_diagnosis_sankey(_gdf_ze, column)
            st.divider()
            plot_treemap(_gdf_ze)
        # _coverage[coverage_stats.columns] = coverage_stats.loc[_coverage.index]

        # n = coverage_stats.columns.shape[0]
        # fig, axes = plt.subplots(nrows=n, ncols=1, figsize=(5, n * 3))  # Imposta la dimensione per adattare
        # for i, ax in enumerate(axes):
        #     c = coverage_stats.columns[i]
        #     _coverage.plot(ax=ax, column=c, legend=True)
        #     ax.set_title(c)
        # plt.tight_layout()            
        # col1r1.pyplot(plt.gcf())

        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

@st.fragment
def plot_treemap(df):
    # Index(['LocalID', 'VersionID', 'OffSource', 'MS', 'HilucLU', 'HilucsMSP',
    #               'Sea use', 'Function', 'SeaUseDsc', 'OriginUN', 'OriginUNEn',
    #               'RegNature', 'VertDistr', 'ProcStepG', 'hilucsPres', 'SpecLanUs',
    #               'SpecPres', 'BackgMap', 'ValidFrom', 'ValidTo', 'PrevMSPPla',
    #               'BeginLSVer', 'EndLSVer', 'DimInd', 'SPID', 'OffDoc', 'Coast_Dist_M',
    #               'km2', 'Shape_Length', 'Shape_Area', 'geometry', 'Coast_Dist',
    #               'geoarea'],
          
    print("DFDFDFDFDF")
    print(df.columns)
    st.write(f"### Hierarchical exploration")
    df['Hilucs MSP'] = df.HilucsMSP.str.split('_').str[-1].str.replace('.html','')

    treemap_explore_by_options = [
        'Member states', 'Sea uses', 'Hilucs MSP'
        ]
    treemap_explore_by_selected = st.selectbox(
        "Explore by",
        options=treemap_explore_by_options,
        key="treemap_explore_by_selected",
    )
    tree_title = treemap_explore_by_selected
    if treemap_explore_by_selected == 'Member states':
        tree_columns = ['MS', 'Sea use', 'Function', 'OriginUNEn']
    elif treemap_explore_by_selected == 'Sea uses':
        tree_columns = ['Sea use', 'MS', 'OriginUNEn', 'Function']
    elif treemap_explore_by_selected == 'Hilucs MSP':
        tree_columns = ['Hilucs MSP', 'MS', 'OriginUNEn', 'Function']
    # treemap color
    treemap_color_options = tree_columns
    treemap_color_selected = st.selectbox(
        "Color mode",
        options=treemap_color_options,
        key="treemap_color_selected",
    )

    st.write(f"**Hierarchy**: {' -> '.join(tree_columns)}")
    fig = px.treemap(df, path=[px.Constant(tree_title)] + tree_columns,
                     values='geoarea',
                     # color='lifeExp', hover_data=['iso_alpha'],
                     # color_continuous_scale='RdBu',
                     # color_continuous_midpoint=np.average(df['lifeExp'], weights=df['pop'])
                     # color_discrete_map=GES if treemap_color_selected == assessment_col else None,
                     color=st.session_state.treemap_color_selected,
                     )
    fig.update_layout(margin = dict(t=50, l=25, r=25, b=25))
    fig.update_traces(marker=dict(cornerradius=5))
    st.plotly_chart(fig, use_container_width=True)


@st.fragment
def plot_upset(_gdf_ze, _coverage, column):
            upset_sc_filter_options = _gdf_ze[column].unique()
            st.selectbox(
                st.session_state.sc_selected_filter,
                options=upset_sc_filter_options,
                key="upset_sc_selected_filter",
            )

            upset_columns = ['MS', 'SPID', 'geoarea']
            __df = _gdf_ze[_gdf_ze[column]==st.session_state.upset_sc_selected_filter].copy()
            __df = __df.rename_axis('coverage').reset_index()
            __df = __df.set_index('MS').join(_coverage.groupby(['MS']).sum('geoarea'), rsuffix='_coverage_ms').reset_index()
            __df = __df.set_index('SPID').join(_coverage.groupby(['SPID']).sum('geoarea'), rsuffix='_coverage_spid').reset_index()

            geoarea_column = f'geoarea_perc_{column.lower()}'
            __df[geoarea_column] = __df.geoarea / __df[f'geoarea_coverage_{column.lower()}'] * 100
            
            _df_entity = __df.groupby('coverage').agg({'Sea use': list, geoarea_column: sum})
            print("11111111111111111")
            upset_data = from_memberships(_df_entity['Sea use'],
                                          data=_df_entity[[geoarea_column]])  # , 'location']])
            print("22222222222222222")
            if upset_data.index.nlevels <= 1:
                st.warning(
                    "The number of selected or available uses is not sufficient to perform a coexistence analysis. "
                    "At least two uses are required."
                )
                return
            
            upset = UpSet(upset_data,
                          sum_over = geoarea_column,
                          # intersection_plot_elements=0,
                          totals_plot_elements=12,
                          #  show_counts='%d%%',
                          # show_percentages=True,
                          min_subset_size=0.5,
                          )  # disable the default bar chart
            print("33333333333333333")
            plots = upset.plot()
            plots['totals'].set_title("surface occupied (%)")
            # plt.suptitle(entity)
            # plt.show()
            st.pyplot(plt.gcf())
            

@st.fragment
def plot_diagnosis_sankey(_gdf_ze, column):
            sankey_sc_filter_options = _gdf_ze[column].unique()
            st.selectbox(
                st.session_state.sc_selected_filter,
                options=sankey_sc_filter_options,
                key="sankey_sc_selected_filter",
            )

            sankey_columns = ['OriginUNEn', 'Sea use', 'Function']
            __df = _gdf_ze[_gdf_ze[column]==st.session_state.sankey_sc_selected_filter].copy()
            labels, sources, targets, values, link_colors, sourceinfo = set_sankey_data(__df, sankey_columns, 'geoarea')

            # gcolumns = [column, 'Sea use', 'Function', 'OriginUNEn']
            # __df = __df.groupby(gcolumns).geoarea.sum().to_frame().reset_index()
            # # sovrascrivo nodo Sea use aggiungendo uno spazio per evitare loop nel sankey nel caso
            # # OriginUNEn e Sea use siano uguali
            # __df['Sea use'] = __df['Sea use'] + ' '
            

            # # Creazione delle etichette uniche
            # labels = list(pd.concat([df['OriginUNEn'], df['Sea use'], df['Function']]).unique())

            # # Creazione di un dizionario per mappare le etichette agli indici
            # label_index = {label: index for index, label in enumerate(labels)}

            # # Creazione delle liste per le origini, destinazioni e valori
            # sources = []
            # targets = []
            # values = []
            # link_colors = []
            # sourceinfo = []

            # colors = px.colors.qualitative.Set3

            # # Assicurati che ci siano abbastanza colori per le origini
            # color_mapping = {origin: colors[i % len(colors)] for i, origin in enumerate(df['OriginUNEn'].unique())}
            
            
            # # Riempimento delle liste con i dati del DataFrame
            # for _, row in df.groupby(['OriginUNEn', 'Sea use']).sum('geoarea').reset_index().sort_values(['OriginUNEn', 'Sea use']).iterrows():
            #     sources.append(label_index[row['OriginUNEn']])  # Indice della sorgente
            #     targets.append(label_index[row['Sea use']])      # Indice della destinazione
            #     values.append(row['geoarea'])                        # Valore per lo spessore
            #     link_colors.append(color_mapping[row['OriginUNEn']])
            #     sourceinfo.append(row['OriginUNEn'])
                

            # # Aggiungere anche i collegamenti dalle destinazioni 'Sea use' a 'Function'
            # df_links = df.groupby(['OriginUNEn', 'Sea use', 'Function']).sum('geoarea').reset_index().sort_values(['OriginUNEn', 'Sea use'])
            # for _, row in df_links.iterrows():
            #     sources.append(label_index[row['Sea use']])
            #     targets.append(label_index[row['Function']])
            #     values.append(row['geoarea'])
            #     link_colors.append(color_mapping[row['OriginUNEn']])
            #     sourceinfo.append(row['OriginUNEn'])

            # Creazione del grafico Sankey
            fig = go.Figure(go.Sankey(
                node=dict(
                    # pad=15,
                    # thickness=20,
                    # line=dict(color='black', width=0.5),
                    label=labels,
                    color="grey",
                ),
                link=dict(
                    source=sources,
                    target=targets,
                    value=values,
                    color=link_colors,
                    customdata = sourceinfo,
                    hovertemplate='OriginUNEn %{customdata}<br />'+
                    'source: %{source.label}<br />'+
                    'target: %{target.label}<br />' +
                    'area: %{value}<br />',
                ),
                textfont=dict(
                    color='black',
                    shadow = "rgba(0, 0, 0, 0)",
                )
            ))

            for x_coordinate, column_name in enumerate(["OriginUNEn", "Sea use", "Function"]):
                fig.add_annotation(
                    x=x_coordinate,#Plotly recognizes 0-5 to be the x range.
                    
                    y=1.075,#y value above 1 means above all nodes
                    xref="x",
                    yref="paper",
                    text=column_name,#Text
                    showarrow=False,
                    align="left",
                )
            fig.update_traces(node_hoverlabel=dict(bgcolor="white"))
            # Mostrare il grafico
            # fig.update_layout(title_text='Diagramma di Sankey', font_size=10)
        
            st.plotly_chart(fig, use_container_width=True)
        
            st.dataframe(__df[sankey_columns])

process_data(False)
