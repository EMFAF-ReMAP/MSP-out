# streamlit_app.py
import os
import uuid
import base64
import streamlit as st

# Force import to see config logs
with open("/tmp/geoapps_startup.log", "w") as f:
    f.write("=" * 60 + "\n")
    f.write("STARTING STREAMLIT APP - Importing config...\n")
    f.write(f"GEOAPPS_ENV = {os.getenv('GEOAPPS_ENV', 'NOT SET')}\n")
    f.write("=" * 60 + "\n")
    
from core import config as config_module

with open("/tmp/geoapps_startup.log", "a") as f:
    f.write(f"Config environment: {config_module.config.environment}\n")
    f.write(f"DB Host from config: {config_module.config.get('database.host')}\n")
    f.write(f"DB Port from config: {config_module.config.get('database.port')}\n")
    f.write("=" * 60 + "\n")

from auth.auth import (
    init_database,
    get_user_statistics,
    get_all_users,  # reserved for future admin panels
    auto_logout_check,
    create_user_session,
    end_user_session,
    add_to_demo_queue,
    get_queue_position,
    remove_from_demo_queue,
    is_in_demo_queue,
    get_queue_stats,
    get_next_in_queue,
    auto_login_next_in_queue,
    cleanup_expired_sessions,
    cleanup_expired_queue,
    issue_persistent_login,
    get_user_by_persistent_token,
    revoke_persistent_token,
)

from auth.access_guard import set_home_page
from tools.utils import make_header

# ──────────────────────────────────────────────────────────────
# App config
# ──────────────────────────────────────────────────────────────
st.set_page_config(page_title="CNR-ISMAR Demo Dashboard", layout="wide")

# Set this page as the home page for authentication redirects
set_home_page("streamlit_app_demo.py")

# Initialize database on startup (also ensures migrations)
init_database()

# Auto-logout check as early as possible (legacy flow compatibility)
auto_logout_check()

# Hide multipage navigation
st.markdown(
    """
    <style>
        [data-testid="stSidebarNav"] { display: none; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ──────────────────────────────────────────────────────────────
# Persistent per-browser ID + auth cookies
# ──────────────────────────────────────────────────────────────
from streamlit_cookies_manager import EncryptedCookieManager

# Import condizionale per gestire sia environment di sviluppo che container
try:
    from .core.config import get_secret
except ImportError:
    # Fallback per ambiente container o standalone
    try:
        from geoapps.core.config import get_secret
    except ImportError:
        # Fallback definitivo se la configurazione non è disponibile
        import os
        def get_secret(key, default=None):
            return os.environ.get(key.upper(), default)

cookies = EncryptedCookieManager(
    prefix="cnr_demo_",
    password=get_secret("cookie_secret", "change_this_secret_key"),
)

if not cookies.ready():
    st.stop()

client_id = cookies.get("client_id")
if client_id is None:
    client_id = f"br_{uuid.uuid4().hex[:12]}"
    cookies["client_id"] = client_id
    cookies.save()

st.session_state.client_id = client_id
AUTH_COOKIE_KEY = "auth_token"

# ──────────────────────────────────────────────────────────────
# Session state initialization
# ──────────────────────────────────────────────────────────────
st.session_state.setdefault("logged_in", False)
st.session_state.setdefault("username", None)
st.session_state.setdefault("session_id", None)
st.session_state.setdefault("in_queue", False)

# ──────────────────────────────────────────────────────────────
# Try persistent auto-login (if not already logged in)
# ──────────────────────────────────────────────────────────────
if not st.session_state.logged_in:
    auth_token = cookies.get(AUTH_COOKIE_KEY)
    if auth_token:
        user = get_user_by_persistent_token(auth_token, client_id)
        if user:
            session_id = create_user_session(user["username"], client_id=client_id)
            st.session_state.logged_in = True
            st.session_state.username = user["username"]
            st.session_state.session_id = session_id
            st.success(f"✅ Session restored for **{user['username']}**")
            st.rerun()

# ──────────────────────────────────────────────────────────────
# Client-side auto-claim from queue when a slot is free
# (Only the FIRST in queue is allowed to claim)
# ──────────────────────────────────────────────────────────────
from auth.auth import get_next_in_queue  # add this import near the others if missing

if not st.session_state.logged_in and is_in_demo_queue(st.session_state.client_id):
    first_in_queue = get_next_in_queue()
    if first_in_queue == st.session_state.client_id:
        stats_now = get_user_statistics()
        if stats_now["available_slots"] > 0:
            success, slot_name, browser_id = auto_login_next_in_queue()
            if success and browser_id == st.session_state.client_id:
                session_id = create_user_session(slot_name, client_id=st.session_state.client_id)
                token = issue_persistent_login(slot_name, st.session_state.client_id, days=7)
                cookies[AUTH_COOKIE_KEY] = token
                cookies.save()

                st.session_state.logged_in = True
                st.session_state.username = slot_name
                st.session_state.session_id = session_id
                st.success(f"🎉 It's your turn! You have been assigned to **{slot_name}**.")
                st.rerun()
                
# ──────────────────────────────────────────────────────────────
# Cleanup expired sessions and queue to ensure accurate detection
# ──────────────────────────────────────────────────────────────
cleanup_expired_sessions()
cleanup_expired_queue()

# ──────────────────────────────────────────────────────────────
# If not logged in: show DEMO or Traditional login tabs
# ──────────────────────────────────────────────────────────────
stats = get_user_statistics()

if not st.session_state.logged_in:
    st.title("🌍 CNR-ISMAR Data Explorer [DEMO]")

    tab1, tab2 = st.tabs(["🎯 Demo Slot Login", "🔐 Login with credentials"])

    # ── TAB 1: DEMO SLOT LOGIN ────────────────────────────────
    with tab1:
        st.info("Select a free demo slot or join the queue. No password required.")
        queue_stats = get_queue_stats()

        if is_in_demo_queue(st.session_state.client_id):
            st.session_state.in_queue = True
            position = get_queue_position(st.session_state.client_id)
            estimated_wait = max(1, (position - 1) * 10)  # ~10 min per person ahead

            st.warning(f"🎫 You are in queue — Position #{position}")
            st.info(f"⏱️ Estimated waiting time: ~{estimated_wait} minutes")

            # Auto-refresh every 15s while waiting in queue
            st.markdown("<meta http-equiv='refresh' content='15'>", unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                st.metric("👥 Demo slots in use", f"{stats['demo_count']}/{stats['max_users']}")
            with col2:
                st.metric("🎫 People in queue", queue_stats["total_in_queue"])

            # If it's your turn and a slot is free → claim immediately
            next_browser = get_next_in_queue()
            if next_browser == st.session_state.client_id and stats["available_slots"] > 0:
                success, slot_name, browser_id = auto_login_next_in_queue()
                if success and browser_id == st.session_state.client_id:
                    session_id = create_user_session(slot_name, client_id=st.session_state.client_id)
                    token = issue_persistent_login(slot_name, st.session_state.client_id, days=7)
                    cookies[AUTH_COOKIE_KEY] = token
                    cookies.save()

                    st.session_state.logged_in = True
                    st.session_state.username = slot_name
                    st.session_state.session_id = session_id
                    st.success(f"🎉 It's your turn! You have been assigned to **{slot_name}**.")
                    st.rerun()
            else:
                # Not my turn: do nothing. Another client must claim when they are first.
                pass

            if st.button("❌ Leave the queue", key="exit_queue"):
                remove_from_demo_queue(st.session_state.client_id)
                st.session_state.in_queue = False
                st.rerun()

        else:
            # Debug expander (optional)
            with st.expander("🔍 Debug Info", expanded=False):
                st.write("**Current stats:**", stats)
                st.write("**client_id:**", st.session_state.client_id)
                active_sessions = stats.get("active_sessions", [])
                used_slots = [s["username"] for s in active_sessions if s["username"].startswith("demo")]
                st.write("**Used slots:**", used_slots)

            st.markdown("---")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("👥 Demo slots in use", f"{stats['demo_count']}/{stats['max_users']}")
            with col2:
                st.metric("🆓 Free slots", stats["available_slots"])
            with col3:
                st.metric("⏱️ Timeout", f"{stats['timeout_minutes']} min")

            if queue_stats["total_in_queue"] > 0:
                queue_status = f"{queue_stats['total_in_queue']}/{queue_stats['max_queue_size']}"
                if queue_stats["is_queue_full"]:
                    st.metric("🎫 Queue (FULL)", queue_status, delta="Queue is full", delta_color="inverse")
                else:
                    st.metric("🎫 People in queue", queue_status)

            st.markdown("---")

            slots = stats.get("max_users", 5)
            active_sessions = stats.get("active_sessions", [])
            used_slots = [s["username"] for s in active_sessions if s["username"].startswith("demo")]

            if stats["available_slots"] > 0:
                # Render slot buttons in a grid (3 columns per row)
                slots_per_row = 3
                for row_start in range(1, slots + 1, slots_per_row):
                    cols = st.columns(slots_per_row)
                    for col_idx, i in enumerate(range(row_start, min(row_start + slots_per_row, slots + 1))):
                        slot_name = f"demo{i}"
                        with cols[col_idx]:
                            if slot_name in used_slots:
                                st.button(f"🔒 Slot {i} (busy)", key=f"slot_{i}", disabled=True, use_container_width=True)
                            else:
                                if st.button(f"🟢 Slot {i} (free)", key=f"slot_{i}", use_container_width=True):
                                    session_id = create_user_session(slot_name, client_id=st.session_state.client_id)
                                    token = issue_persistent_login(slot_name, st.session_state.client_id, days=7)
                                    cookies[AUTH_COOKIE_KEY] = token
                                    cookies.save()

                                    st.session_state.logged_in = True
                                    st.session_state.username = slot_name
                                    st.session_state.session_id = session_id

                                    if st.session_state.in_queue:
                                        remove_from_demo_queue(st.session_state.client_id)
                                        st.session_state.in_queue = False

                                    st.success(f"✅ Session created: {session_id}")
                                    st.rerun()
            else:
                st.error("🚫 All demo slots are currently in use!")
                st.markdown("### 🎫 Reservation system")
                
                # Check queue status
                if queue_stats["is_queue_full"]:
                    st.error(f"❌ Queue is full ({queue_stats['max_queue_size']} people max)")
                    st.info("💡 Please try again later or create an account for unlimited access.")
                elif queue_stats["available_queue_spots"] <= 5:
                    st.warning(f"⚠️ Queue is almost full! Only {queue_stats['available_queue_spots']} spots remaining.")
                    st.info("Join now or you'll get in automatically when it's your turn.")
                else:
                    st.info("Join the queue and you'll get in automatically when it's your turn.")

                # --- FIXED: clearer UX + spinner + reliable DB insert ---
                if not is_in_demo_queue(st.session_state.client_id) and not queue_stats["is_queue_full"]:
                    if st.button("🎫 Join the queue", key="join_queue", type="primary"):
                        with st.spinner("Adding you to the queue…"):
                            try:
                                position = add_to_demo_queue(st.session_state.client_id)
                                st.session_state.in_queue = True
                                st.success(f"✅ Reservation confirmed! Your position is #{position}")
                                st.rerun()
                            except ValueError as e:
                                # Queue is full
                                st.error(f"❌ {str(e)}")
                                st.info("💡 Please try again later or create an account for unlimited access.")
                            except Exception as e:
                                # Other errors
                                st.error(f"❌ Could not join the queue: {e}")
                else:
                    st.info("🎫 You are already in the queue.")

    # ── TAB 2: LOGIN WITH USERNAME AND PASSWORD ───────────────
    with tab2:
        st.markdown("### 🔐 Login with credentials")
        st.info("Full access without demo slot limits.")

        with st.form("traditional_login"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("🚀 Sign in", type="primary")

            if submitted:
                if username and password:
                    from auth.auth import authenticate_user

                    user_info = authenticate_user(username, password)
                    if user_info:
                        session_id = create_user_session(username, client_id=st.session_state.client_id)
                        token = issue_persistent_login(username, st.session_state.client_id, days=7)
                        cookies[AUTH_COOKIE_KEY] = token
                        cookies.save()

                        st.session_state.logged_in = True
                        st.session_state.username = username
                        st.session_state.session_id = session_id
                        st.success(f"✅ Welcome {user_info['full_name']}!")
                        st.rerun()
                    else:
                        st.error("❌ Invalid credentials")
                else:
                    st.warning("⚠️ Please enter username and password")

# ──────────────────────────────────────────────────────────────
# Logged-in area (demo or traditional)
# ──────────────────────────────────────────────────────────────
else:
    username = st.session_state.username or ""
    user_type = "Demo Slot" if username.startswith("demo") else "Registered User"
    
    # Use consistent header across all pages
    make_header()
    
    # Welcome message in main area
    if username.startswith("demo"):
        st.success(f"🎯 Welcome! You are using a **demo slot** — Account: **{username}**")
    else:
        st.success(f"🔐 Welcome! You are logged in with **credentials** — Account: **{username}**")

    st.markdown("---")
    # ── Dashboard with uniform card heights ──────────────────
    st.markdown("### 🚀 Available Applications")
    col1, col2, col3 = st.columns(3)

    with col1:
        card_html = """
        <div style="border:2px solid #1f77b4; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#f8f9fa 0%,#e9ecef 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
            <h4 style="color:#1f77b4; margin:0 0 10px 0; font-size:1.1em;">🌐 CKAN Spatial Explorer</h4>
            <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Full access to spatial datasets with advanced filtering, maps, and analysis tools.</p>
            <div style="width:100%; aspect-ratio:16/9; overflow:hidden; border-radius:6px; background:#e9ecef; flex-grow:1;">
                <img src="data:image/png;base64,{}" style="width:100%; height:100%; object-fit:cover; object-position:center;">
            </div>
        </div>
        """
        try:
            with open("res/ckan_explorer_thumbnail.png", "rb") as f:
                img_data = base64.b64encode(f.read()).decode()
            st.markdown(card_html.format(img_data), unsafe_allow_html=True)
        except Exception:
            st.markdown(
                """
                <div style="border:2px solid #1f77b4; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#f8f9fa 0%,#e9ecef 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
                    <h4 style="color:#1f77b4; margin:0 0 10px 0; font-size:1.1em;">🌐 CKAN Spatial Explorer</h4>
                    <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Full access to spatial datasets with advanced filtering, maps, and analysis tools.</p>
                    <div style="width:100%; aspect-ratio:16/9; background:#e9ecef; border-radius:6px; display:flex; align-items:center; justify-content:center; color:#6c757d; font-size:12px; flex-grow:1;">Image not found</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        if st.button("🚀 Launch CKAN Explorer [DEMO]", use_container_width=True, key="ckan_demo"):
            st.switch_page("pages/CKAN_Explorer.py")

    with col2:
        card_html = """
        <div style="border:2px solid #ff7f0e; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
            <h4 style="color:#ff7f0e; margin:0 0 10px 0; font-size:1.1em;">📈 ReMAP - MSP out</h4>
            <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Marine Spatial Planning outputs and reporting tools with full member access.</p>
            <div style="width:100%; aspect-ratio:16/9; overflow:hidden; border-radius:6px; background:#ffe0b2; flex-grow:1;">
                <img src="data:image/png;base64,{}" style="width:100%; height:100%; object-fit:cover; object-position:center;">
            </div>
        </div>
        """
        try:
            with open("res/remap_thumbnail.png", "rb") as f:
                img_data = base64.b64encode(f.read()).decode()
            st.markdown(card_html.format(img_data), unsafe_allow_html=True)
        except Exception:
            st.markdown(
                """
                <div style="border:2px solid #ff7f0e; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
                    <h4 style="color:#ff7f0e; margin:0 0 10px 0; font-size:1.1em;">📈 ReMAP - MSP out</h4>
                    <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Marine Spatial Planning outputs and reporting tools with full member access.</p>
                    <div style="width:100%; aspect-ratio:16/9; background:#ffe0b2; border-radius:6px; display:flex; align-items:center; justify-content:center; color:#bf5f00; font-size:12px; flex-grow:1;">Image not found</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        if st.button(f"🚀 Launch ReMAP - MSP out [{st.session_state.username}]", use_container_width=True, key="remap_main"):
            st.switch_page("pages/ReMAP_MSP_out.py")

    with col3:
        card_html = """
        <div style="border:2px solid #2ca02c; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#e8f5e9 0%,#c8e6c9 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
            <h4 style="color:#2ca02c; margin:0 0 10px 0; font-size:1.1em;">📊 ReMAP - MSP & MSFD</h4>
            <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Marine Spatial Planning and Marine Strategy Framework Directive integration tools.</p>
            <div style="width:100%; aspect-ratio:16/9; overflow:hidden; border-radius:6px; background:#c8e6c9; flex-grow:1;">
                <img src="data:image/png;base64,{}" style="width:100%; height:100%; object-fit:cover; object-position:center;">
            </div>
        </div>
        """
        try:
            with open("res/remap_msfd_thumbnail.png", "rb") as f:
                img_data = base64.b64encode(f.read()).decode()
            st.markdown(card_html.format(img_data), unsafe_allow_html=True)
        except Exception:
            st.markdown(
                """
                <div style="border:2px solid #2ca02c; border-radius:10px; padding:16px; margin:8px 0; background:linear-gradient(135deg,#e8f5e9 0%,#c8e6c9 100%); box-shadow:0 3px 6px rgba(0,0,0,0.08); text-align:center; height:420px; display:flex; flex-direction:column;">
                    <h4 style="color:#2ca02c; margin:0 0 10px 0; font-size:1.1em;">📊 ReMAP - MSP & MSFD</h4>
                    <p style="color:#495057; font-size:0.9em; margin:0 0 12px 0; flex-grow:0; min-height:60px;">Marine Spatial Planning and Marine Strategy Framework Directive integration tools.</p>
                    <div style="width:100%; aspect-ratio:16/9; background:#c8e6c9; border-radius:6px; display:flex; align-items:center; justify-content:center; color:#1b5e20; font-size:12px; flex-grow:1;">Image not found</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        if st.button(f"🚀 Launch ReMAP - MSP & MSFD [{st.session_state.username}]", use_container_width=True, key="remap_msfd"):
            st.switch_page("pages/ReMAP_MSP_MSFD.py")


