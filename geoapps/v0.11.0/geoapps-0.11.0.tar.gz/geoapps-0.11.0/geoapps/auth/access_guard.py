# access_guard.py
import os
import uuid
import streamlit as st
from streamlit_cookies_manager import EncryptedCookieManager

from .auth import (
    init_database,
    get_user_by_persistent_token,
    create_user_session,
)

# Import default values
try:
    from core.defaults import COOKIE_PREFIX as DEFAULT_COOKIE_PREFIX, COOKIE_SECRET as DEFAULT_COOKIE_SECRET
except ImportError:
    DEFAULT_COOKIE_PREFIX = "cnr_demo_"
    DEFAULT_COOKIE_SECRET = "change_this_secret_key"

AUTH_COOKIE_KEY = "auth_token"

# Import condizionale per gestire sia environment di sviluppo che container
try:
    from ..core.config import get_secret
except ImportError:
    # Fallback per ambiente container o standalone
    try:
        from geoapps.core.config import get_secret
    except ImportError:
        # Fallback definitivo se la configurazione non è disponibile
        def get_secret(key, default=None):
            return os.environ.get(key.upper(), default)

COOKIE_PREFIX = DEFAULT_COOKIE_PREFIX
CLIENT_ID_COOKIE = f"{COOKIE_PREFIX}_client_id"
LOGIN_STATE_COOKIE = f"{COOKIE_PREFIX}_login_state"

def _get_cookies() -> EncryptedCookieManager:
    cookies = EncryptedCookieManager(
        prefix=COOKIE_PREFIX,
        password=get_secret("cookie_secret", DEFAULT_COOKIE_SECRET),
    )
    if not cookies.ready():
        # Show a loading message instead of just stopping
        st.info("🔄 Loading authentication cookies...")
        st.stop()
    return cookies

def _get_or_set_client_id(cookies: EncryptedCookieManager) -> str:
    client_id = cookies.get("client_id")
    if client_id is None:
        client_id = f"br_{uuid.uuid4().hex[:12]}"
        cookies["client_id"] = client_id
        cookies.save()
    return client_id

def require_app_login() -> None:
    """
    Call this at the very TOP of every app/page.
    If the user isn't logged in, try to restore from cookie.
    If still not logged in, redirect to home page (determined dynamically).
    """
    # Ensure DB exists
    init_database()

    # Already logged in in this Streamlit run? OK.
    if st.session_state.get("logged_in", False) and st.session_state.get("username"):
        # Debug: show that we're already logged in
        # st.sidebar.success(f"✅ Logged in as {st.session_state.username}")
        return

    # Try to restore from persistent cookie
    cookies = _get_cookies()
    client_id = _get_or_set_client_id(cookies)
    token = cookies.get(AUTH_COOKIE_KEY)

    if token:
        user = get_user_by_persistent_token(token, client_id)
        if user:
            # Recreate server-side session and Streamlit state
            session_id = create_user_session(user["username"], client_id=client_id)
            st.session_state.logged_in = True
            st.session_state.username = user["username"]
            st.session_state.session_id = session_id
            # Force rerun to ensure session state is properly set
            st.rerun()
        else:
            # Token exists but user validation failed - might be expired
            # Clear the invalid token
            cookies[AUTH_COOKIE_KEY] = ""
            cookies.save()
    
    # Not logged in → get home page from session state or query params
    home_page = _get_home_page()
    st.switch_page(home_page)


def _get_home_page() -> str:
    """
    Get the home page dynamically from session state or query params.
    Falls back to default if not found.
    """
    # Check session state first (set by home page)
    if "home_page" in st.session_state:
        return st.session_state.home_page
    
    # Check query parameters
    if "home" in st.query_params:
        return st.query_params["home"]
    
    # Fallback to default
    # In Streamlit multipage apps, the main file is referenced without extension
    return "streamlit_app_demo.py"


def set_home_page(home_page: str) -> None:
    """
    Set the home page in session state.
    Should be called by the main app/home page.
    """
    st.session_state.home_page = home_page
