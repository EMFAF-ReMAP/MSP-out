"""Modulo per l'autenticazione e controllo accessi."""

# Import delle funzioni principali
from .auth import (
    init_database, authenticate_user, is_logged_in,
    get_current_user, logout_user, auto_logout_check, clear_all_sessions,
    get_next_in_queue, get_all_users,
    get_user_role_from_db, update_user_role, create_user
)
from .access_guard import require_app_login, set_home_page

# Import role-based access control
from .roles import (
    UserRole, Permission,
    get_current_user_role, get_user_role,
    has_permission, has_any_permission, has_all_permissions,
    is_admin, require_permission, require_role, require_admin,
    get_role_display_name, show_user_badge
)
