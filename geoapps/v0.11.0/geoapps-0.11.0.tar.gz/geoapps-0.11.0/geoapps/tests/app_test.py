import streamlit as st
import pandas as pd
import numpy as np
import os
import folium
from streamlit_folium import st_folium
import geopandas as gpd

# Titolo della pagina
st.title("Hello Streamlit! test")

# Testo descrittivo
st.write("Questa è una semplice app di test per Streamlit.")

# Slider interattivo
number = st.slider("Scegli un numero", 0, 100, 50)
st.write(f"Hai scelto: {number}")

# Generazione di un DataFrame casuale
st.write("Esempio di DataFrame:")
df = pd.DataFrame(
    np.random.randn(10, 3),
    columns=["A", "B", "C"]
)
st.dataframe(df)

# Grafico a linee semplice
st.line_chart(df)


DATA_DIR = "/var/geoapps/geoapps_storage/remap/parquetdata"  # la directory da cui leggere

st.title("Lista dei file 📂")

# ottieni lista dei file
files = os.listdir(DATA_DIR)

# mostra la lista
for f in files:
        st.write(f)

gdf = gpd.read_parquet("/var/geoapps/geoapps_storage/remap/parquetdata/areas_of_interest.parquet")
gdf = gdf.to_crs(epsg=4326)

m = folium.Map(location=[gdf.geometry.centroid.y.mean(),
                                                  gdf.geometry.centroid.x.mean()],
                              zoom_start=6)

folium.GeoJson(gdf).add_to(m)

st.title("Mappa interattiva con Folium")
st_folium(m, width=700, height=500)
