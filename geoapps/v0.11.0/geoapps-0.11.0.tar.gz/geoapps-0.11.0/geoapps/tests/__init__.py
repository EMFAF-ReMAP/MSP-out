"""Test suite per l'applicazione geoapps."""
