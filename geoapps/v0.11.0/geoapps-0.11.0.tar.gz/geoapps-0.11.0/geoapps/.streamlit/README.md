# Streamlit Configuration

This directory contains the configuration files for the Streamlit application.

## Files

### `config.toml`
Main configuration file for Streamlit server and theme settings.

**Key configurations:**
- `server.headless = true` - Run in headless mode (no browser auto-open)
- `server.port = 8501` - Default port for the application
- Theme settings for consistent UI appearance

## Configuration Priority

Streamlit loads configuration in this order:
1. Command-line arguments (highest priority)
2. Environment variables
3. `.streamlit/config.toml` in the project directory
4. Global `~/.streamlit/config.toml` (lowest priority)

## Notes

- CORS is enabled by default for XSRF protection compatibility
- Configuration is copied into the Docker container during build
- Changes to this file require rebuilding the Docker image

## Reference

For more information, see the [Streamlit Configuration Documentation](https://docs.streamlit.io/library/advanced-features/configuration)
