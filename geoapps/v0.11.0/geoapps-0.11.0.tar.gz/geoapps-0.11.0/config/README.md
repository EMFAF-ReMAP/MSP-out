# Configuration Templates

Configuration templates for different environments.

## Files

- **`config.development.yaml`** - Local development (Windows/Mac)
- **`config.production.yaml`** - Production server (Linux)  
- **`secrets.yaml.example`** - Secrets template

## Usage

**Development:**
```bash
cp config/config.development.yaml config.yaml
```

**Production:**
```bash
cp config/config.production.yaml config.yaml
```

**Secrets:**
```bash
cp config/secrets.yaml.example secrets.yaml
nano secrets.yaml  # Edit with real values
```

## Notes

- `config.yaml` in root is NOT committed (`.gitignore`)
- Templates in `config/` ARE committed
- Never commit passwords or secrets
