#!/usr/bin/env python3
"""
Test script for the enhanced authentication system with concurrent users and session timeout
"""

import sqlite3
import hashlib
import os
import time
from datetime import datetime, timedelta
import uuid
from pathlib import Path

# Get the project root directory (parent of scripts)
PROJECT_ROOT = Path(__file__).parent.parent
DATABASE_PATH = PROJECT_ROOT / "geoapps_storage" / "auth.db"
MAX_CONCURRENT_USERS = 5
SESSION_TIMEOUT_MINUTES = 10

def hash_password(password: str) -> str:
    """Hash a password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def init_database():
    """Initialize the authentication database"""
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create sessions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_sessions (
            session_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (username) REFERENCES users (username)
        )
    ''')
    
    # Sample users
    sample_users = [
        ("admin", "Admin2025!", "Administrator", "admin@cnr-ismar.it"),
        ("demo", "demo", "Demo User", "demo@cnr-ismar.it"),
        ("test1", "test1", "Test User 1", "test1@cnr-ismar.it"),
        ("test2", "test2", "Test User 2", "test2@cnr-ismar.it"),
        ("test3", "test3", "Test User 3", "test3@cnr-ismar.it"),
    ]
    
    for username, password, full_name, email in sample_users:
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        if cursor.fetchone()[0] == 0:
            password_hash = hash_password(password)
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, email) VALUES (?, ?, ?, ?)",
                (username, password_hash, full_name, email)
            )
    
    conn.commit()
    conn.close()

def create_test_session(username: str) -> str:
    """Create a test session"""
    session_id = str(uuid.uuid4())
    
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO user_sessions (session_id, username, login_time, last_activity, is_active)
        VALUES (?, ?, ?, ?, 1)
    ''', (session_id, username, datetime.now().isoformat(), datetime.now().isoformat()))
    
    conn.commit()
    conn.close()
    
    return session_id

def get_active_sessions():
    """Get active sessions"""
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT us.session_id, us.username, us.login_time, us.last_activity, u.full_name
        FROM user_sessions us
        JOIN users u ON us.username = u.username
        WHERE us.is_active = 1
        ORDER BY us.login_time DESC
    ''')
    
    sessions = cursor.fetchall()
    conn.close()
    
    return sessions

def cleanup_expired_sessions():
    """Clean up expired sessions"""
    expiry_time = datetime.now() - timedelta(minutes=SESSION_TIMEOUT_MINUTES)
    
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    cursor.execute(
        "DELETE FROM user_sessions WHERE last_activity < ? OR is_active = 0",
        (expiry_time.isoformat(),)
    )
    
    deleted = cursor.rowcount
    conn.commit()
    conn.close()
    
    return deleted

def test_concurrent_users():
    """Test concurrent user functionality"""
    print("🧪 Testing Concurrent User Management...")
    
    # Initialize database
    init_database()
    
    # Clean up any existing sessions
    cleanup_expired_sessions()
    
    print(f"📋 Creating test sessions (max: {MAX_CONCURRENT_USERS})...")
    
    # Create sessions up to limit
    sessions = []
    for i in range(MAX_CONCURRENT_USERS + 2):  # Try to exceed limit
        username = f"test{i+1}" if i < 5 else f"user{i+1}"
        
        # Check current active count
        active_sessions = get_active_sessions()
        active_count = len(active_sessions)
        
        if active_count < MAX_CONCURRENT_USERS:
            session_id = create_test_session(username)
            sessions.append(session_id)
            print(f"  ✅ Created session for {username} ({active_count + 1}/{MAX_CONCURRENT_USERS})")
        else:
            print(f"  ❌ Cannot create session for {username} - limit reached ({active_count}/{MAX_CONCURRENT_USERS})")
    
    # Show current sessions
    print(f"\n📊 Current Active Sessions:")
    active_sessions = get_active_sessions()
    for session in active_sessions:
        session_id, username, login_time, last_activity, full_name = session
        login_dt = datetime.fromisoformat(login_time)
        duration = datetime.now() - login_dt
        print(f"  • {username} ({full_name}) - {str(duration).split('.')[0]}")
    
    print(f"\n📈 Statistics:")
    print(f"  • Active sessions: {len(active_sessions)}")
    print(f"  • Maximum allowed: {MAX_CONCURRENT_USERS}")
    print(f"  • Available slots: {max(0, MAX_CONCURRENT_USERS - len(active_sessions))}")
    
    return len(active_sessions)

def test_session_timeout():
    """Test session timeout functionality"""
    print(f"\n🕐 Testing Session Timeout (timeout: {SESSION_TIMEOUT_MINUTES} minutes)...")
    
    # Create an old session (simulate expired)
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    old_time = datetime.now() - timedelta(minutes=SESSION_TIMEOUT_MINUTES + 1)
    session_id = str(uuid.uuid4())
    
    cursor.execute('''
        INSERT INTO user_sessions (session_id, username, login_time, last_activity, is_active)
        VALUES (?, ?, ?, ?, 1)
    ''', (session_id, "test_expired", old_time.isoformat(), old_time.isoformat()))
    
    conn.commit()
    conn.close()
    
    print(f"  📅 Created expired session (age: {SESSION_TIMEOUT_MINUTES + 1} minutes)")
    
    # Count before cleanup
    before_count = len(get_active_sessions())
    
    # Clean up expired sessions
    deleted = cleanup_expired_sessions()
    
    # Count after cleanup
    after_count = len(get_active_sessions())
    
    print(f"  🧹 Cleanup results:")
    print(f"    • Sessions before: {before_count}")
    print(f"    • Sessions deleted: {deleted}")
    print(f"    • Sessions after: {after_count}")
    
    return deleted > 0

def main():
    print("🚀 Testing Enhanced Authentication System")
    print("=" * 50)
    
    # Test 1: Concurrent users
    active_count = test_concurrent_users()
    
    # Test 2: Session timeout
    timeout_working = test_session_timeout()
    
    # Final summary
    print(f"\n✅ Test Summary:")
    print(f"  • Concurrent user limit: {'✅ Working' if active_count <= MAX_CONCURRENT_USERS else '❌ Failed'}")
    print(f"  • Session timeout: {'✅ Working' if timeout_working else '❌ Failed'}")
    print(f"  • Database location: {DATABASE_PATH}")
    
    print(f"\n🔧 Configuration:")
    print(f"  • Max concurrent users: {MAX_CONCURRENT_USERS}")
    print(f"  • Session timeout: {SESSION_TIMEOUT_MINUTES} minutes")
    
    print(f"\n🎯 Ready to test with Streamlit!")
    print(f"  • Run: streamlit run app/streamlit_app.py")
    print(f"  • Open multiple browser tabs to test concurrent limits")
    print(f"  • Wait {SESSION_TIMEOUT_MINUTES} minutes without activity to test timeout")

if __name__ == "__main__":
    main()
