#!/usr/bin/env python3
"""
Test script for authentication system
This creates the database and shows sample users without needing streamlit
"""

import sqlite3
import hashlib
import os
from pathlib import Path

# Get the project root directory (parent of scripts)
PROJECT_ROOT = Path(__file__).parent.parent
DATABASE_PATH = PROJECT_ROOT / "geoapps_storage" / "auth.db"

def hash_password(password: str) -> str:
    """Hash a password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def init_database():
    """Initialize the authentication database with sample users"""
    # Ensure data directory exists
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Sample users (username, password, full_name, email)
    sample_users = [
        ("admin", "Admin2025!", "Administrator", "admin@cnr-ismar.it"),
        ("scientist1", "password123", "Dr. Maria Rossi", "maria.rossi@cnr-ismar.it"),
        ("scientist2", "secure456", "Dr. Giovanni Bianchi", "giovanni.bianchi@cnr-ismar.it"),
        ("researcher1", "research789", "Dr. Anna Verdi", "anna.verdi@cnr-ismar.it"),
        ("researcher2", "data2024", "Dr. Marco Neri", "marco.neri@cnr-ismar.it"),
        ("analyst1", "analysis321", "Dr. Lucia Ferrari", "lucia.ferrari@cnr-ismar.it"),
        ("analyst2", "spatial987", "Dr. Paolo Conti", "paolo.conti@cnr-ismar.it"),
        ("guest1", "Guest@CNR1", "Guest User 1", "guest1@cnr-ismar.it"),
        ("guest2", "Guest@CNR2", "Guest User 2", "guest2@cnr-ismar.it"),
        ("demo", "demo", "Demo User", "demo@cnr-ismar.it"),
    ]
    
    # Insert sample users if they don't exist
    for username, password, full_name, email in sample_users:
        cursor.execute(
            "SELECT COUNT(*) FROM users WHERE username = ?", 
            (username,)
        )
        if cursor.fetchone()[0] == 0:
            password_hash = hash_password(password)
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, email) VALUES (?, ?, ?, ?)",
                (username, password_hash, full_name, email)
            )
    
    conn.commit()
    conn.close()
    return True

def test_authentication(username: str, password: str):
    """Test authentication for a user"""
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    password_hash = hash_password(password)
    cursor.execute(
        "SELECT id, username, full_name, email FROM users WHERE username = ? AND password_hash = ?",
        (username, password_hash)
    )
    
    result = cursor.fetchone()
    conn.close()
    
    if result:
        return {
            "id": result[0],
            "username": result[1],
            "full_name": result[2],
            "email": result[3]
        }
    return None

def get_all_users():
    """Get all users from the database"""
    conn = sqlite3.connect(str(DATABASE_PATH))
    cursor = conn.cursor()
    
    cursor.execute("SELECT username, full_name, email, created_at FROM users ORDER BY username")
    users = cursor.fetchall()
    conn.close()
    
    return users

def main():
    print("🚀 Initializing CNR-ISMAR authentication database...")
    
    # Initialize the database
    init_database()
    
    # Show all users
    print("\n👥 Sample users created:")
    users = get_all_users()
    
    print(f"{'Username':<15} {'Full Name':<25} {'Email':<30}")
    print("-" * 70)
    
    for username, full_name, email, created_at in users:
        print(f"{username:<15} {full_name:<25} {email:<30}")
    
    print(f"\n✅ Database initialized successfully!")
    print(f"📂 Database location: {DATABASE_PATH}")
    print(f"👤 Total users: {len(users)}")
    
    print("\n🔐 Sample login credentials:")
    credentials = [
        ("admin", "Admin2025!", "Administrator access"),
        ("scientist1", "password123", "Scientist user"),
        ("demo", "demo", "Demo user"),
    ]
    
    for username, password, description in credentials:
        print(f"  • {username} / {password} - {description}")
    
    # Test authentication
    print("\n🧪 Testing authentication...")
    for username, password, _ in credentials[:2]:
        user = test_authentication(username, password)
        if user:
            print(f"  ✅ {username}: Authentication successful - {user['full_name']}")
        else:
            print(f"  ❌ {username}: Authentication failed")

if __name__ == "__main__":
    main()
