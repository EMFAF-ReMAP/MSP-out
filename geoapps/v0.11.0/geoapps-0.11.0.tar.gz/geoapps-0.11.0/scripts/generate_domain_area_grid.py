#generate_domain_area_grid.py
import json
import pickle
import numpy as np
import geopandas as gpd
from shapely.geometry import shape, box
import os

# Resolution in meters (instead of degrees) for a more regular grid
GRID_RESOLUTION_METERS = 30000  # 30 km
INPUT_PATH = "geoapps_storage/domain_areas.json"
OUTPUT_PATH = "geoapps_storage/domain_area_grid.pkl"

print("🔁 Loading domain areas...")
with open(INPUT_PATH, "r", encoding="utf-8") as f:
    raw_data = json.load(f)

# Build GeoDataFrame of domain areas
domain_areas = []
for entry in raw_data:
    if not entry.get("geo"):
        continue
    geom = shape(entry["geo"])
    label = entry["label"]
    domain_areas.append({
        "label": label,
        "geometry": geom
    })

gdf = gpd.GeoDataFrame(domain_areas, crs="EPSG:4326")

print("🗺️  Reprojecting to Web Mercator...")
# Reproject to Web Mercator for a regular grid
gdf_mercator = gdf.to_crs("EPSG:3857")

# Costruisci la griglia in metri
minx, miny, maxx, maxy = gdf_mercator.total_bounds

# Expand bounds slightly to have a complete grid
margin = GRID_RESOLUTION_METERS * 0.5
minx -= margin
miny -= margin
maxx += margin
maxy += margin

# Create grid coordinates in meters
x_coords = np.arange(minx, maxx, GRID_RESOLUTION_METERS)
y_coords = np.arange(miny, maxy, GRID_RESOLUTION_METERS)

print(f"📏 Grid dimensions: {len(x_coords)} x {len(y_coords)} = {len(x_coords) * len(y_coords)} cells")

# Create grid cells
grid_cells = []
for x in x_coords:
    for y in y_coords:
        cell = box(x, y, x + GRID_RESOLUTION_METERS, y + GRID_RESOLUTION_METERS)
        grid_cells.append(cell)

print("🔧 Creating grid GeoDataFrame...")
grid_gdf = gpd.GeoDataFrame(geometry=grid_cells, crs="EPSG:3857")
grid_gdf["domain_areas"] = [[] for _ in range(len(grid_gdf))]

print("🧠 Intersecting domain areas with grid...")
# Intersect domain areas with the grid
for i, domain_row in gdf_mercator.iterrows():
    geom = domain_row["geometry"]
    label = domain_row["label"]
    
    # Find cells that intersect this domain area
    intersects = grid_gdf.geometry.intersects(geom)
    
    for idx in grid_gdf[intersects].index:
        grid_gdf.at[idx, "domain_areas"].append(label)
    
    if (i + 1) % 10 == 0:
        print(f"   Processed {i + 1}/{len(gdf_mercator)} domain areas...")

# Remove duplicates and convert to list
grid_gdf["domain_areas"] = grid_gdf["domain_areas"].apply(lambda lst: list(set(lst)))

# Remove empty cells for optimization
grid_gdf = grid_gdf[grid_gdf["domain_areas"].apply(len) > 0].reset_index(drop=True)

print("🔄 Converting back to WGS84...")
# Convert back to WGS84 for compatibility with the rest of the code
grid_gdf_wgs84 = grid_gdf.to_crs("EPSG:4326")

# DEBUG
non_empty = [d for d in grid_gdf_wgs84["domain_areas"] if d]
print(f"📌 Numero di celle non vuote: {len(non_empty)}")
print(f"📌 Esempi di domain areas: {non_empty[:2] if non_empty else 'Nessuna'}")

# Save grid information
grid_info = {
    'resolution_meters': GRID_RESOLUTION_METERS,
    'total_cells': len(grid_gdf_wgs84),
    'non_empty_cells': len(non_empty),
    'bounds_wgs84': grid_gdf_wgs84.total_bounds.tolist(),
    'crs_original': 'EPSG:3857',
    'crs_final': 'EPSG:4326'
}

print(f"💾 Saving grid to: {OUTPUT_PATH}")
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
with open(OUTPUT_PATH, "wb") as f:
    pickle.dump({
        'grid': grid_gdf_wgs84,
        'info': grid_info
    }, f)

print("✅ Done.")
print(f"Grid info: {grid_info}")

# Helper function to load data
def load_grid_with_info(grid_path):
    """Load the grid with associated information"""
    with open(grid_path, "rb") as f:
        data = pickle.load(f)
    if isinstance(data, dict):
        return data['grid'], data.get('info', {})
    else:
        # Backward compatibility with old format
        return data, {}