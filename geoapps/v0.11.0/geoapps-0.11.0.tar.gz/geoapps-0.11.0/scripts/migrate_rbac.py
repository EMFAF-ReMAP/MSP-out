#!/usr/bin/env python3
"""
Script di migrazione per aggiungere il campo 'role' al database esistente.
Questo script è idempotente - può essere eseguito multiple volte senza problemi.
"""

import sys
from pathlib import Path

# Setup path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "geoapps"))

from auth.auth import DATABASE_PATH, init_database

def main():
    print("=" * 80)
    print("🔧 RBAC Migration Script")
    print("   Adding 'role' column to users table")
    print("=" * 80)
    print()
    
    print(f"📂 Database path: {DATABASE_PATH}")
    print()
    
    # Run init_database which will handle the migration
    print("🚀 Running database initialization and migration...")
    init_database()
    
    print()
    print("=" * 80)
    print("✅ Migration completed successfully!")
    print("=" * 80)
    print()
    print("Next steps:")
    print("1. Test with: python scripts/test_rbac.py")
    print("2. Start the app and test role-based features")
    print("3. Admin can modify user roles in the RBAC Example page")
    print()

if __name__ == "__main__":
    main()
