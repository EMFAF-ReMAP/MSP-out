"""
Role-based access control (RBAC) module.
Provides utilities to check user roles and permissions.
"""

from typing import Optional, List
from enum import Enum
import streamlit as st


class UserRole(Enum):
    """User role definitions"""
    ADMIN = "admin"
    SCIENTIST = "scientist"
    RESEARCHER = "researcher"
    ANALYST = "analyst"
    GUEST = "guest"
    DEMO = "demo"


class Permission(Enum):
    """Permission definitions"""
    # Data permissions
    VIEW_DATA = "view_data"
    DOWNLOAD_DATA = "download_data"
    UPLOAD_DATA = "upload_data"
    DELETE_DATA = "delete_data"
    
    # Publishing permissions
    PUBLISH_DIRECT = "publish_direct"  # Publish without approval
    PUBLISH_REQUEST = "publish_request"  # Request to publish
    
    # Admin permissions
    MANAGE_USERS = "manage_users"
    VIEW_LOGS = "view_logs"
    SYSTEM_CONFIG = "system_config"


# Role -> Permissions mapping
ROLE_PERMISSIONS = {
    UserRole.ADMIN: [
        # All permissions for admin
        Permission.VIEW_DATA,
        Permission.DOWNLOAD_DATA,
        Permission.UPLOAD_DATA,
        Permission.DELETE_DATA,
        Permission.PUBLISH_DIRECT,
        Permission.MANAGE_USERS,
        Permission.VIEW_LOGS,
        Permission.SYSTEM_CONFIG,
    ],
    UserRole.SCIENTIST: [
        Permission.VIEW_DATA,
        Permission.DOWNLOAD_DATA,
        Permission.UPLOAD_DATA,
        Permission.PUBLISH_REQUEST,  # Can request publishing, not direct
    ],
    UserRole.RESEARCHER: [
        Permission.VIEW_DATA,
        Permission.DOWNLOAD_DATA,
        Permission.UPLOAD_DATA,
        Permission.PUBLISH_REQUEST,
    ],
    UserRole.ANALYST: [
        Permission.VIEW_DATA,
        Permission.DOWNLOAD_DATA,
        Permission.PUBLISH_REQUEST,
    ],
    UserRole.GUEST: [
        Permission.VIEW_DATA,
        Permission.DOWNLOAD_DATA,
    ],
    UserRole.DEMO: [
        Permission.VIEW_DATA,
        # Demo users can only view, no downloads
    ],
}


def _get_role_from_database(username: str) -> Optional[UserRole]:
    """
    Fetch user role from database.
    
    Args:
        username: The username to look up
        
    Returns:
        UserRole if found, None otherwise
    """
    import sqlite3
    import os
    
    # Import DATABASE_PATH from auth module
    try:
        from .auth import DATABASE_PATH
    except ImportError:
        from auth.auth import DATABASE_PATH
    
    if not os.path.exists(DATABASE_PATH):
        return None
    
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=10.0)
        cursor = conn.cursor()
        cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
        row = cursor.fetchone()
        conn.close()
        
        if row and row[0]:
            try:
                return UserRole(row[0])
            except ValueError:
                # Invalid role in DB, default to guest
                return UserRole.GUEST
        
        return None
    except Exception:
        return None


def get_current_user_role() -> Optional[UserRole]:
    """
    Get the role of the currently logged-in user from Streamlit session state.
    
    Returns:
        UserRole if user is logged in, None otherwise
    """
    if not st.session_state.get("logged_in", False):
        return None
    
    username = st.session_state.get("username")
    if not username:
        return None
    
    # Get role from database
    role = _get_role_from_database(username)
    return role if role else UserRole.GUEST


def get_user_role(username: str) -> UserRole:
    """
    Get the role for a specific username from database.
    
    Args:
        username: The username to check
        
    Returns:
        UserRole enum value (defaults to GUEST if not found)
    """
    role = _get_role_from_database(username)
    return role if role else UserRole.GUEST


def has_permission(permission: Permission, username: Optional[str] = None) -> bool:
    """
    Check if the current user (or specified user) has a specific permission.
    
    Args:
        permission: The Permission to check
        username: Optional username to check. If None, checks current logged-in user.
        
    Returns:
        True if user has permission, False otherwise
    """
    if username:
        role = get_user_role(username)
    else:
        role = get_current_user_role()
    
    if not role:
        return False
    
    role_perms = ROLE_PERMISSIONS.get(role, [])
    return permission in role_perms


def has_any_permission(permissions: List[Permission], username: Optional[str] = None) -> bool:
    """
    Check if user has ANY of the specified permissions.
    
    Args:
        permissions: List of Permission to check
        username: Optional username to check. If None, checks current logged-in user.
        
    Returns:
        True if user has at least one permission, False otherwise
    """
    return any(has_permission(perm, username) for perm in permissions)


def has_all_permissions(permissions: List[Permission], username: Optional[str] = None) -> bool:
    """
    Check if user has ALL of the specified permissions.
    
    Args:
        permissions: List of Permission to check
        username: Optional username to check. If None, checks current logged-in user.
        
    Returns:
        True if user has all permissions, False otherwise
    """
    return all(has_permission(perm, username) for perm in permissions)


def is_admin(username: Optional[str] = None) -> bool:
    """
    Check if user is an admin.
    
    Args:
        username: Optional username to check. If None, checks current logged-in user.
        
    Returns:
        True if user is admin, False otherwise
    """
    if username:
        role = get_user_role(username)
    else:
        role = get_current_user_role()
    
    return role == UserRole.ADMIN


def require_permission(permission: Permission, error_message: Optional[str] = None):
    """
    Guard function that stops execution if user doesn't have permission.
    Use this at the top of protected pages or before protected operations.
    
    Args:
        permission: The required Permission
        error_message: Optional custom error message
        
    Raises:
        st.stop() if permission is denied
    """
    if not has_permission(permission):
        if error_message:
            st.error(error_message)
        else:
            st.error(f"🚫 Access denied. You don't have permission: {permission.value}")
        st.stop()


def require_role(required_role: UserRole, error_message: Optional[str] = None):
    """
    Guard function that stops execution if user doesn't have the required role.
    
    Args:
        required_role: The required UserRole
        error_message: Optional custom error message
        
    Raises:
        st.stop() if role doesn't match
    """
    current_role = get_current_user_role()
    if current_role != required_role:
        if error_message:
            st.error(error_message)
        else:
            st.error(f"🚫 Access denied. Required role: {required_role.value}")
        st.stop()


def require_admin(error_message: Optional[str] = None):
    """
    Guard function that stops execution if user is not an admin.
    Convenience wrapper around require_role.
    
    Args:
        error_message: Optional custom error message
        
    Raises:
        st.stop() if user is not admin
    """
    if not is_admin():
        if error_message:
            st.error(error_message)
        else:
            st.error("🚫 Access denied. Admin privileges required.")
        st.stop()


def get_role_display_name(role: UserRole) -> str:
    """
    Get a human-readable display name for a role.
    
    Args:
        role: The UserRole
        
    Returns:
        Display name string
    """
    display_names = {
        UserRole.ADMIN: "👑 Administrator",
        UserRole.SCIENTIST: "🔬 Scientist",
        UserRole.RESEARCHER: "🔍 Researcher",
        UserRole.ANALYST: "📊 Analyst",
        UserRole.GUEST: "👤 Guest",
        UserRole.DEMO: "🎯 Demo User",
    }
    return display_names.get(role, "Unknown")


def show_user_badge():
    """
    Display a badge showing the current user's role and permissions.
    Can be called in sidebar or main area.
    """
    role = get_current_user_role()
    if not role:
        return
    
    username = st.session_state.get("username", "Unknown")
    role_name = get_role_display_name(role)
    
    st.sidebar.markdown("---")
    st.sidebar.markdown(f"**User:** {username}")
    st.sidebar.markdown(f"**Role:** {role_name}")
    
    # Show key permissions
    perms = ROLE_PERMISSIONS.get(role, [])
    if perms:
        with st.sidebar.expander("🔑 Your Permissions"):
            for perm in perms:
                st.write(f"✓ {perm.value.replace('_', ' ').title()}")
