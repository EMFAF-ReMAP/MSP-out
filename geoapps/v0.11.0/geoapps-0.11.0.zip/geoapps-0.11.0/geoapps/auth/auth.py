"""
Authentication module for the Streamlit app
Handles user login, logout, database operations, concurrent users and session timeout,
plus persistent per-browser login tokens.
"""

import os
import sqlite3
import hashlib
import uuid
import time
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, List

import streamlit as st

# Import default values
try:
    from core.defaults import (
        DATABASE_PATH as DEFAULT_DATABASE_PATH,
        MAX_CONCURRENT_USERS as DEFAULT_MAX_CONCURRENT_USERS,
        SESSION_TIMEOUT_MINUTES as DEFAULT_SESSION_TIMEOUT_MINUTES,
        MAX_DEMO_QUEUE_SIZE as DEFAULT_MAX_DEMO_QUEUE_SIZE,
        DEMO_QUEUE_TIMEOUT_MINUTES as DEFAULT_DEMO_QUEUE_TIMEOUT_MINUTES,
        SQLITE_TIMEOUT as DEFAULT_SQLITE_TIMEOUT,
        SQLITE_MAX_RETRIES as DEFAULT_SQLITE_MAX_RETRIES,
        SQLITE_RETRY_SLEEP as DEFAULT_SQLITE_RETRY_SLEEP,
    )
except ImportError:
    # Fallback if defaults module is not available
    DEFAULT_DATABASE_PATH = "geoapps_storage/auth.db"
    DEFAULT_MAX_CONCURRENT_USERS = 2
    DEFAULT_SESSION_TIMEOUT_MINUTES = 10
    DEFAULT_MAX_DEMO_QUEUE_SIZE = 20
    DEFAULT_DEMO_QUEUE_TIMEOUT_MINUTES = 30
    DEFAULT_SQLITE_TIMEOUT = 10.0
    DEFAULT_SQLITE_MAX_RETRIES = 5
    DEFAULT_SQLITE_RETRY_SLEEP = 0.2

# Try to load from configuration, otherwise use defaults
try:
    from core.config import get_config_value
    DATABASE_PATH = get_config_value("auth.database_path", DEFAULT_DATABASE_PATH)
    MAX_CONCURRENT_USERS = get_config_value("auth.max_concurrent_users", DEFAULT_MAX_CONCURRENT_USERS)
    SESSION_TIMEOUT_MINUTES = get_config_value("auth.session_timeout_minutes", DEFAULT_SESSION_TIMEOUT_MINUTES)
    MAX_DEMO_QUEUE_SIZE = get_config_value("auth.max_demo_queue_size", DEFAULT_MAX_DEMO_QUEUE_SIZE)
    DEMO_QUEUE_TIMEOUT_MINUTES = get_config_value("auth.demo_queue_timeout_minutes", DEFAULT_DEMO_QUEUE_TIMEOUT_MINUTES)
    SQLITE_TIMEOUT = get_config_value("database.sqlite_timeout", DEFAULT_SQLITE_TIMEOUT)
    SQLITE_MAX_RETRIES = get_config_value("database.sqlite_max_retries", DEFAULT_SQLITE_MAX_RETRIES)
    SQLITE_RETRY_SLEEP = get_config_value("database.sqlite_retry_sleep", DEFAULT_SQLITE_RETRY_SLEEP)
except ImportError:
    # Config module not available, use defaults
    DATABASE_PATH = DEFAULT_DATABASE_PATH
    MAX_CONCURRENT_USERS = DEFAULT_MAX_CONCURRENT_USERS
    SESSION_TIMEOUT_MINUTES = DEFAULT_SESSION_TIMEOUT_MINUTES
    MAX_DEMO_QUEUE_SIZE = DEFAULT_MAX_DEMO_QUEUE_SIZE
    DEMO_QUEUE_TIMEOUT_MINUTES = DEFAULT_DEMO_QUEUE_TIMEOUT_MINUTES
    SQLITE_TIMEOUT = DEFAULT_SQLITE_TIMEOUT
    SQLITE_MAX_RETRIES = DEFAULT_SQLITE_MAX_RETRIES
    SQLITE_RETRY_SLEEP = DEFAULT_SQLITE_RETRY_SLEEP


# ──────────────────────────────────────────────────────────────
# Utilities
# ──────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    """Hash a password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()


def _ensure_persistent_login_columns():
    """Add columns for persistent login if they don't exist."""
    if not os.path.exists(DATABASE_PATH):
        init_database()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    try:
        cur.execute("PRAGMA table_info(user_sessions)")
        cols = {row[1] for row in cur.fetchall()}
        to_add = []
        if "persistent_token" not in cols:
            to_add.append("ALTER TABLE user_sessions ADD COLUMN persistent_token TEXT")
        if "client_id" not in cols:
            to_add.append("ALTER TABLE user_sessions ADD COLUMN client_id TEXT")
        if "expires_at" not in cols:
            to_add.append("ALTER TABLE user_sessions ADD COLUMN expires_at TIMESTAMP")
        for stmt in to_add:
            cur.execute(stmt)
        conn.commit()
    finally:
        conn.close()


def _ensure_role_column():
    """Add role column to users table if it doesn't exist and populate from username patterns."""
    if not os.path.exists(DATABASE_PATH):
        init_database()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    try:
        # Check if role column exists
        cur.execute("PRAGMA table_info(users)")
        cols = {row[1] for row in cur.fetchall()}
        
        if "role" not in cols:
            # Add role column
            cur.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'guest'")
            
            # Populate roles based on username patterns (migration)
            cur.execute("UPDATE users SET role = 'admin' WHERE username = 'admin'")
            cur.execute("UPDATE users SET role = 'scientist' WHERE username LIKE 'scientist%'")
            cur.execute("UPDATE users SET role = 'researcher' WHERE username LIKE 'researcher%'")
            cur.execute("UPDATE users SET role = 'analyst' WHERE username LIKE 'analyst%'")
            cur.execute("UPDATE users SET role = 'guest' WHERE username LIKE 'guest%'")
            cur.execute("UPDATE users SET role = 'demo' WHERE username LIKE 'demo%'")
            
            conn.commit()
            print(f"✅ Added 'role' column to users table and populated from username patterns")
    finally:
        conn.close()


# ──────────────────────────────────────────────────────────────
# DB init
# ──────────────────────────────────────────────────────────────
def init_database():
    """Initialize the authentication database with sample users and tables."""
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()

    # Users
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            email TEXT,
            role TEXT DEFAULT 'guest',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    # Sessions
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS user_sessions (
            session_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            browser_id TEXT,
            login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1,
            persistent_token TEXT,
            client_id TEXT,
            expires_at TIMESTAMP,
            FOREIGN KEY (username) REFERENCES users (username)
        )
        """
    )

    # Demo queue
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS demo_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            browser_id TEXT UNIQUE NOT NULL,
            reservation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            estimated_wait_minutes INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1
        )
        """
    )

    # Seed users (username, password, full_name, email, role)
    sample_users = [
        ("admin", "Admin2025!", "Administrator", "admin@cnr-ismar.it", "admin"),
        ("scientist1", "password123", "Dr. Maria Rossi", "maria.rossi@cnr-ismar.it", "scientist"),
        ("scientist2", "secure456", "Dr. Giovanni Bianchi", "giovanni.bianchi@cnr-ismar.it", "scientist"),
        ("researcher1", "research789", "Dr. Anna Verdi", "anna.verdi@cnr-ismar.it", "researcher"),
        ("researcher2", "data2024", "Dr. Marco Neri", "marco.neri@cnr-ismar.it", "researcher"),
        ("analyst1", "analysis321", "Dr. Lucia Ferrari", "lucia.ferrari@cnr-ismar.it", "analyst"),
        ("analyst2", "spatial987", "Dr. Paolo Conti", "paolo.conti@cnr-ismar.it", "analyst"),
        ("guest1", "Guest@CNR1", "Guest User 1", "guest1@cnr-ismar.it", "guest"),
        ("guest2", "Guest@CNR2", "Guest User 2", "guest2@cnr-ismar.it", "guest"),
        ("demo", "demo", "Demo User", "demo@cnr-ismar.it", "demo"),
        ("demo1", "demo", "Demo Slot 1", "demo1@cnr-ismar.it", "demo"),
        ("demo2", "demo", "Demo Slot 2", "demo2@cnr-ismar.it", "demo"),
        ("demo3", "demo", "Demo Slot 3", "demo3@cnr-ismar.it", "demo"),
        ("demo4", "demo", "Demo Slot 4", "demo4@cnr-ismar.it", "demo"),
        ("demo5", "demo", "Demo Slot 5", "demo5@cnr-ismar.it", "demo"),
    ]

    for username, password, full_name, email, role in sample_users:
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        user_exists = cursor.fetchone()[0] > 0
        
        password_hash = hash_password(password)
        
        if user_exists:
            # Update existing user (password and role might have changed in code)
            cursor.execute(
                "UPDATE users SET password_hash = ?, full_name = ?, email = ?, role = ? WHERE username = ?",
                (password_hash, full_name, email, role, username),
            )
        else:
            # Insert new user
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, email, role) VALUES (?, ?, ?, ?, ?)",
                (username, password_hash, full_name, email, role),
            )

    conn.commit()
    conn.close()
    print(f"✅ Authentication database initialized at {DATABASE_PATH}")

    # Ensure persistent-login columns exist (idempotent)
    _ensure_persistent_login_columns()
    
    # Ensure role column exists (idempotent migration)
    _ensure_role_column()


# ──────────────────────────────────────────────────────────────
# Auth primitives
# ──────────────────────────────────────────────────────────────
def authenticate_user(username: str, password: str) -> Optional[dict]:
    """Check username/password and return user info including role if valid."""
    if not os.path.exists(DATABASE_PATH):
        init_database()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    password_hash = hash_password(password)
    cursor.execute(
        "SELECT id, username, full_name, email, role FROM users WHERE username = ? AND password_hash = ?",
        (username, password_hash),
    )
    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            "id": row[0], 
            "username": row[1], 
            "full_name": row[2], 
            "email": row[3],
            "role": row[4] if len(row) > 4 else "guest"  # Fallback for old DB
        }
    return None


def cleanup_expired_sessions():
    """Remove expired or inactive sessions."""
    if not os.path.exists(DATABASE_PATH):
        return

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    try:
        expiry_time = datetime.now() - timedelta(minutes=SESSION_TIMEOUT_MINUTES)
        cursor.execute(
            "DELETE FROM user_sessions WHERE last_activity < ? OR is_active = 0",
            (expiry_time.isoformat(),),
        )
        conn.commit()
    finally:
        conn.close()


def cleanup_expired_queue():
    """Remove expired queue entries (users waiting longer than DEMO_QUEUE_TIMEOUT_MINUTES)."""
    if not os.path.exists(DATABASE_PATH):
        return

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    try:
        expiry_time = datetime.now() - timedelta(minutes=DEMO_QUEUE_TIMEOUT_MINUTES)
        cursor.execute(
            "UPDATE demo_queue SET is_active = 0 WHERE reservation_time < ? AND is_active = 1",
            (expiry_time.isoformat(),),
        )
        deleted_count = cursor.rowcount
        conn.commit()
        if deleted_count > 0:
            print(f"🧹 Cleaned up {deleted_count} expired queue entries")
    finally:
        conn.close()


def get_active_sessions_count() -> int:
    """Number of active sessions (any user)."""
    cleanup_expired_sessions()
    if not os.path.exists(DATABASE_PATH):
        return 0

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT COUNT(*) FROM user_sessions WHERE is_active = 1")
        return cursor.fetchone()[0]
    finally:
        conn.close()


def get_active_sessions_info() -> List[Dict]:
    """Return details of active sessions."""
    cleanup_expired_sessions()
    if not os.path.exists(DATABASE_PATH):
        return []

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT us.session_id, us.username, us.browser_id, us.login_time, us.last_activity, u.full_name
        FROM user_sessions us
        JOIN users u ON us.username = u.username
        WHERE us.is_active = 1
        ORDER BY us.login_time DESC
        """
    )
    sessions = []
    for row in cursor.fetchall():
        sessions.append(
            {
                "session_id": row[0],
                "username": row[1],
                "browser_id": row[2],
                "login_time": row[3],
                "last_activity": row[4],
                "full_name": row[5],
            }
        )
    conn.close()
    return sessions


def can_user_login() -> Tuple[bool, str]:
    """
    Check if a new DEMO user can login based on MAX_CONCURRENT_USERS.
    We only limit demo slots (users whose username starts with 'demo').
    """
    stats = get_user_statistics()
    if stats["available_slots"] <= 0:
        return False, f"Maximum number of demo users ({MAX_CONCURRENT_USERS}) already connected. Please try again later."
    else:
        return True, f"Welcome! {stats['available_slots']} demo slot(s) available."


def create_user_session(username: str, browser_id: Optional[str] = None, client_id: Optional[str] = None) -> str:
    """
    Create a server-side session row for the user.
    For backward compatibility, we still populate browser_id (with client_id if provided).
    """
    if not os.path.exists(DATABASE_PATH):
        init_database()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT session_id FROM user_sessions 
        WHERE username = ? AND is_active = 1
        """,
        (username,),
    )
    existing = cursor.fetchone()
    if existing:
        conn.close()
        return existing[0]

    session_id = str(uuid.uuid4())
    now = datetime.now().isoformat()
    legacy_browser_id = browser_id or client_id
    cursor.execute(
        """
        INSERT INTO user_sessions (session_id, username, browser_id, client_id, login_time, last_activity, is_active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
        """,
        (session_id, username, legacy_browser_id, client_id, now, now),
    )

    conn.commit()
    conn.close()
    return session_id


def update_session_activity(session_id: str):
    """Update last activity timestamp for a session."""
    if not session_id or not os.path.exists(DATABASE_PATH):
        return
    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    cur.execute(
        "UPDATE user_sessions SET last_activity = ? WHERE session_id = ? AND is_active = 1",
        (datetime.now().isoformat(), session_id),
    )
    conn.commit()
    conn.close()


def end_user_session(session_id: str):
    """Mark a session as inactive."""
    if not session_id or not os.path.exists(DATABASE_PATH):
        return
    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    cur.execute("UPDATE user_sessions SET is_active = 0 WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()


def check_session_validity(session_id: str) -> bool:
    """True if the session exists, is active and not expired."""
    if not session_id or not os.path.exists(DATABASE_PATH):
        return False

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    expiry_time = datetime.now() - timedelta(minutes=SESSION_TIMEOUT_MINUTES)
    cur.execute(
        """
        SELECT COUNT(*) FROM user_sessions 
        WHERE session_id = ? AND is_active = 1 AND last_activity > ?
        """,
        (session_id, expiry_time.isoformat()),
    )
    ok = cur.fetchone()[0] > 0
    conn.close()
    return ok


def get_all_users() -> list:
    """Return all users with their roles."""
    if not os.path.exists(DATABASE_PATH):
        init_database()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    cur.execute("SELECT username, full_name, email, role, created_at FROM users ORDER BY username")
    users = cur.fetchall()
    conn.close()
    return users


# ──────────────────────────────────────────────────────────────
# Streamlit-side session helpers (legacy)
# ──────────────────────────────────────────────────────────────
def is_logged_in() -> bool:
    """Check Streamlit-side session validity and refresh activity."""
    if not st.session_state.get("logged_in", False):
        return False
    session_id = st.session_state.get("session_id")
    if session_id and check_session_validity(session_id):
        update_session_activity(session_id)
        return True
    else:
        logout_user()
        return False


def get_current_user() -> Optional[dict]:
    """Return current user info (Streamlit-side)."""
    if is_logged_in():
        return st.session_state.get("user_info")
    return None


def login_user(user_info: dict):
    """Login helper that honors demo slot limits via can_user_login()."""
    can_login, message = can_user_login()
    if not can_login:
        st.error(message)
        return False

    session_id = create_user_session(user_info["username"])
    st.session_state.logged_in = True
    st.session_state.user_info = user_info
    st.session_state.username = user_info["username"]
    st.session_state.session_id = session_id
    st.session_state.login_time = datetime.now()
    return True


def logout_user():
    """Logout helper for Streamlit-side flows."""
    session_id = st.session_state.get("session_id")
    if session_id:
        end_user_session(session_id)
    st.session_state.logged_in = False
    st.session_state.user_info = None
    st.session_state.username = ""
    st.session_state.session_id = None
    st.session_state.login_time = None


def require_login(redirect_url: str):
    """Guard for pages requiring login (legacy flow)."""
    if not is_logged_in():
        st.error(f"🔒 Please log in to access this page. [Go to Home Page]({redirect_url})")
        st.stop()


def auto_logout_check():
    """Auto-logout if Streamlit-side session expired (legacy flow)."""
    if st.session_state.get("logged_in", False):
        session_id = st.session_state.get("session_id")
        if session_id and not check_session_validity(session_id):
            st.warning("⏱️ Your session has expired due to inactivity. Please log in again.")
            logout_user()
            st.rerun()


def get_user_statistics() -> Dict:
    """Stats separated between demo slots and traditional users."""
    active_sessions = get_active_sessions_info()
    demo_sessions = [s for s in active_sessions if s["username"].startswith("demo")]
    traditional_sessions = [s for s in active_sessions if not s["username"].startswith("demo")]

    demo_count = len(demo_sessions)
    traditional_count = len(traditional_sessions)

    return {
        "active_count": demo_count + traditional_count,
        "demo_count": demo_count,
        "traditional_count": traditional_count,
        "max_users": MAX_CONCURRENT_USERS,                         # total demo slots
        "available_slots": max(0, MAX_CONCURRENT_USERS - demo_count),  # free demo slots
        "timeout_minutes": SESSION_TIMEOUT_MINUTES,
        "active_sessions": active_sessions,
    }


# ──────────────────────────────────────────────────────────────
# Persistent login tokens (per-browser)
# ──────────────────────────────────────────────────────────────
def issue_persistent_login(username: str, client_id: str, days: int = 7) -> str:
    """
    Create a persistent login token bound to (username, client_id).
    Only one active token is kept for a given pair.
    """
    _ensure_persistent_login_columns()
    token = str(uuid.uuid4())
    expires_at = (datetime.now() + timedelta(days=days)).isoformat()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    try:
        # Revoke old tokens for same (username, client_id)
        cur.execute(
            """
            UPDATE user_sessions
            SET persistent_token = NULL, expires_at = NULL
            WHERE username = ? AND client_id = ?
            """,
            (username, client_id),
        )

        # Attach token to an active session if present; otherwise create a thin row
        cur.execute(
            """
            SELECT session_id FROM user_sessions
            WHERE username = ? AND is_active = 1
            ORDER BY login_time DESC LIMIT 1
            """,
            (username,),
        )
        row = cur.fetchone()

        now = datetime.now().isoformat()
        if row:
            session_id = row[0]
            cur.execute(
                """
                UPDATE user_sessions
                SET persistent_token = ?, client_id = ?, expires_at = ?
                WHERE session_id = ?
                """,
                (token, client_id, expires_at, session_id),
            )
        else:
            session_id = str(uuid.uuid4())
            cur.execute(
                """
                INSERT INTO user_sessions (session_id, username, browser_id, client_id, login_time, last_activity, is_active, persistent_token, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
                """,
                (session_id, username, client_id, client_id, now, now, token, expires_at),
            )

        conn.commit()
        return token
    finally:
        conn.close()


def get_user_by_persistent_token(token: str, client_id: str) -> Optional[dict]:
    """Validate a persistent token and return the user info if valid."""
    if not token:
        return None
    _ensure_persistent_login_columns()

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    try:
        cur.execute(
            """
            SELECT us.username, us.expires_at
            FROM user_sessions us
            WHERE us.persistent_token = ? AND us.client_id = ? AND us.is_active = 1
            """,
            (token, client_id),
        )
        row = cur.fetchone()
        if not row:
            return None

        username, expires_at = row
        if expires_at and datetime.fromisoformat(expires_at) < datetime.now():
            revoke_persistent_token(token)
            return None

        # Fetch full user info
        conn2 = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
        cur2 = conn2.cursor()
        cur2.execute("SELECT id, username, full_name, email FROM users WHERE username = ?", (username,))
        u = cur2.fetchone()
        conn2.close()

        if not u:
            return None
        return {"id": u[0], "username": u[1], "full_name": u[2], "email": u[3]}
    finally:
        conn.close()


def revoke_persistent_token(token: str):
    """Invalidate a persistent token."""
    _ensure_persistent_login_columns()
    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cur = conn.cursor()
    try:
        cur.execute(
            "UPDATE user_sessions SET persistent_token = NULL, expires_at = NULL WHERE persistent_token = ?",
            (token,),
        )
        conn.commit()
    finally:
        conn.close()


# ──────────────────────────────────────────────────────────────
# Queue management (legacy 'browser_id' column — we store client_id)
# ──────────────────────────────────────────────────────────────
def _retryable_exec(fn, *args, **kwargs):
    """Run a DB operation with retries on 'database is locked'."""
    last_exc = None
    for _ in range(SQLITE_MAX_RETRIES):
        try:
            return fn(*args, **kwargs)
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e).lower():
                last_exc = e
                time.sleep(SQLITE_RETRY_SLEEP)
                continue
            raise
    if last_exc:
        raise last_exc


def add_to_demo_queue(browser_id: str) -> int:
    """Add (or reactivate) a browser/client in the demo queue and return its position.
    - If the client is already queued (even with a past inactive row), upsert to set is_active=1
      and push it to the tail by refreshing reservation_time.
    - Raises ValueError if queue is full (exceeds MAX_DEMO_QUEUE_SIZE).
    """
    if not os.path.exists(DATABASE_PATH):
        init_database()

    def _op():
        conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
        try:
            cur = conn.cursor()

            # Check if browser is already in queue
            cur.execute("SELECT id FROM demo_queue WHERE browser_id = ? AND is_active = 1", (browser_id,))
            already_in_queue = cur.fetchone() is not None

            # Compute current queue size
            cur.execute("SELECT COUNT(*) FROM demo_queue WHERE is_active = 1")
            current_queue_size = cur.fetchone()[0]
            
            # If not already in queue and queue is full, reject
            if not already_in_queue and current_queue_size >= MAX_DEMO_QUEUE_SIZE:
                raise ValueError(f"Queue is full. Maximum {MAX_DEMO_QUEUE_SIZE} users allowed in queue.")
            
            # Compute the position it will get if inserted now (tail = count + 1)
            new_position = current_queue_size + 1 if not already_in_queue else current_queue_size
            estimated_wait = new_position * 10  # minutes

            # Upsert: (re)activate this browser_id and place it at the TAIL
            # reservation_time refreshed to CURRENT_TIMESTAMP; estimated_wait updated
            cur.execute(
                """
                INSERT INTO demo_queue (browser_id, estimated_wait_minutes, is_active)
                VALUES (?, ?, 1)
                ON CONFLICT(browser_id) DO UPDATE SET
                    is_active = 1,
                    reservation_time = CURRENT_TIMESTAMP,
                    estimated_wait_minutes = excluded.estimated_wait_minutes
                """,
                (browser_id, estimated_wait),
            )
            conn.commit()

            # Return actual current position after upsert (count how many active before me)
            cur.execute(
                """
                SELECT COUNT(*) FROM demo_queue 
                WHERE is_active = 1 AND reservation_time <= (
                    SELECT reservation_time FROM demo_queue WHERE browser_id = ? AND is_active = 1
                )
                """,
                (browser_id,),
            )
            pos = cur.fetchone()[0] or 1
            return pos
        finally:
            conn.close()

    return _retryable_exec(_op)


def get_queue_position(browser_id: str) -> int:
    """Return the current position in the queue for a given browser/client."""
    if not os.path.exists(DATABASE_PATH):
        return 0

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT COUNT(*) FROM demo_queue 
        WHERE reservation_time <= (
            SELECT reservation_time FROM demo_queue 
            WHERE browser_id = ? AND is_active = 1
        ) AND is_active = 1
        """,
        (browser_id,),
    )
    result = cursor.fetchone()
    conn.close()
    return result[0] if result and result[0] else 0


def remove_from_demo_queue(browser_id: str):
    """Deactivate a queue entry for the given browser/client."""
    if not os.path.exists(DATABASE_PATH):
        return

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute("UPDATE demo_queue SET is_active = 0 WHERE browser_id = ?", (browser_id,))
    conn.commit()
    conn.close()


def auto_login_next_in_queue() -> tuple:
    """
    Automatically login the next client in the queue if there are free demo slots.
    Returns (success, slot_name, browser_id) where browser_id is actually client_id now.
    """
    stats = get_user_statistics()
    if stats["available_slots"] <= 0:
        return False, None, None

    next_browser = get_next_in_queue()
    if not next_browser:
        return False, None, None

    active_sessions = stats.get("active_sessions", [])
    used_slots = [s["username"] for s in active_sessions]

    for i in range(1, stats["max_users"] + 1):
        slot_name = f"demo{i}"
        if slot_name not in used_slots:
            session_id = create_user_session(slot_name, browser_id=next_browser, client_id=next_browser)
            remove_from_demo_queue(next_browser)
            return True, slot_name, next_browser

    return False, None, None


def get_next_in_queue() -> Optional[str]:
    """Return the next browser/client id in the queue."""
    if not os.path.exists(DATABASE_PATH):
        return None

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT browser_id FROM demo_queue 
        WHERE is_active = 1 
        ORDER BY reservation_time ASC 
        LIMIT 1
        """
    )
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None


def is_in_demo_queue(browser_id: str) -> bool:
    """True if the given browser/client is currently in the queue."""
    if not os.path.exists(DATABASE_PATH):
        return False

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM demo_queue WHERE browser_id = ? AND is_active = 1", (browser_id,))
    result = cursor.fetchone()
    conn.close()
    return bool(result)


def get_queue_stats() -> dict:
    """Return queue stats including current size, max size, and availability."""
    if not os.path.exists(DATABASE_PATH):
        return {
            "total_in_queue": 0, 
            "estimated_wait": 0,
            "max_queue_size": MAX_DEMO_QUEUE_SIZE,
            "is_queue_full": False,
            "available_queue_spots": MAX_DEMO_QUEUE_SIZE
        }

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM demo_queue WHERE is_active = 1")
    total_in_queue = cursor.fetchone()[0]
    estimated_wait = total_in_queue * 10
    conn.close()
    
    is_queue_full = total_in_queue >= MAX_DEMO_QUEUE_SIZE
    available_queue_spots = max(0, MAX_DEMO_QUEUE_SIZE - total_in_queue)
    
    return {
        "total_in_queue": total_in_queue, 
        "estimated_wait": estimated_wait,
        "max_queue_size": MAX_DEMO_QUEUE_SIZE,
        "is_queue_full": is_queue_full,
        "available_queue_spots": available_queue_spots
    }


def clear_all_sessions():
    """Manual admin: deactivate all sessions and clear the queue."""
    if not os.path.exists(DATABASE_PATH):
        return

    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute("UPDATE user_sessions SET is_active = 0")
    cursor.execute("UPDATE demo_queue SET is_active = 0")
    conn.commit()
    conn.close()
    print("✅ All sessions and queue cleared manually")


# ──────────────────────────────────────────────────────────────
# Role management functions
# ──────────────────────────────────────────────────────────────
def get_user_role_from_db(username: str) -> Optional[str]:
    """Get the role of a specific user from database."""
    if not os.path.exists(DATABASE_PATH):
        return None
    
    conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
    cursor = conn.cursor()
    cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    
    return row[0] if row else None


def update_user_role(username: str, new_role: str) -> bool:
    """
    Update the role of a user.
    
    Args:
        username: The username to update
        new_role: The new role (admin, scientist, researcher, analyst, guest, demo)
        
    Returns:
        True if successful, False otherwise
    """
    if not os.path.exists(DATABASE_PATH):
        return False
    
    valid_roles = ["admin", "scientist", "researcher", "analyst", "guest", "demo"]
    if new_role not in valid_roles:
        return False
    
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET role = ? WHERE username = ?", (new_role, username))
        conn.commit()
        success = cursor.rowcount > 0
        conn.close()
        return success
    except Exception:
        return False


def create_user(username: str, password: str, full_name: str, email: str, role: str = "guest") -> bool:
    """
    Create a new user with specified role.
    
    Args:
        username: Unique username
        password: Plain text password (will be hashed)
        full_name: User's full name
        email: User's email
        role: User role (default: guest)
        
    Returns:
        True if successful, False if username exists or error
    """
    if not os.path.exists(DATABASE_PATH):
        init_database()
    
    valid_roles = ["admin", "scientist", "researcher", "analyst", "guest", "demo"]
    if role not in valid_roles:
        role = "guest"
    
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=SQLITE_TIMEOUT)
        cursor = conn.cursor()
        
        # Check if username exists
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        if cursor.fetchone()[0] > 0:
            conn.close()
            return False
        
        # Create user
        password_hash = hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password_hash, full_name, email, role) VALUES (?, ?, ?, ?, ?)",
            (username, password_hash, full_name, email, role)
        )
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False
