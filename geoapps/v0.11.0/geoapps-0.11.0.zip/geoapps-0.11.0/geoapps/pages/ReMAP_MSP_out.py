#0_📈_ReMAP_MSP_out_v2.py


import pickle
import pathlib
from matplotlib import pyplot as plt
from matplotlib.backends.backend_agg import RendererAgg
from time import sleep

import streamlit as st
import geopandas as gpd
import pydeck as pdk
import streamlit as st
import pandas as pd
import copy

import streamlit as st
from streamlit.components.v1 import html
from branca.element import Element
from tools.utils import make_login, make_header, publish_result, check_pageload
import plotly.express as px
import plotly.graph_objects as go

from tools.importer import *
from database.dbconn import QueryManager, ZoningAreas, Plans, add_where, engine, CoverageUF, AreasOfInterest
from sqlalchemy import select, func, distinct
from geoalchemy2 import Geometry, functions as geofunc

from core.analysis_msp_out import analysis_zoning_elements, analysis_sea_uses, analysis_sea_use_function, analysis_upset, analysis_diagnosis
from core.map_utils import set_map_state, make_map


from auth.access_guard import require_app_login
require_app_login()  #

qm = QueryManager(engine)
qmconf = QueryManager(engine)

st.set_page_config(
    page_title="Tools4MSP GeoApps: ReMAP MSP-out",
    page_icon="🗺️",
    layout="wide",
)

explanations = {

"coverage":
"""The graph and table show the percentage of ZEs coverage, calculated relative to the total area of the Spatial Plan.""",
    
"Zoning Elements":
"""According to EMODnet, Zoning Elements (ZEs) are spatial objects,
part of a spatial plan, defining activities and uses in a specific
area. This analysis offers insights on the number of ZEs, and the
relative Disjoint Index""",
"n_ze":
"""The graph and table display the number of Zoning Elements for each
country or spatial plan, as present in EMODnet.""",
"disjoint":
"""The graph and table display the Disjoint Index for each country or
spatial plan. The Disjoint Index ranges from 0 to 1, where 0 indicates
perfect overlapping between Zoning Elements, while 1 indicated absence
of overlapping.""",

"Sea use":
"""This analysis offers a visual idea of which activities are present
or absent in a plan, and their relative spatial coverage.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.  """,

"Sea use & Function":
"""This analysis offers an overview of the Sea uses present in a plan,
and their relative Functions.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.

Another Zoning Elements’ attribute can be the Function, describing the
regulatory framework of a given activity in the area. The model
provides six possible Functions:

* Reserved: areas specifically designated for the development of certain activities 
* Priority: activities with precedence over any other 
* Allowed: activities with permission to be developed 
* Potential: activities that could be developed according to the characteristics of the area 
* Restricted: specific activities that can not be carried out in a given area 
* Forbidden: activities that cannot be developed according to the plan 

The Function Undefined was added by the module developers to cover
those Zoning Elements that were missing the Function attribute.  """,

"Multi-source overlay":
"""This analysis adds European-wide geospatial layers, such as
bathymetry and vessel density, to offer a comprehensive understanding
of the maritime context.  """
                }

make_header()

# analyisis


@st.fragment
def make_settings():
    _session_state = {}
    filter_array = []
    filter_array_geoplatform = []

    conf_ze = qmconf.run('ze_distinct')
    conf_aois = qmconf.run('aois', mode='list')
    conf_plans = qmconf.run('plans')
    
    st.image('https://www.shom.fr/sites/default/files/inline-images/logo_ReMAP_0.png', width=200)

    st.write("###  Settings")
    uc_filter_options = [
        None,
        'Baltic sea use case',
        'North-Western Mediterranean sea use case',
        'Galicia use case',
    ]

    def update_defaults():
        profile_choice = st.session_state.conf_uc_selected_filter
        if profile_choice is None:
            st.session_state.conf_ms_selected_filter = []
            st.session_state.conf_aoi_selected_filter = None
        elif profile_choice == 'Baltic sea use case':
            st.session_state.conf_ms_selected_filter = ['Denmark', 'Estonia', 'Finland', 'Germany', 'Latvia', 'Lithuania', 'Poland', 'Sweden']
            st.session_state.conf_aoi_selected_filter = 'Baltic sea'
        elif profile_choice == 'North-Western Mediterranean sea use case':
            st.session_state.conf_ms_selected_filter = ['Spain', 'France', 'Italy']
            st.session_state.conf_aoi_selected_filter = 'North-Western Mediterranean Sea PSSA'
        elif profile_choice == 'Galicia use case':
            st.session_state.conf_ms_selected_filter = ['Spain']
            st.session_state.conf_aoi_selected_filter = 'Galicia'

                    
    uc_selected_filter = st.selectbox("Profiles",
                                      key="conf_uc_selected_filter",
                                      options=uc_filter_options,
                                      on_change=update_defaults
                                      )

    st.write("####  Area of Analysis")
    ms_filter_options = conf_ze.MS.unique()
    ms_selected_filter = st.multiselect("Member states", options=sorted(ms_filter_options), key="conf_ms_selected_filter")
    _session_state['ms_selected_filter'] = ms_selected_filter
    
    if len(ms_selected_filter) > 0:
        filter_array.append(" or ".join([f"ms LIKE '{ms}'" for ms in ms_selected_filter]))
        # replace value for France
        ms_selected_filter_fr = ['France-MED' if x == 'France' else x for x in ms_selected_filter]
        filter_array_geoplatform.append(" or ".join([f"MS LIKE '{ms}'" for ms in ms_selected_filter_fr]))

    if len(ms_selected_filter) > 0:
        spid_filter_options = conf_ze[conf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    else:
        spid_filter_options = conf_ze.SPID.unique()
    spid_selected_filter = st.multiselect("Spatial Plan (SPID)", options=sorted(spid_filter_options), key="conf_spid_selected_filter")
    _session_state['spid_selected_filter'] = spid_selected_filter
    # if filter is None select the SPID from selected member states (if any)
    ms_spid_selected_filter = spid_selected_filter
    if len(spid_selected_filter) == 0 and len(ms_selected_filter) > 0:
        ms_spid_selected_filter = conf_ze[conf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    _session_state['ms_spid_selected_filter'] = ms_spid_selected_filter

    # Spatial plans
    selected_plans = conf_plans[['MS', 'SPID', 'OffTitle']].copy()
    if len(spid_selected_filter) > 0:
        selected_plans = selected_plans[selected_plans.SPID.isin(spid_selected_filter)]
    selected_plans.SPID = selected_plans.SPID.replace(map_spid)
    _session_state['selected_plans'] = selected_plans.copy()

    # Area of interest
    aoi_filter_options = conf_aois
    aoi_selected_filter = st.selectbox("Areas of Interest / Transboundary areas",
                                       options=aoi_filter_options,
                                       index=None,
                                       key="conf_aoi_selected_filter")
    _session_state['aoi_selected_filter'] = aoi_selected_filter

    # Spatial scale
    sc_filter_options = ['Member State', 'Spatial Plan']
    sc_selected_filter = st.selectbox("Spatial scale", options=sc_filter_options, key="conf_sc_selected_filter")
    _session_state['sc_selected_filter'] = sc_selected_filter

    if sc_selected_filter == 'Spatial Plan' and len(spid_selected_filter) > 0:
        spid_orig = [k for k, v in map_spid.items() if v in spid_selected_filter]
        filter_array.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig]))

        # replace value for France
        spid_orig_fr = ['FRA-MED' if x == 'DSF_MED' else x for x in spid_orig]

        filter_array_geoplatform.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig_fr]))

    st.divider()
    st.write("####  Kind of Analysis")
    analysis_filter_options = ['Zoning Elements',
                               'Sea use',
                               'Sea use & Function',
                               'Coexistence',
                               # 'Multi-source overlay',
                               'Diagnosis',
                               ]
    analysis_selected_filter = st.selectbox("Analysis", options=analysis_filter_options, key="conf_analysis_selected_filter")
    _session_state['analysis_selected_filter'] = analysis_selected_filter

    
    st.divider()
    st.write("#### Focus")

    # Sea use
    _gdf = conf_ze
    if len(ms_selected_filter) > 0:
        _gdf = _gdf[_gdf.MS.isin(ms_selected_filter)]
    if len(spid_selected_filter) > 0:
        _gdf = _gdf[_gdf.SPID.isin(spid_selected_filter)]

    seause_filter_options = _gdf['Sea use'].unique()
    seause_selected_filter = st.multiselect("Sea use", options=seause_filter_options, key="conf_seause_selected_filter")
    _session_state['seause_selected_filter'] = seause_selected_filter

    if len(seause_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausename = '{_seause}'" for _seause in seause_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseName = '{_seause}'" for _seause in seause_selected_filter]))
        _gdf = _gdf[_gdf['Sea use'].isin(seause_selected_filter)]

    # Function
    function_filter_options = _gdf['Function'].unique()
    function_selected_filter = st.multiselect("Sea use function", options=function_filter_options, key="conf_function_selected_filter")
    _session_state['function_selected_filter'] = function_selected_filter

    if len(function_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausefct = '{_function}'" for _function in function_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseFct = '{_function}'" for _function in function_selected_filter]))

    # add parenthesis
    filter_array = [f"({_f})" for _f in filter_array]
    filter_query = " and ".join(filter_array)

    filter_array_geoplatform = [f"({_f})" for _f in filter_array_geoplatform]
    filter_query_geoplatform = " and ".join(filter_array_geoplatform)

    
    _session_state['filter_query'] = filter_query
    _session_state['filter_query_geoplatform'] = filter_query_geoplatform

    # set default (only for the first run)
    if check_pageload('msp_out'):
        for k, v in _session_state.items():
            st.session_state[k] = v

    if st.button("Process"):
        for k, v in _session_state.items():
            st.session_state[k] = v
        first_analysis = False
        st.rerun()


def get_filter_column():
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        column = 'SPID'
    elif st.session_state.sc_selected_filter == 'Member State':
        column = 'MS'
    return column
    
def apply_filters():
    qm._filters = {}
    _selected_filter = None
    column = get_filter_column()
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        _selected_filter = st.session_state.ms_spid_selected_filter
    elif st.session_state.sc_selected_filter == 'Member State':
        _selected_filter = st.session_state.ms_selected_filter

    # apply filters  
    if len(_selected_filter) > 0:
        qm.set_filter(column, _selected_filter)
    if len(st.session_state.seause_selected_filter) > 0:
        qm.set_filter('Sea_use', st.session_state.seause_selected_filter)
    if len(st.session_state.function_selected_filter) > 0:
        qm.set_filter('Function', st.session_state.function_selected_filter)
    # apply geofilter
    
    # if len(st.session_state.aoi_selected_filter) > 0:
    #     # print("Spatial filter")
    #     # filter_geo = aois[aois.label.isin(st.session_state.aoi_selected_filter)].unary_union
    #     # _df = _df[_df.intersects(filter_geo)]
    #     subq = (
    #         select(geofunc.ST_Union(AreasOfInterest.geometry).label("geometry"))
    #         .where(AreasOfInterest.label.in_(st.session_state.aoi_selected_filter))
    #         .subquery()
    #     )
    #     qm.set_filter('ST_intersects', subq.c.geometry)
    if st.session_state.aoi_selected_filter:
        # print("Spatial filter")
        # filter_geo = aois[aois.label.isin(st.session_state.aoi_selected_filter)].unary_union
        # _df = _df[_df.intersects(filter_geo)]
        subq = (
            select(AreasOfInterest.geometry)
            .where(AreasOfInterest.label == st.session_state.aoi_selected_filter)
            .subquery()
        )
        qm.set_filter('ST_intersects', subq.c.geometry)


@st.fragment
def make_analysis():
    analysis_header = st.empty()
    analysis_container = st.empty()

    with analysis_header.container():
        st.write(f"## {st.session_state.analysis_selected_filter} Analysis")
        explanation = explanations.get(st.session_state.analysis_selected_filter)
        if explanation is not None:
            with st.popover("ℹ️ "):
                st.write(explanation)

    column = get_filter_column()
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)
    apply_filters()

    if st.session_state.analysis_selected_filter == 'Sea use':
        with analysis_container.container():
            analysis_sea_uses(qm, column, explanations)

    elif st.session_state.analysis_selected_filter == 'Zoning Elements':
        with analysis_container.container():
            analysis_zoning_elements(qm, column, explanations)

    elif st.session_state.analysis_selected_filter == 'Sea use & Function':
        with analysis_container.container():
            analysis_sea_use_function(qm, column, explanations)

    elif st.session_state.analysis_selected_filter == 'Coexistence':
        with analysis_container.container():
            analysis_upset(qm, column, explanations)

    elif st.session_state.analysis_selected_filter == 'Diagnosis':
        with analysis_container.container():
            analysis_diagnosis(qm, column, explanations)


with st.sidebar:
    make_settings()

with st.spinner("Wait for it...", show_time=True):
    set_map_state()
    make_map(qm)
    make_analysis()


