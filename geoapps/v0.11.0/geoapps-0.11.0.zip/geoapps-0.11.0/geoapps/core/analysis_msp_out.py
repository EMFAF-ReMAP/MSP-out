import streamlit as st
from matplotlib import pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from sqlalchemy import select, func, distinct
from geoalchemy2 import Geometry, functions as geofunc
import plotly.io as pio
pio.templates.default = "seaborn" # "plotly"

from upsetplot import from_memberships, plot as upplot, UpSet
from threading import RLock
_lock = RLock()

from database.dbconn import QueryManager, ZoningAreas, Plans, add_where, engine, CoverageUF, AreasOfInterest
from tools.utils import set_sankey_data, publish_result

def plot_diagnosis_sankey(qm, stmt, column, zoning_areas_column):
    sankey_sc_filter_options = qm.run("plans")[column].unique()
    st.selectbox(
        st.session_state.sc_selected_filter,
        options=sankey_sc_filter_options,
        key="sankey_sc_selected_filter",
    )

    stmt = stmt.where(zoning_areas_column==st.session_state.sankey_sc_selected_filter)

    __df = qm.read(stmt, 'df').fillna(0)
    print(__df)
    sankey_columns = ['OriginUNEn', 'Sea use', 'Function']
    
    # __df = _gdf_ze[_gdf_ze[column]==st.session_state.sankey_sc_selected_filter].copy()
    # print(__df)
    labels, sources, targets, values, link_colors, sourceinfo = set_sankey_data(__df, sankey_columns, 'geoarea')

    # Creazione del grafico Sankey
    fig = go.Figure(go.Sankey(
        node=dict(
            # pad=15,
            # thickness=20,
            # line=dict(color='black', width=0.5),
            label=labels,
            color="grey",
        ),
        link=dict(
            source=sources,
            target=targets,
            value=values,
            color=link_colors,
            customdata = sourceinfo,
            hovertemplate='OriginUNEn %{customdata}<br />'+
            'source: %{source.label}<br />'+
            'target: %{target.label}<br />' +
            'area: %{value}<br />',
        ),
        textfont=dict(
            color='black',
            shadow = "rgba(0, 0, 0, 0)",
        )
    ))

    for x_coordinate, column_name in enumerate(["OriginUNEn", "Sea use", "Function"]):
        fig.add_annotation(
            x=x_coordinate,#Plotly recognizes 0-5 to be the x range.
            
            y=1.075,#y value above 1 means above all nodes
            xref="x",
            yref="paper",
            text=column_name,#Text
            showarrow=False,
            align="left",
        )
    fig.update_traces(node_hoverlabel=dict(bgcolor="white"))
    # Mostrare il grafico
    # fig.update_layout(title_text='Diagramma di Sankey', font_size=10)
        
    st.plotly_chart(fig, use_container_width=True)
    if st.button("Publish analysis", key="publish_diagnosis_sankey"):
        publish_result(fig, prefix="publish_diagnosis_sankey")

        
    st.dataframe(__df[sankey_columns])

def plot_treemap(df):          
    st.write(f"### Hierarchical exploration")
    df['Hilucs MSP'] = df.HilucsMSP.str.split('_').str[-1].str.replace('.html','')

    treemap_explore_by_options = [
        'Member states', 'Sea uses', 'Hilucs MSP'
        ]
    treemap_explore_by_selected = st.selectbox(
        "Explore by",
        options=treemap_explore_by_options,
        key="treemap_explore_by_selected",
    )
    tree_title = treemap_explore_by_selected
    if treemap_explore_by_selected == 'Member states':
        tree_columns = ['MS', 'Sea use', 'Function', 'OriginUNEn']
    elif treemap_explore_by_selected == 'Sea uses':
        tree_columns = ['Sea use', 'MS', 'OriginUNEn', 'Function']
    elif treemap_explore_by_selected == 'Hilucs MSP':
        tree_columns = ['Hilucs MSP', 'MS', 'OriginUNEn', 'Function']
    # treemap color
    treemap_color_options = tree_columns
    treemap_color_selected = st.selectbox(
        "Color mode",
        options=treemap_color_options,
        key="treemap_color_selected",
    )

    st.write(f"**Hierarchy**: {' -> '.join(tree_columns)}")
    fig = px.treemap(df, path=[px.Constant(tree_title)] + tree_columns,
                     values='geoarea',
                     # color='lifeExp', hover_data=['iso_alpha'],
                     # color_continuous_scale='RdBu',
                     # color_continuous_midpoint=np.average(df['lifeExp'], weights=df['pop'])
                     # color_discrete_map=GES if treemap_color_selected == assessment_col else None,
                     color=st.session_state.treemap_color_selected,
                     )
    fig.update_layout(margin = dict(t=50, l=25, r=25, b=25))
    fig.update_traces(marker=dict(cornerradius=5))
    st.plotly_chart(fig, use_container_width=True)
    if st.button("Publish analysis", key="publish_mspout_treemap"):
        publish_result(fig, prefix="mspout_treemap")


def analysis_diagnosis(qm, column, explanations):
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)
    stmt = select(zoning_areas_column,
                  ZoningAreas.OriginUNEn,
                  ZoningAreas.Sea_use,
                  ZoningAreas.Function,
                  ZoningAreas.geoarea,
                  ZoningAreas.HilucsMSP
                  )
    stmt = add_where(stmt, ZoningAreas, qm._filters)
    plot_diagnosis_sankey(qm, stmt, column, zoning_areas_column)
    st.divider()
    plot_treemap(qm.read(stmt, 'df').fillna(0))

def analysis_upset(qm, column, explanations):
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)

    # upset_sc_filter_options = _gdf_ze[column].unique()
    upset_sc_filter_options = qm.run("plans")[column].unique()            
    st.selectbox(
        st.session_state.sc_selected_filter,
        options=upset_sc_filter_options,
        key="upset_sc_selected_filter",
    )

    coverage_uf_column = getattr(CoverageUF, column)
    plans_column = getattr(Plans, column)
    stmt_coverage_s = select(CoverageUF.index, coverage_uf_column, CoverageUF.Sea_use, CoverageUF.geoarea).distinct(CoverageUF.index, CoverageUF.Sea_use)
    stmt_coverage_s = stmt_coverage_s.where(coverage_uf_column ==st.session_state.upset_sc_selected_filter)
    stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()
    # subq_column = getattr(stmt_coverage_s.c, column)
    # stmt_coverage = select(subq_column, stmt_coverage_s.c.Sea_use, func.sum(stmt_coverage_s.c.geoarea).label("geoarea")).group_by(subq_column, stmt_coverage_s.c.Sea_use).subquery()
    stmt_coverage = stmt_coverage_s

    stmt_plans = select(plans_column,
                        func.sum(Plans.geoarea).label("geoarea_plan"),
                        func.sum(Plans.geoarea_coverage).label("geoarea_coverage"),
                        func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
                        ).group_by(plans_column)
    stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

    # subquery columns
    stmt_coverage_col = getattr(stmt_coverage.c, column)
    stmt_plans_col = getattr(stmt_plans.c, column)

    stmt = (
        select(
            stmt_coverage.c.index.label("coverageid"),
            stmt_coverage_col,
            stmt_coverage.c.Sea_use,
            stmt_coverage.c.geoarea,
            stmt_plans.c.geoarea_coverage,
            stmt_plans.c.geoarea_noboundaries,
            stmt_plans.c.geoarea_plan,
        )
        .select_from(stmt_coverage)
        .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
    )
    __df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)
    geoarea_column = f'geoarea_perc_{column.lower()}'
    __df[geoarea_column] = __df.geoarea / __df[f'geoarea_coverage'] * 100
    _df_entity = __df.groupby('coverageid').agg({'Sea use': list, geoarea_column: sum})

    upset_data = from_memberships(_df_entity['Sea use'],
                                          data=_df_entity[[geoarea_column]])  # , 'location']])
    if upset_data.index.nlevels <= 1:
        st.warning(
            "The number of selected or available uses is not sufficient to perform a coexistence analysis. "
            "At least two uses are required."
        )
        return
            
    upset = UpSet(upset_data,
                  sum_over = geoarea_column,
                  # intersection_plot_elements=0,
                  totals_plot_elements=12,
                  #  show_counts='%d%%',
                  # show_percentages=True,
                  min_subset_size=0.5,
                  )  # disable the default bar chart
    with _lock:
        fig, ax = plt.subplots()
        plots = upset.plot(fig=fig)
        # rimuovo i ticks dell'asse creato all'inizio
        ax.tick_params(
            top=False, bottom=False, left=False, right=False,
            labelbottom=False, labelleft=False
        )
        for spine in ax.spines.values():
            spine.set_visible(False)
        plots['totals'].set_title("surface occupied (%)")
        st.pyplot(fig, width="content")
        if st.button("Publish analysis", key="publish_upset"):
            publish_result(fig, prefix="mspout_upset")



def analysis_sea_use_function(qm, column, explanations):
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)

    col1, col2 = st.columns([5, 5], border=True)

    stmt_coverage_s = select(CoverageUF.index, coverage_uf_column, CoverageUF.Sea_use, CoverageUF.Function, CoverageUF.geoarea).distinct(CoverageUF.index, CoverageUF.Sea_use, CoverageUF.Function)
    stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()
    subq_column = getattr(stmt_coverage_s.c, column)
    stmt_coverage = select(subq_column,
                           stmt_coverage_s.c.Sea_use,
                           stmt_coverage_s.c.Function,
                           func.sum(stmt_coverage_s.c.geoarea).label("geoarea")).group_by(subq_column, stmt_coverage_s.c.Sea_use, stmt_coverage_s.c.Function).subquery()

    stmt_plans = select(plans_column,
                        func.sum(Plans.geoarea).label("geoarea_plan"),
                        func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
                        ).group_by(plans_column)
    stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

    # subquery columns
    stmt_coverage_col = getattr(stmt_coverage.c, column)
    stmt_plans_col = getattr(stmt_plans.c, column)

    stmt = (
        select(
            stmt_coverage_col,
            stmt_coverage.c.Sea_use,
            stmt_coverage.c.Function,
            stmt_coverage.c.geoarea,
            stmt_plans.c.geoarea_noboundaries,
            stmt_plans.c.geoarea_plan,
        )
        .select_from(stmt_coverage)
        .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
    )

    _df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)
        
    _df.Function = _df.Function.replace(' ', 'Undefined')

    _df['coverage %'] = _df.geoarea / _df.geoarea_noboundaries * 100

    SORTED_FUNCTIONS = ['Reserved', 'Priority', 'Allowed', 'Potential', 'Restricted', 'Forbidden', 'Undefined']
    SORTED_SEAUSES = qm.run('ze_distinct')['Sea use'].sort_values().unique()
        
    fig = px.bar(
        _df.sort_values('MS'),
        x="coverage %",
        y="Sea use",
        color="Function",
        orientation="h",
        facet_col=column,
        facet_col_wrap=3,  # come col_wrap
        category_orders={
            "Sea use": SORTED_SEAUSES,      # lista con l'ordine voluto
            "Function": SORTED_FUNCTIONS,   # idem per Function
        }
    )
    
    fig.update_layout(barmode="stack")

    for axis in fig.layout:
        if axis.startswith('yaxis'):
            fig.layout[axis].tickfont = dict(size=7)
            fig.layout[axis].tickmode = 'array'

    # (facoltativo) anche sugli assi X
    for axis in fig.layout:
        if axis.startswith('xaxis'):
            fig.layout[axis].tickfont = dict(size=7)
            fig.layout[axis].tickvals = list(_df["Sea use"].sort_values().unique())

    # Riduci anche font generale
    fig.update_layout(font=dict(size=10), title_font=dict(size=12))

                                            
    
    # fig.update_layout(
    #         font=dict(size=10),
    #         xaxis=dict(tickangle=45, tickfont=dict(size=8)),
    #         yaxis=dict(tickfont=dict(size=8)),
    #         title_font=dict(size=12)
    #     )
    fig.update_traces(textfont_size=8)
    
    with col1:
        st.plotly_chart(fig, theme="streamlit", use_container_width=True)
        if st.button("Publish analysis", key="publish_sea_use_function"):
            publish_result(fig, prefix="sea_use_function")


    with col2:
        st.dataframe(_df)

def analysis_sea_uses(qm, column, explanations):
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)

    col1, col2 = st.columns([5, 5], border=True)

    stmt_coverage_s = select(CoverageUF.index, coverage_uf_column, CoverageUF.Sea_use, CoverageUF.geoarea).distinct(CoverageUF.index, CoverageUF.Sea_use)
    stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()
    subq_column = getattr(stmt_coverage_s.c, column)
    stmt_coverage = select(subq_column, stmt_coverage_s.c.Sea_use, func.sum(stmt_coverage_s.c.geoarea).label("geoarea")).group_by(subq_column, stmt_coverage_s.c.Sea_use).subquery()

    stmt_plans = select(plans_column,
                        func.sum(Plans.geoarea).label("geoarea_plan"),
                        func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
                        ).group_by(plans_column)
    stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

    # subquery columns
    stmt_coverage_col = getattr(stmt_coverage.c, column)
    stmt_plans_col = getattr(stmt_plans.c, column)

    stmt = (
        select(
            stmt_coverage_col,
            stmt_coverage.c.Sea_use,
            stmt_coverage.c.geoarea,
            stmt_plans.c.geoarea_noboundaries,
            stmt_plans.c.geoarea_plan,
        )
        .select_from(stmt_coverage)
        .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
    )

    _df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)
        
    _df['coverage %'] = _df.geoarea / _df.geoarea_noboundaries * 100
    _df['coverage_plan %'] = _df.geoarea / _df.geoarea_plan * 100

    #aggregate on Function
    u_df = _df
    u_df = u_df.pivot(columns='Sea use', index=column, values='coverage %')  # .fillna(0)
    u_df = u_df.dropna(how='all').round(0)

    # Display the plot in Streamlit
    with col1:
        fig = px.imshow(u_df, text_auto=True, aspect="auto", color_continuous_scale="aggrnyl_r",
                        title="Percentage of sea use surfaces relative to Zoning Elements coverage")
        fig = fig.update_traces(xgap=2, ygap=2)
        st.plotly_chart(fig, theme="streamlit", use_container_width=True)
        if st.button("Publish analysis", key="publish_sea_use"):
            publish_result(fig, prefix="sea_use")

        st.dataframe(u_df.T)

    #aggregate on Function
    u_df = _df.groupby([column, 'Sea use'])['coverage_plan %'].sum().to_frame().reset_index()

    u_df = u_df.pivot(columns='Sea use', index=column, values='coverage_plan %')  # .fillna(0)
    u_df = u_df.dropna(how='all').round(0)

    # Display the plot in Streamlit
    with col2:
        fig = px.imshow(u_df, text_auto=True, aspect="auto", color_continuous_scale="aggrnyl_r",
                        title="Percentage of sea use surfaces relative to Spatial Plan coverage")
        fig = fig.update_traces(xgap=2, ygap=2)
        st.plotly_chart(fig, theme="streamlit", use_container_width=True)
        if st.button("Publish analysis", key="publish_sea_use_coverage"):
            publish_result(fig, prefix="sea_use_coverage")

        st.dataframe(u_df.T)


def analysis_zoning_elements(qm, column, explanations):
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)

    col1, col2, col3 = st.columns([5, 5, 5], border=True)

    # __df = _gdf_ze.groupby(column).size().to_frame("Number_ZE")
    stmt = select(zoning_areas_column, func.count().label("Number_ZE")).group_by(zoning_areas_column)
    stmt = add_where(stmt, ZoningAreas, qm._filters)

    __df = qm.read(stmt, 'df', index_col=column)

    with col1:
        st.write("**Number of Zoning Elements**")
        with st.expander("ℹ️  See explanation"):
            st.write(explanations.get("n_ze"))
        # st.bar_chart(__df)
        fig = px.bar(__df.reset_index(), x="MS", y=__df.columns[0])
        st.plotly_chart(fig, use_container_width=True)
        if st.button("Publish analysis", key="publish_ze"):
            publish_result(fig, prefix="ze")
        st.dataframe(__df)

    ##############
    stmt_zoning_areas = select(zoning_areas_column, func.sum(ZoningAreas.geoarea).label("geoarea")).group_by(zoning_areas_column)
    stmt_zoning_areas = add_where(stmt_zoning_areas, ZoningAreas, qm._filters).subquery()
    stmt_plans = select(plans_column, func.sum(Plans.geoarea).label("geoarea_plan")).group_by(plans_column)
    stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

    stmt_coverage_s = select(CoverageUF.index, coverage_uf_column, CoverageUF.geoarea).distinct(CoverageUF.index)
    stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()
    subq_column = getattr(stmt_coverage_s.c, column)
    stmt_coverage = select(subq_column, func.sum(stmt_coverage_s.c.geoarea).label("geoarea_coverage")).group_by(subq_column).subquery()
        
    stmt_zoning_areas_col = getattr(stmt_zoning_areas.c, column)
    stmt_plans_col = getattr(stmt_plans.c, column)
    stmt_coverage_col = getattr(stmt_coverage.c, column)

    stmt = (
        select(
            stmt_zoning_areas_col,
            stmt_zoning_areas.c.geoarea,
            stmt_plans.c.geoarea_plan,
            stmt_coverage.c.geoarea_coverage
        )
        .select_from(stmt_zoning_areas)
        .join(stmt_plans, stmt_zoning_areas_col == stmt_plans_col)
        .join(stmt_coverage, stmt_zoning_areas_col == stmt_coverage_col)
    )

    __df = qm.read(stmt, 'df', index_col=column)
        
    # __df = (_gdf_ze.groupby([column]).sum('geoarea')
    #        .join(_coverage.groupby(column).sum('geoarea'), rsuffix='_coverage')
    #        .join(plans.groupby(column).sum('geoarea')[['geoarea']], rsuffix='_plan')
    #     )

    # print(__df)
        
    field = 'Disjoint_index'
    # rimuovere il moltiplicatore quando ci saranno i dati giusti
    # print(_gdf_ze.groupby([column]).sum('geoarea'))
    # print("######################")
    # print(_coverage.groupby(column).sum('geoarea'))
    # print(__df.columns)

    

    ___df = (__df.geoarea_coverage / __df.geoarea).to_frame(field)

    ___df['ZE Coverage (%)'] = ((__df.geoarea_coverage / __df.geoarea_plan) * 100).round(1)

    ___df = ___df.sort_index()

    with col2:
        st.write("**Disjoint Index**")
        with st.expander("ℹ️  See explanation"):
            st.write(explanations.get("disjoint"))
        # st.bar_chart(___df[field])
        fig = px.bar(___df, y=field)
        st.plotly_chart(fig, use_container_width=True)
        if st.button("Publish analysis", key="publish_ze_disjoint"):
            publish_result(fig, prefix="ze_disjoint")
        st.dataframe(___df[[field]])

    field = 'ZE Coverage (%)'
    with col3:
        st.write("**ZE Coverage (%)**")
        with st.expander("ℹ️  See explanation"):
            st.write(explanations.get("coverage"))
        # st.bar_chart(___df[field])
        fig = px.bar(___df, y=field)
        st.plotly_chart(fig, use_container_width=True)
        if st.button("Publish analysis", key="publish_ze_coverage"):
            publish_result(fig, prefix="ze_coverage")
        st.dataframe(___df[[field]])

    # aggiungere % zoning element coverage
    # u_df = _df.groupby([column, 'Sea use'])['coverage_plan %'].sum().to_frame().reset_index()
