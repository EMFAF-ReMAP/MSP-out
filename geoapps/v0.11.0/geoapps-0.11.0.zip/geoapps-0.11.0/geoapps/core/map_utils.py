from folium import Map, TileLayer, GeoJson, FeatureGroup
from streamlit_folium import st_folium
from branca.colormap import linear
from shapely.geometry import shape
import folium
import geopandas as gpd
import pickle
import streamlit as st
from streamlit_folium import st_folium
from branca.colormap import linear
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt

def draw_domain_map(da_counts_filtered, DA_BY_LABEL):
    """Draw map with filtered domain areas only.

    Args:
        da_counts_filtered (dict[str, int]): domain_area → dataset count
        DA_BY_LABEL (dict[str, pandas.Series]): lookup label → record with geo_simplified
    """

    # ───────────────────── Base map ──────────────────────
    fmap = Map(location=[43, 12], zoom_start=4)
    TileLayer("CartoDB positron", control=False).add_to(fmap)

    # ───────────────────── Robust color scale ────────────
    counts = list(da_counts_filtered.values())
    max_val = max(counts)
    min_val = min(counts)
    if min_val == max_val:               # avoid flat scale
        min_val = 0

    colormap = linear.OrRd_09.scale(min_val, max_val)
    colormap.caption = "Dataset count"
    
    # Configure legend to show only integer numbers
    if max_val > min_val:
        # Create list of integer ticks
        num_ticks = min(6, max_val - min_val + 1)  # Maximum 6 ticks or available range
        tick_values = [int(x) for x in np.linspace(min_val, max_val, num_ticks)]
        # Remove duplicates maintaining order
        tick_values = list(dict.fromkeys(tick_values))
        colormap.tick_labels = [str(x) for x in tick_values]

    # ───── Prepare list (area, label, count, color, geom) ─
    area_list = []
    for da, cnt in da_counts_filtered.items():
        row = DA_BY_LABEL.get(da)
        geom = row["geo_simplified"] if row is not None else None
        if geom is None:
            continue

        gshape = shape(geom)
        area = gshape.area
        color = colormap(cnt)
        area_list.append((area, da, cnt, color, geom))

    # sort: large first → small on top
    area_list.sort(reverse=True)

    # ─────────────── Add each area as layer ─────────
    for _, da, cnt, col, geom in area_list:
        layer = folium.FeatureGroup(name=da, show=True)

        gj = folium.GeoJson(
            geom,
            name=da,
            style_function=lambda *_ , c=col: {
                "fillColor": c,
                "color": c,
                "weight": 1,
                "fillOpacity": 0.6,
            },
            highlight_function=lambda *_: {
                "weight": 3,
                "color": "black",
                "fillOpacity": 0.7,
            },
            tooltip=folium.Tooltip(f"{da}: {cnt} dataset(s)"),
        )
        gj.add_to(layer)
        layer.add_to(fmap)

    # ───────────────────── Add color legend BEFORE LayerControl ─────────────
    colormap.add_to(fmap)

    folium.LayerControl(collapsed=True, position='topright').add_to(fmap)

    from folium import MacroElement
    from jinja2 import Template

    css = MacroElement()
    css._template = Template("""
    {% macro html(this, kwargs) %}
    <style>
    .leaflet-control-layers-list {
        max-height: calc(100vh - 120px);
        max-width: 350px;
        overflow-y: auto;
        overflow-x: auto;
    }
    </style>
    {% endmacro %}
    """)
    fmap.get_root().add_child(css)

    # ───────────────────── Render via Streamlit ─────────────
    st_folium(fmap, use_container_width=True, height=800,returned_objects=[])

@st.cache_data
def load_domain_area_grid(_path: str):
    """Carica la griglia delle domain areas, gestendo sia il nuovo che il vecchio formato"""
    with open(_path, "rb") as f:
        data = pickle.load(f)
    
    # Handles both new format (with metadata) and old format
    if isinstance(data, dict) and 'grid' in data:
        return data['grid']
    else:
        # Backward compatibility with old format
        return data

def draw_grid_map(grid_path: str, datasets_dict: dict):
    grid_gdf = load_domain_area_grid(grid_path)
    if grid_gdf is None or grid_gdf.empty:
        st.warning("⚠️ Grid is empty or not loaded correctly.")
        return

    # Build from → dataset set
    da_to_dataset = defaultdict(set)
    for ds_id, ds in datasets_dict.items():
        for da in ds["domain_areas"]:
            da_to_dataset[da].add(ds_id)

    # Calculate total count per cell
    def total_for_cell(domain_areas):
        return sum(len(da_to_dataset.get(da, set())) for da in domain_areas)

    grid_gdf["total_count"] = grid_gdf["domain_areas"].apply(total_for_cell)
    max_val = grid_gdf["total_count"].max()

    if max_val == 0:
        st.warning("No datasets to show on the grid.")
        return

    colormap = linear.OrRd_09.scale(0, max_val)
    m = folium.Map(location=[42.5, 10], zoom_start=5, tiles="CartoDB positron")

    for _, row in grid_gdf.iterrows():
        count = row["total_count"]
        if count == 0:
            continue
        color = colormap(count)

        # Popup: show the number of datasets per area
        popup_text = "<br>".join(
            f"<b>{da}</b>: {len(da_to_dataset.get(da, set()))}"
            for da in row["domain_areas"]
            if da_to_dataset.get(da)
        )
        popup = folium.Popup(popup_text, max_width=250)

        folium.GeoJson(
            row["geometry"],
            style_function=lambda _: {
                "fillColor": color,
                "color": "black",
                "weight": 0.2,
                "fillOpacity": 0.7,
            },
            tooltip=popup,
        ).add_to(m)

    colormap.caption = "Total Dataset Count"
    
    # Configure legend to show only integer numbers
    if max_val > 0:
        # Create list of integer ticks
        num_ticks = min(6, max_val + 1)  # Maximum 6 ticks or available range
        tick_values = [int(x) for x in np.linspace(0, max_val, num_ticks)]
        # Remove duplicates maintaining order
        tick_values = list(dict.fromkeys(tick_values))
        colormap.tick_labels = [str(x) for x in tick_values]
    
    colormap.add_to(m)
    st_folium(m, width=900, height=600)
    
    
def draw_grid_raster(grid_path: str, datasets_dict: dict, show_borders: bool = False):
    """Disegna una griglia raster correttamente allineata usando Web Mercator"""
    import numpy as np
    import matplotlib.pyplot as plt
    from PIL import Image
    from io import BytesIO
    import base64
    import folium
    from branca.colormap import linear
    from streamlit_folium import st_folium
    from collections import defaultdict
    import geopandas as gpd

    # Load grid
    grid_gdf = load_domain_area_grid(grid_path)
    if grid_gdf is None or grid_gdf.empty:
        st.warning("⚠️ Grid is empty or not loaded correctly.")
        return

    # Build domain_area → dataset set
    da_to_dataset = defaultdict(set)
    for ds_id, ds in datasets_dict.items():
        for da in ds["domain_areas"]:
            da_to_dataset[da].add(ds_id)

    def total_for_cell(domain_areas):
        return sum(len(da_to_dataset.get(da, set())) for da in domain_areas)

    grid_gdf["total_count"] = grid_gdf["domain_areas"].apply(total_for_cell)
    max_val = grid_gdf["total_count"].max()
    if max_val == 0:
        st.warning("No datasets to show on the grid.")
        return

    # Add checkbox to show borders
    show_borders = st.checkbox("Show grid borders", value=False)

    # SOLUTION: Reproject to Web Mercator for regular grid
    grid_mercator = grid_gdf.to_crs("EPSG:3857")  # Web Mercator
    
    # Filter only non-empty cells for analysis
    non_empty_cells = grid_mercator[grid_mercator["total_count"] > 0]
    
    if len(non_empty_cells) == 0:
        st.warning("No non-empty cells to display.")
        return
    
    # Calculate bounds in meters (Web Mercator)
    minx_m, miny_m, maxx_m, maxy_m = non_empty_cells.total_bounds
    
    # Grid resolution estimation based on existing data
    # Find typical cell size
    cell_widths = non_empty_cells.geometry.bounds["maxx"] - non_empty_cells.geometry.bounds["minx"]
    cell_heights = non_empty_cells.geometry.bounds["maxy"] - non_empty_cells.geometry.bounds["miny"]
    
    typical_width = cell_widths.median()
    typical_height = cell_heights.median()
    
    # Calculate the number of cells along each axis
    n_cols = max(1, int(np.ceil((maxx_m - minx_m) / typical_width)))
    n_rows = max(1, int(np.ceil((maxy_m - miny_m) / typical_height)))
    
    # Create regular coordinates
    x_coords_m = np.linspace(minx_m, maxx_m, n_cols + 1)
    y_coords_m = np.linspace(miny_m, maxy_m, n_rows + 1)
    
    # Create image matrix
    img = np.zeros((n_rows, n_cols), dtype=float)
    
    # For each cell in the original grid, find the position in the matrix
    for _, row in non_empty_cells.iterrows():
        bounds = row.geometry.bounds
        center_x = (bounds[0] + bounds[2]) / 2
        center_y = (bounds[1] + bounds[3]) / 2
        
        # Find indices in the regular grid
        j = np.clip(int((center_x - minx_m) / typical_width), 0, n_cols - 1)
        i = np.clip(int((center_y - miny_m) / typical_height), 0, n_rows - 1)
        
        # Flip Y axis for image (Y grows downward in images)
        img[n_rows - 1 - i, j] = max(img[n_rows - 1 - i, j], row["total_count"])
    
    # Normalize and convert to RGBA
    if max_val > 0:
        norm_img = img / max_val
    else:
        norm_img = img
        
    cmap = plt.get_cmap("OrRd")
    rgba_img = (cmap(norm_img) * 255).astype(np.uint8)
    
    # Make pixels with value 0 transparent
    rgba_img[img == 0, 3] = 0  # Alpha channel = 0 for transparency
    
    pil_img = Image.fromarray(rgba_img, 'RGBA')

    # Encode PNG
    buf = BytesIO()
    pil_img.save(buf, format="PNG")
    img_url = f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}"

    # Convert bounds back to WGS84 for Folium
    from shapely.geometry import box
    bounds_gdf = gpd.GeoDataFrame(
        geometry=[box(minx_m, miny_m, maxx_m, maxy_m)], 
        crs="EPSG:3857"
    ).to_crs("EPSG:4326")
    
    minx, miny, maxx, maxy = bounds_gdf.total_bounds
    bounds = [[miny, minx], [maxy, maxx]]

    # Folium map
    center_lat = (miny + maxy) / 2
    center_lon = (minx + maxx) / 2
    m = folium.Map(
        location=[center_lat, center_lon], 
        zoom_start=6, 
        tiles="CartoDB positron"
    )

    # Aggiungi l'overlay raster
    folium.raster_layers.ImageOverlay(
        image=img_url,
        bounds=bounds,
        opacity=0.7,
        zindex=1,
        interactive=False,
    ).add_to(m)

    # Optional: show grid borders
    if show_borders:
        # Show only non-empty cells for clarity
        folium.GeoJson(
            non_empty_cells.to_crs("EPSG:4326").geometry, 
            name="Grid borders", 
            style_function=lambda _: {
                "color": "black", 
                "weight": 0.5, 
                "fillOpacity": 0.0,
                "opacity": 0.8
            }
        ).add_to(m)

    # Aggiungi la colorbar
    colormap = linear.OrRd_09.scale(0, max_val)
    colormap.caption = "Dataset count"
    
    # Configure legend to show only integer numbers
    if max_val > 0:
        # Create list of integer ticks
        num_ticks = min(6, max_val + 1)  # Maximum 6 ticks or available range
        tick_values = [int(x) for x in np.linspace(0, max_val, num_ticks)]
        # Remove duplicates maintaining order
        tick_values = list(dict.fromkeys(tick_values))
        colormap.tick_labels = [str(x) for x in tick_values]
    
    colormap.add_to(m)

    # Add layer control if borders are shown
    if show_borders:
        folium.LayerControl().add_to(m)

    # Mostra informazioni sulla griglia
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Celle totali", len(grid_gdf))
    with col2:
        st.metric("Celle con dati", len(non_empty_cells))
    with col3:
        st.metric("Max dataset per cella", int(max_val))

    st_folium(m, width=900, height=600, returned_objects=[])
    
    
    
import copy
import streamlit as st
import folium
from streamlit_folium import st_folium
from sqlalchemy import select, func, distinct, and_, or_, not_
from geoalchemy2 import Geometry, functions as geofunc
from database.dbconn import QueryManager, ZoningAreas, Plans, add_where, engine, CoverageUF, AreasOfInterest, GESNonov, MRUNonov

def set_map_state():
    if not st.session_state.get('new_map_state', False):
        st.session_state.new_map_state = {"center": {"lat": 50, "lng": 15}, "zoom": 4}
    st.session_state.map_state = copy.deepcopy(st.session_state.new_map_state)

@st.fragment
def make_map(qm, colors=None):
    # if st.session_state.get('aoi_selected_filter', False) and len(st.session_state.get('aoi_selected_filter', [])) >0:
    #     stmt = select(AreasOfInterest.geometry).where(AreasOfInterest.label.in_(st.session_state.aoi_selected_filter))
    #     aoi_filtered = qm.read(stmt, 'gdf').to_crs(epsg=4326)
    #     # aoi_filtered = aois[aois.label.isin(st.session_state.aoi_selected_filter)].to_crs(epsg=4326)
    if st.session_state.get('aoi_selected_filter', False):
        stmt = select(AreasOfInterest.geometry).where(AreasOfInterest.label==st.session_state.aoi_selected_filter)
        aoi_filtered = qm.read(stmt, 'gdf').to_crs(epsg=4326)
        # aoi_filtered = aois[aois.label.isin(st.session_state.aoi_selected_filter)].to_crs(epsg=4326)
    else:
        aoi_filtered = None
    filter_query = st.session_state.filter_query
    filter_query_geoplatform = st.session_state.filter_query_geoplatform
    # Get the last known map state
    last_location = [st.session_state.map_state['center']["lat"],
                     st.session_state.map_state['center']["lng"]
                     ]
    last_zoom = st.session_state.map_state['zoom']
    
    # Create a folium map using the last known state
    m = folium.Map(location=last_location, zoom_start=last_zoom)

    human_activities_wms_url = "https://ows.emodnet-humanactivities.eu/wms?"
    tools4msp_geoplatform_wms_url =  "https://geoplatform.tools4msp.eu/geoserver/wms?"
    bathymetry_wms_url = "https://ows.emodnet-bathymetry.eu/wms?"

    folium.raster_layers.WmsTileLayer(
        url=bathymetry_wms_url,
        name="Bathymetry",
        layers="emodnet:mean_atlas_land",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=False,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (All vessels)",
        layers="routedensity_allavg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Tanker)",
        layers="routedensity_04avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    
    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Cargo)",
        layers="routedensity_01avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    # Add WMS layer with the selected filter
    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Spatial Plan",
        layers="geonode:EMODnet_EU_SpatialPlans",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Zoning Elements",
        layers="geonode:EMODnet_EU_ZoningElements",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query_geoplatform
    ).add_to(m)

    if aoi_filtered is not None:
        geo_j = aoi_filtered.to_json()
        geo_j = folium.GeoJson(name="Areas of Interest", data=geo_j, style_function=lambda x: {"fillColor": "orange"})
        geo_j.add_to(m)
        bounds = aoi_filtered.total_bounds
        m.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])

    # Add LayerControl
    folium.LayerControl().add_to(m)

    # Dynamic features
    fg = folium.FeatureGroup(name="Analysis")
    if st.session_state.get('analysis_geo_results', None) is not None:
        _gdf = st.session_state.get('analysis_geo_results')
        color_column = st.session_state.get('assessment_col')
        if st.session_state.get('analysis_geo_results_tooltip', False):
            tooltip = folium.GeoJsonTooltip(fields=st.session_state.get('analysis_geo_results_tooltip'))
        else:
            tooltip = None
        if colors is None:
            colors = {}
        folium.GeoJson(
            _gdf,
            marker=folium.CircleMarker(radius=6, fill=True), 
            style_function=lambda feature: {
                "fillColor": colors.get(feature["properties"][color_column], '#999999'),
                "color": "",
                # "weight": 1,
                "fillOpacity": 1,
            },
            tooltip=tooltip,
        ).add_to(fg)

    st.write("# Maritime Spatial Plans (EMODnet)")
    c_map, c_spid = st.columns([7, 3])
    with c_map:
        # Display the map in Streamlit
        st_map = st_folium(m,
                           feature_group_to_add=fg,
                           width=1200,
                           height=500,
                           use_container_width=True,
                           key="new_map_state")
    with c_spid:
        st.write("### Spatial Plan IDs (SPID)")
        st.dataframe(st.session_state.selected_plans.sort_values(['MS', 'SPID']), hide_index=True)

    return st_map, m, fg
