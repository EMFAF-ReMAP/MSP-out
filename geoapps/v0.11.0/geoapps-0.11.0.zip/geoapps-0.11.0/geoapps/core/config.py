"""
Modulo di configurazione centralizzata per GeApps

Gestisce le configurazioni per tutti gli ambienti (development, production)
e carica i secrets da file separati non committati.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class ConfigManager:
    """Gestisce la configurazione centralizzata dell'applicazione"""
    
    def __init__(self, environment: Optional[str] = None):
        self.environment = environment or os.getenv("GEOAPPS_ENV", "production")
        self.base_path = Path(__file__).parent.parent.parent  # Torna alla root del progetto
        self._config = None
        self._secrets = None
        
        # Log environment per debug
        import sys
        sys.stderr.write(f"🔧 [ConfigManager] Initializing...\n")
        sys.stderr.write(f"🔧 [ConfigManager] Environment: {self.environment}\n")
        sys.stderr.write(f"🔧 [ConfigManager] GEOAPPS_ENV: {os.getenv('GEOAPPS_ENV', 'NOT SET')}\n")
        sys.stderr.write(f"🔧 [ConfigManager] Base path: {self.base_path}\n")
        sys.stderr.write(f"🔧 [ConfigManager] Config file: {self.base_path / 'config.yaml'}\n")
        sys.stderr.flush()
        
        self._load_config()
        self._load_secrets()
        
        # Avvia automaticamente il tunnel SSH in development
        if self.environment == "development" and self.get("database.ssh_tunnel.enabled"):
            self._ensure_ssh_tunnel()
    
    def _load_config(self):
        """Carica la configurazione da config.yaml"""
        import sys
        
        config_file = self.base_path / "config.yaml"
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                self._config = yaml.safe_load(f)
                sys.stderr.write(f"✅ [ConfigManager] Loaded config.yaml successfully\n")
                sys.stderr.flush()
        except FileNotFoundError as e:
            sys.stderr.write(f"⚠️ [ConfigManager] config.yaml not found at {config_file}\n")
            sys.stderr.write(f"⚠️ [ConfigManager] Error: {e}\n")
            sys.stderr.flush()
            self._config = {}
        except yaml.YAMLError as e:
            sys.stderr.write(f"❌ [ConfigManager] Error parsing config.yaml: {e}\n")
            sys.stderr.flush()
            self._config = {}
    
    def _load_secrets(self):
        """Carica i secrets da file separato"""
        secrets_file = self.base_path / "secrets.yaml"
        if secrets_file.exists():
            try:
                with open(secrets_file, 'r', encoding='utf-8') as f:
                    self._secrets = yaml.safe_load(f)
            except yaml.YAMLError as e:
                logger.warning(f"Errore nel parsing dei secrets: {e}")
                self._secrets = {}
        else:
            logger.warning(f"File secrets.yaml non trovato. Crealo copiando secrets.yaml.example")
            self._secrets = {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Ottiene un valore di configurazione usando dot notation
        
        Args:
            key: Chiave in formato "section.subsection.key"
            default: Valore di default se la chiave non esiste
        
        Returns:
            Il valore di configurazione
        """
        try:
            # Prima cerca nei secrets
            value = self._get_nested_value(self._secrets, key)
            if value is not None:
                return value
            
            # Poi cerca direttamente nella configurazione (file piatto, non più sezioni per environment)
            value = self._get_nested_value(self._config, key)
            if value is not None:
                return value
            
            return default
        except Exception:
            return default
    
    def _get_nested_value(self, data: Dict, key: str) -> Any:
        """Ottiene un valore usando dot notation"""
        keys = key.split('.')
        current = data
        
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return None
        
        return current
    
    def get_database_url(self) -> str:
        """Costruisce l'URL di connessione al database"""
        driver = self.get("database.driver", "postgresql")
        username = self.get("database.username")
        password = self.get("database_password") or self.get("database.password")
        host = self.get("database.host")
        port = self.get("database.port")
        database = self.get("database.database")
        
        db_url = f"{driver}://{username}:{password}@{host}:{port}/{database}"
        logger.info(f"🔧 Database URL constructed: {driver}://{username}:***@{host}:{port}/{database}")
        return db_url
    
    def get_data_path(self, key: str) -> Path:
        """Ottiene un percorso di dati come oggetto Path"""
        path_str = self.get(f"data_paths.{key}")
        if path_str:
            path = Path(path_str)
            # Se è un percorso relativo, lo rendiamo assoluto rispetto alla root del progetto
            if not path.is_absolute():
                path = self.base_path / path
            return path
        return None
    
    def get_api_config(self, key: str = None) -> str:
        """Ottiene configurazioni API"""
        if key:
            return self.get(f"api.{key}")
        return {
            "url": self.get("api.url"),
            "key": self.get("api_key") or self.get("api.key")
        }


# Istanza globale del config manager
config = ConfigManager()

# Funzioni di convenienza
def get_config(key: str, default: Any = None) -> Any:
    """Funzione di convenienza per ottenere configurazioni"""
    return config.get(key, default)

def get_database_url() -> str:
    """Funzione di convenienza per ottenere l'URL del database"""
    return config.get_database_url()

def get_secret(key: str, default: Any = None) -> Any:
    """Funzione di convenienza per ottenere secrets"""
    return config.get(key, default)

def get_data_path(key: str) -> Path:
    """Funzione di convenienza per ottenere percorsi dati"""
    return config.get_data_path(key)

def get_api_config(key: str = None):
    """Funzione di convenienza per ottenere configurazioni API"""
    return config.get_api_config(key)