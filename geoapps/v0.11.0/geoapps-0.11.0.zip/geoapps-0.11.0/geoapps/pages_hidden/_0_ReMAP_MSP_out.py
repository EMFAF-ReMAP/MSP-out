import pickle
import pathlib
from matplotlib import pyplot as plt
from matplotlib.backends.backend_agg import RendererAgg
from time import sleep
from threading import RLock

import streamlit as st
import geopandas as gpd
import pydeck as pdk
import pandas as pd
import copy
import numpy as np
import seaborn as sns  # included as in L1

import folium
from streamlit_folium import st_folium
from streamlit.components.v1 import html
from branca.element import Element
from tools.utils import make_login, make_header, set_sankey_data
import plotly.express as px
import plotly.graph_objects as go

from upsetplot import from_memberships, UpSet

from auth.access_guard import require_app_login
require_app_login()  # redirect if not logged in

from tools.importer import *
from database.dbconn import QueryManager, ZoningAreas, Plans, add_where, engine, CoverageUF, AreasOfInterest
from sqlalchemy import select, func, distinct
from geoalchemy2 import Geometry, functions as geofunc

_lock = RLock()

qm = QueryManager(engine)
qmconf = QueryManager(engine)

# Page config removed – handled by the main app

explanations = {
    "Zoning Elements":
        """According to EMODnet, Zoning Elements (ZEs) are spatial objects,
part of a spatial plan, defining activities and uses in a specific
area. This analysis offers insights on the number of ZEs, and the
relative Disjoint Index""",
    "n_ze":
        """The graph and table display the number of Zoning Elements for each
country or spatial plan, as present in EMODnet.""",
    "disjoint":
        """The graph and table display the Disjoint Index for each country or
spatial plan. The Disjoint Index ranges from 0 to 1, where 0 indicates
perfect overlapping between Zoning Elements, while 1 indicated absence
of overlapping.""",
    "Sea use":
        """This analysis offers a visual idea of which activities are present
or absent in a plan, and their relative spatial coverage.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.  """,
    "Sea use & Function":
        """This analysis offers an overview of the Sea uses present in a plan,
and their relative Functions.

In EMODnet, each Zoning Element is described by a set of fields, one
of which is the Sea use, describing the human activity present in that
area. EMODnet offers a list of Sea uses, as present in the graphs and
tables below.

Another Zoning Elements’ attribute can be the Function, describing the
regulatory framework of a given activity in the area. The model
provides six possible Functions:

* Reserved: areas specifically designated for the development of certain activities 
* Priority: activities with precedence over any other 
* Allowed: activities with permission to be developed 
* Potential: activities that could be developed according to the characteristics of the area 
* Restricted: specific activities that can not be carried out in a given area 
* Forbidden: activities that cannot be developed according to the plan 

The Function Undefined was added by the module developers to cover
those Zoning Elements that were missing the Function attribute.  """,
    "Multi-source overlay":
        """This analysis adds European-wide geospatial layers, such as
bathymetry and vessel density, to offer a comprehensive understanding
of the maritime context.  """
}

make_header()

def set_map_state():
    if not st.session_state.get('new_map_state', False):
        st.session_state.new_map_state = {"center": {"lat": 50, "lng": 15}, "zoom": 4}
    st.session_state.map_state = copy.deepcopy(st.session_state.new_map_state)

def process_data(analysis=True):
    set_map_state()
    with st.spinner("Wait for it...", show_time=True):
        make_map()
    if analysis:
        with st.spinner("Wait for it...", show_time=True):
            todo()

@st.fragment
def make_conf():
    conf_ze = qmconf.run('ze_distinct')
    conf_aois = qmconf.run('aois', mode='list')
    conf_plans = qmconf.run('plans')
        
    ms_filter_options = conf_ze.MS.unique()

    st.write("###  Settings")
    uc_filter_options = [
        None,
        'Baltic sea use case',
        'North-Western Mediterranean sea use case',
        'Galicia use case',
    ]

    filter_array = []
    filter_array_geoplatform = []

    def update_defaults():
        profile_choice = st.session_state.uc_selected_filter
        if profile_choice is None:
            st.session_state.ms_selected_filter = []
            st.session_state.aoi_selected_filter = []
        elif profile_choice == 'Baltic sea use case':
            st.session_state.ms_selected_filter = ['Denmark', 'Estonia', 'Finland', 'Germany', 'Latvia', 'Lithuania', 'Poland', 'Sweden']
            st.session_state.aoi_selected_filter = ['Baltic sea']
        elif profile_choice == 'North-Western Mediterranean sea use case':
            st.session_state.ms_selected_filter = ['Spain', 'France', 'Italy']
            st.session_state.aoi_selected_filter = ['North-Western Mediterranean Sea PSSA']
        elif profile_choice == 'Galicia use case':
            st.session_state.ms_selected_filter = ['Spain']
            st.session_state.aoi_selected_filter = ['Galicia']

    uc_selected_filter = st.selectbox(
        "Profiles",
        key="uc_selected_filter",
        options=uc_filter_options,
        on_change=update_defaults
    )

    st.write("####  Area of Analysis")
    ms_selected_filter = st.multiselect("Member states", options=sorted(ms_filter_options),
                                        key="ms_selected_filter")
    if len(ms_selected_filter) > 0:
        filter_array.append(" or ".join([f"ms LIKE '{ms}'" for ms in ms_selected_filter]))
        # replace value for France
        ms_selected_filter_fr = ['France-MED' if x == 'France' else x for x in ms_selected_filter]
        filter_array_geoplatform.append(" or ".join([f"MS LIKE '{ms}'" for ms in ms_selected_filter_fr]))

    if len(ms_selected_filter) > 0:
        spid_filter_options = conf_ze[conf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    else:
        spid_filter_options = conf_ze.SPID.unique()
    spid_selected_filter = st.multiselect("Spatial Plan (SPID)", options=sorted(spid_filter_options), key="spid_selected_filter")

    # if filter is None select the SPID from selected member states (if any)
    ms_spid_selected_filter = spid_selected_filter
    if len(spid_selected_filter) == 0 and len(ms_selected_filter) > 0:
        ms_spid_selected_filter = conf_ze[conf_ze.MS.isin(ms_selected_filter)].SPID.unique()
    st.session_state.ms_spid_selected_filter = ms_spid_selected_filter

    # Spatial plans
    selected_plans = conf_plans[['MS', 'SPID', 'OffTitle']].copy()
    if len(spid_selected_filter) > 0:
        selected_plans = selected_plans[selected_plans.SPID.isin(spid_selected_filter)]
    selected_plans.SPID = selected_plans.SPID.replace(map_spid)
    st.session_state.selected_plans = selected_plans.copy()

    # Area of interest
    aoi_filter_options = conf_aois
    aoi_selected_filter = st.multiselect("Areas of Interest / Transboundary areas",
                                         options=aoi_filter_options,
                                         key="aoi_selected_filter")

    # Spatial scale
    sc_filter_options = ['Member State', 'Spatial Plan']
    sc_selected_filter = st.selectbox("Spatial scale", options=sc_filter_options, key="sc_selected_filter")

    if sc_selected_filter == 'Spatial Plan' and len(spid_selected_filter) > 0:
        spid_orig = [k for k, v in map_spid.items() if v in spid_selected_filter]
        filter_array.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig]))

        # replace value for France
        spid_orig_fr = ['FRA-MED' if x == 'DSF_MED' else x for x in spid_orig]
        filter_array_geoplatform.append(" or ".join([f"SPID = '{_spid_orig}'" for _spid_orig in spid_orig_fr]))

    st.divider()
    st.write("####  Kind of Analysis")
    analysis_filter_options = [
        'Zoning Elements',
        'Sea use',
        'Sea use & Function',
        'Coexistence',
        # 'Multi-source overlay',  # intentionally hidden like S2
        'Diagnosis',
    ]
    analysis_selected_filter = st.selectbox("Analysis", options=analysis_filter_options, key="analysis_selected_filter")

    st.divider()
    st.write("#### Focus")

    spid_filter_options = conf_ze['Sea use'].unique()
    _gdf = conf_ze
    if len(ms_selected_filter) > 0:
        _gdf = _gdf[_gdf.MS.isin(ms_selected_filter)]
    if len(spid_selected_filter) > 0:
        _gdf = _gdf[_gdf.SPID.isin(spid_selected_filter)]

    seause_filter_options = _gdf['Sea use'].unique()
    seause_selected_filter = st.multiselect("Sea use", options=seause_filter_options, key="seause_selected_filter")

    if len(seause_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausename = '{_seause}'" for _seause in seause_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseName = '{_seause}'" for _seause in seause_selected_filter]))
        _gdf = _gdf[_gdf['Sea use'].isin(seause_selected_filter)]

    # Function filter
    function_filter_options = _gdf['Function'].unique()
    function_selected_filter = st.multiselect("Sea use function", options=function_filter_options, key="function_selected_filter")

    if len(function_selected_filter) > 0:
        filter_array.append(" or ".join([f"seausefct = '{_function}'" for _function in function_selected_filter]))
        filter_array_geoplatform.append(" or ".join([f"SeaUseFct = '{_function}'" for _function in function_selected_filter]))

    # Compose WMS filters
    filter_array = [f"({_f})" for _f in filter_array]
    filter_query = " and ".join(filter_array)

    filter_array_geoplatform = [f"({_f})" for _f in filter_array_geoplatform]
    filter_query_geoplatform = " and ".join(filter_array_geoplatform)

    st.session_state.filter_query = filter_query
    st.session_state.filter_query_geoplatform = filter_query_geoplatform

    st.button("Process", on_click=process_data)

with st.sidebar:
    st.image('https://www.shom.fr/sites/default/files/inline-images/logo_ReMAP_0.png', width=200)
    make_conf()

@st.fragment
def make_map():
    if len(st.session_state.aoi_selected_filter) > 0:
        stmt = select(AreasOfInterest.geometry).where(AreasOfInterest.label.in_(st.session_state.aoi_selected_filter))
        aoi_filtered = qm.read(stmt, 'gdf').to_crs(epsg=4326)
    else:
        aoi_filtered = None

    filter_query = st.session_state.filter_query
    filter_query_geoplatform = st.session_state.filter_query_geoplatform

    # keep previous map state
    last_location = [
        st.session_state.map_state['center']["lat"],
        st.session_state.map_state['center']["lng"]
    ]
    last_zoom = st.session_state.map_state['zoom']
    
    m = folium.Map(location=last_location, zoom_start=last_zoom)

    human_activities_wms_url = "https://ows.emodnet-humanactivities.eu/wms?"
    tools4msp_geoplatform_wms_url = "https://geoplatform.tools4msp.eu/geoserver/wms?"
    bathymetry_wms_url = "https://ows.emodnet-bathymetry.eu/wms?"

    folium.raster_layers.WmsTileLayer(
        url=bathymetry_wms_url,
        name="Bathymetry",
        layers="emodnet:mean_atlas_land",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=False,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (All vessels)",
        layers="routedensity_allavg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Tanker)",
        layers="routedensity_04avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=human_activities_wms_url,
        name="Maritime transport (Cargo)",
        layers="routedensity_01avg",
        show=False,
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Spatial Plan",
        layers="geonode:EMODnet_EU_SpatialPlans",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query
    ).add_to(m)

    folium.raster_layers.WmsTileLayer(
        url=tools4msp_geoplatform_wms_url,
        name="MSP Zoning Elements",
        layers="geonode:EMODnet_EU_ZoningElements",
        fmt="image/png",
        transparent=True,
        control=True,
        overlay=True,
        cql_filter=filter_query_geoplatform
    ).add_to(m)

    if aoi_filtered is not None:
        geo_j = aoi_filtered.to_json()
        geo_j = folium.GeoJson(data=geo_j, style_function=lambda x: {"fillColor": "orange"})
        geo_j.add_to(m)
        bounds = aoi_filtered.total_bounds
        m.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])

    folium.LayerControl().add_to(m)

    st.write("# Maritime Spatial Plans (EMODnet)")
    col1, col2 = st.columns([7, 3])
    with col1:
        st_folium(
            m,
            width=1200,
            height=500,
            use_container_width=True,
            key="new_map_state"
        )
    with col2:
        st.write("### Spatial Plan IDs (SPID)")
        st.dataframe(st.session_state.selected_plans.sort_values(['MS', 'SPID']), hide_index=True)

def get_filter_column():
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        column = 'SPID'
    elif st.session_state.sc_selected_filter == 'Member State':
        column = 'MS'
    return column

def apply_filters():
    qm._filters = {}
    _selected_filter = None
    column = get_filter_column()
    if st.session_state.sc_selected_filter == 'Spatial Plan':
        _selected_filter = st.session_state.ms_spid_selected_filter
    elif st.session_state.sc_selected_filter == 'Member State':
        _selected_filter = st.session_state.ms_selected_filter

    if len(_selected_filter) > 0:
        qm.set_filter(column, _selected_filter)
    if len(st.session_state.seause_selected_filter) > 0:
        qm.set_filter('Sea_use', st.session_state.seause_selected_filter)
    if len(st.session_state.function_selected_filter) > 0:
        qm.set_filter('Function', st.session_state.function_selected_filter)

    if len(st.session_state.aoi_selected_filter) > 0:
        subq = (
            select(geofunc.ST_Union(AreasOfInterest.geometry).label("geometry"))
            .where(AreasOfInterest.label.in_(st.session_state.aoi_selected_filter))
            .subquery()
        )
        qm.set_filter('ST_intersects', subq.c.geometry)

@st.fragment
def todo():
    analysis_header = st.empty()
    analysis_container = st.empty()
    col1, col2 = st.columns([5, 5])
    col1r0 = col1.empty()
    col1r1 = col1.empty()
    col1r2 = col1.empty()
    col1r3 = col1.empty()
    col2r0 = col2.empty()
    col2r1 = col2.empty()
    col2r2 = col2.empty()
    col2r3 = col2.empty()

    with analysis_header.container():
        st.write(f"## {st.session_state.analysis_selected_filter} Analysis")
        explanation = explanations.get(st.session_state.analysis_selected_filter)
        if explanation is not None:
            with st.popover("ℹ️ "):
                st.write(explanation)

    column = get_filter_column()
    zoning_areas_column = getattr(ZoningAreas, column)
    plans_column = getattr(Plans, column)
    coverage_uf_column = getattr(CoverageUF, column)
    apply_filters()

    if st.session_state.analysis_selected_filter == 'Sea use':
        col1r0.write("")
        col2r0.write("")

        # coverage aggregated by unique coverage index & Sea_use
        stmt_coverage_s = select(
            CoverageUF.index,
            coverage_uf_column,
            CoverageUF.Sea_use,
            CoverageUF.geoarea
        ).distinct(CoverageUF.index, CoverageUF.Sea_use)
        stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()

        subq_column = getattr(stmt_coverage_s.c, column)
        stmt_coverage = select(
            subq_column,
            stmt_coverage_s.c.Sea_use,
            func.sum(stmt_coverage_s.c.geoarea).label("geoarea")
        ).group_by(subq_column, stmt_coverage_s.c.Sea_use).subquery()

        stmt_plans = select(
            plans_column,
            func.sum(Plans.geoarea).label("geoarea_plan"),
            func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
        ).group_by(plans_column)
        stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

        stmt_coverage_col = getattr(stmt_coverage.c, column)
        stmt_plans_col = getattr(stmt_plans.c, column)

        stmt = (
            select(
                stmt_coverage_col,
                stmt_coverage.c.Sea_use,
                stmt_coverage.c.geoarea,
                stmt_plans.c.geoarea_noboundaries,
                stmt_plans.c.geoarea_plan,
            )
            .select_from(stmt_coverage)
            .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
        )

        _df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)

        _df['coverage %'] = _df.geoarea / _df.geoarea_noboundaries * 100
        _df['coverage_plan %'] = _df.geoarea / _df.geoarea_plan * 100

        u_df = _df.pivot(columns='Sea_use', index=column, values='coverage %')
        u_df = u_df.dropna(how='all').round(0)

        with col1r1.container():
            fig = px.imshow(
                u_df,
                text_auto=True,
                aspect="auto",
                color_continuous_scale="aggrnyl_r",
                title="Percentage of sea use surfaces relative to Zoning Elements coverage"
            )
            fig = fig.update_traces(xgap=2, ygap=2)
            st.plotly_chart(fig, theme="streamlit", use_container_width=True)
        col1r2.dataframe(u_df.T)

        u_df2 = _df.groupby([column, 'Sea_use'])['coverage_plan %'].sum().to_frame().reset_index()
        u_df2 = u_df2.pivot(columns='Sea_use', index=column, values='coverage_plan %')
        u_df2 = u_df2.dropna(how='all').round(0)

        with col2r1.container():
            fig2 = px.imshow(
                u_df2,
                text_auto=True,
                aspect="auto",
                color_continuous_scale="aggrnyl_r",
                title="Percentage of sea use surfaces relative to Spatial Plan coverage"
            )
            fig2 = fig2.update_traces(xgap=2, ygap=2)
            st.plotly_chart(fig2, theme="streamlit", use_container_width=True)
        col2r2.dataframe(u_df2.T)

    elif st.session_state.analysis_selected_filter == 'Zoning Elements':
        with col1r0.container():
            st.write("**Number of Zoning Elements**")
            with st.expander("ℹ️  See explanation"):
                st.write(explanations.get("n_ze"))

        with col2r0.container():
            st.write("**Disjoint Index**")
            with st.expander("ℹ️  See explanation"):
                st.write(explanations.get("disjoint"))

        stmt = select(zoning_areas_column, func.count().label("Number_ZE")).group_by(zoning_areas_column)
        stmt = add_where(stmt, ZoningAreas, qm._filters)
        __df = qm.read(stmt, 'df', index_col=column)

        with col1r1.container():
            st.bar_chart(__df)
        col1r2.dataframe(__df)

        stmt_zoning_areas = select(
            zoning_areas_column,
            func.sum(ZoningAreas.geoarea).label("geoarea")
        ).group_by(zoning_areas_column)
        stmt_zoning_areas = add_where(stmt_zoning_areas, ZoningAreas, qm._filters).subquery()

        stmt_plans = select(
            plans_column,
            func.sum(Plans.geoarea).label("geoarea_plan")
        ).group_by(plans_column)
        stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

        stmt_coverage_s = select(
            CoverageUF.index,
            coverage_uf_column,
            CoverageUF.geoarea
        ).distinct(CoverageUF.index)
        stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()

        stmt_zoning_areas_col = getattr(stmt_zoning_areas.c, column)
        stmt_plans_col = getattr(stmt_plans.c, column)
        stmt_coverage_col = getattr(stmt_coverage_s.c, column)

        stmt_coverage = select(
            stmt_coverage_col,
            func.sum(stmt_coverage_s.c.geoarea).label("geoarea_coverage")
        ).group_by(stmt_coverage_col).subquery()

        stmt_final = (
            select(
                stmt_zoning_areas_col,
                stmt_zoning_areas.c.geoarea,
                stmt_plans.c.geoarea_plan,
                stmt_coverage.c.geoarea_coverage
            )
            .select_from(stmt_zoning_areas)
            .join(stmt_plans, stmt_zoning_areas_col == stmt_plans_col)
            .join(stmt_coverage, stmt_zoning_areas_col == getattr(stmt_coverage.c, column))
        )

        __df = qm.read(stmt_final, 'df', index_col=column)

        field = 'Disjoint_index'
        ___df = (__df.geoarea_coverage / __df.geoarea).to_frame(field)
        ___df['ZE Coverage (%)'] = ((__df.geoarea_coverage / __df.geoarea_plan) * 100).round(1)

        col2r1.bar_chart(___df[field])
        col2r2.dataframe(___df)

    elif st.session_state.analysis_selected_filter == 'Sea use & Function':
        stmt_coverage_s = select(
            CoverageUF.index,
            coverage_uf_column,
            CoverageUF.Sea_use,
            CoverageUF.Function,
            CoverageUF.geoarea
        ).distinct(CoverageUF.index, CoverageUF.Sea_use, CoverageUF.Function)
        stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()

        subq_column = getattr(stmt_coverage_s.c, column)
        stmt_coverage = select(
            subq_column,
            stmt_coverage_s.c.Sea_use,
            stmt_coverage_s.c.Function,
            func.sum(stmt_coverage_s.c.geoarea).label("geoarea")
        ).group_by(subq_column, stmt_coverage_s.c.Sea_use, stmt_coverage_s.c.Function).subquery()

        stmt_plans = select(
            plans_column,
            func.sum(Plans.geoarea).label("geoarea_plan"),
            func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
        ).group_by(plans_column)
        stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

        stmt_coverage_col = getattr(stmt_coverage.c, column)
        stmt_plans_col = getattr(stmt_plans.c, column)

        stmt = (
            select(
                stmt_coverage_col,
                stmt_coverage.c.Sea_use,
                stmt_coverage.c.Function,
                stmt_coverage.c.geoarea,
                stmt_plans.c.geoarea_noboundaries,
                stmt_plans.c.geoarea_plan,
            )
            .select_from(stmt_coverage)
            .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
        )

        _df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)
        _df.Function = _df.Function.replace(' ', 'Undefined')
        _df['coverage %'] = _df.geoarea / _df.geoarea_noboundaries * 100

        SORTED_FUNCTIONS = ['Reserved', 'Priority', 'Allowed', 'Potential', 'Restricted', 'Forbidden', 'Undefined']
        SORTED_SEAUSES = qmconf.run('ze_distinct')['Sea use'].sort_values().unique()

        fig = px.bar(
            _df,
            x="coverage %",
            y="Sea use",
            color="Function",
            orientation="h",
            facet_col=column,
            facet_col_wrap=3,
            category_orders={
                "Sea use": SORTED_SEAUSES,
                "Function": SORTED_FUNCTIONS,
            }
        )
        fig.update_layout(barmode="stack")
        fig.update_yaxes(tickfont=dict(size=10))
        col1r1.plotly_chart(fig, theme="streamlit", use_container_width=True)

        col2r1.dataframe(_df)
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Coexistence':
        with analysis_container.container():
            plot_upset(column)
        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Multi-source overlay':
        # Option intentionally not listed in UI (same as S2). Kept for completeness.
        st.info("Multi-source overlay is currently disabled in this build.")
        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

    elif st.session_state.analysis_selected_filter == 'Diagnosis':
        with analysis_container.container():
            stmt = select(
                zoning_areas_column,
                ZoningAreas.OriginUNEn,
                ZoningAreas.Sea_use,
                ZoningAreas.Function,
                ZoningAreas.geoarea,
                ZoningAreas.HilucsMSP
            )
            stmt = add_where(stmt, ZoningAreas, qm._filters)
            plot_diagnosis_sankey(stmt, column, zoning_areas_column)
            st.divider()
            plot_treemap(qm.read(stmt, 'df').fillna(0))

        col2r1.write("")
        col1r2.write("")
        col2r2.write("")

@st.fragment
def plot_treemap(df):
    st.write("### Hierarchical exploration")
    df['Hilucs MSP'] = df.HilucsMSP.str.split('_').str[-1].str.replace('.html', '')

    treemap_explore_by_options = ['Member states', 'Sea uses', 'Hilucs MSP']
    treemap_explore_by_selected = st.selectbox(
        "Explore by",
        options=treemap_explore_by_options,
        key="treemap_explore_by_selected",
    )
    tree_title = treemap_explore_by_selected
    if treemap_explore_by_selected == 'Member states':
        tree_columns = ['MS', 'Sea use', 'Function', 'OriginUNEn']
    elif treemap_explore_by_selected == 'Sea uses':
        tree_columns = ['Sea use', 'MS', 'OriginUNEn', 'Function']
    elif treemap_explore_by_selected == 'Hilucs MSP':
        tree_columns = ['Hilucs MSP', 'MS', 'OriginUNEn', 'Function']

    treemap_color_options = tree_columns
    treemap_color_selected = st.selectbox(
        "Color mode",
        options=treemap_color_options,
        key="treemap_color_selected",
    )

    st.write(f"**Hierarchy**: {' -> '.join(tree_columns)}")
    fig = px.treemap(
        df,
        path=[px.Constant(tree_title)] + tree_columns,
        values='geoarea',
        color=st.session_state.treemap_color_selected,
    )
    fig.update_layout(margin=dict(t=50, l=25, r=25, b=25))
    fig.update_traces(marker=dict(cornerradius=5))
    st.plotly_chart(fig, use_container_width=True)

@st.fragment
def plot_upset(column):
    upset_sc_filter_options = qm.run("plans")[column].unique()
    st.selectbox(
        st.session_state.sc_selected_filter,
        options=upset_sc_filter_options,
        key="upset_sc_selected_filter",
    )

    coverage_uf_column = getattr(CoverageUF, column)
    plans_column = getattr(Plans, column)

    stmt_coverage_s = select(
        CoverageUF.index,
        coverage_uf_column,
        CoverageUF.Sea_use,
        CoverageUF.geoarea
    ).distinct(CoverageUF.index, CoverageUF.Sea_use)

    stmt_coverage_s = stmt_coverage_s.where(coverage_uf_column == st.session_state.upset_sc_selected_filter)
    stmt_coverage_s = add_where(stmt_coverage_s, CoverageUF, qm._filters).subquery()

    stmt_plans = select(
        plans_column,
        func.sum(Plans.geoarea).label("geoarea_plan"),
        func.sum(Plans.geoarea_coverage).label("geoarea_coverage"),
        func.sum(Plans.geoarea_noboundaries).label("geoarea_noboundaries")
    ).group_by(plans_column)
    stmt_plans = add_where(stmt_plans, Plans, qm._filters).subquery()

    stmt_coverage_col = getattr(stmt_coverage_s.c, column)
    stmt_plans_col = getattr(stmt_plans.c, column)

    stmt = (
        select(
            stmt_coverage_s.c.index.label("coverageid"),
            stmt_coverage_col,
            stmt_coverage_s.c.Sea_use,
            stmt_coverage_s.c.geoarea,
            stmt_plans.c.geoarea_coverage,
            stmt_plans.c.geoarea_noboundaries,
            stmt_plans.c.geoarea_plan,
        )
        .select_from(stmt_coverage_s)
        .join(stmt_plans, stmt_coverage_col == stmt_plans_col)
    )

    __df = qm.read(stmt, 'df', index_col=column).reset_index().fillna(0)
    geoarea_column = f'geoarea_perc_{column.lower()}'
    __df[geoarea_column] = __df.geoarea / __df['geoarea_coverage'] * 100

    _df_entity = __df.groupby('coverageid').agg({'Sea_use': list, geoarea_column: 'sum'})

    upset_data = from_memberships(
        _df_entity['Sea_use'],
        data=_df_entity[[geoarea_column]]
    )
    if upset_data.index.nlevels <= 1:
        st.warning(
            "The number of selected or available uses is not sufficient to perform a coexistence analysis. "
            "At least two uses are required."
        )
        return

    with _lock:
        fig, ax = plt.subplots()
        upset = UpSet(
            upset_data,
            sum_over=geoarea_column,
            totals_plot_elements=12,
            min_subset_size=0.5,
        )
        plots = upset.plot(fig=fig)
        plots['totals'].set_title("surface occupied (%)")
        st.pyplot(fig, width="content")

@st.fragment
def plot_diagnosis_sankey(stmt, column, zoning_areas_column):
    sankey_sc_filter_options = qm.run("plans")[column].unique()
    st.selectbox(
        st.session_state.sc_selected_filter,
        options=sankey_sc_filter_options,
        key="sankey_sc_selected_filter",
    )

    stmt = stmt.where(zoning_areas_column == st.session_state.sankey_sc_selected_filter)

    __df = qm.read(stmt, 'df').fillna(0)
    sankey_columns = ['OriginUNEn', 'Sea use', 'Function']

    labels, sources, targets, values, link_colors, sourceinfo = set_sankey_data(__df, sankey_columns, 'geoarea')

    fig = go.Figure(go.Sankey(
        node=dict(
            label=labels,
            color="grey",
        ),
        link=dict(
            source=sources,
            target=targets,
            value=values,
            color=link_colors,
            customdata=sourceinfo,
            hovertemplate='OriginUNEn %{customdata}<br />'
                          'source: %{source.label}<br />'
                          'target: %{target.label}<br />'
                          'area: %{value}<br />',
        ),
        textfont=dict(
            color='black',
            shadow="rgba(0, 0, 0, 0)",
        )
    ))

    for x_coordinate, column_name in enumerate(["OriginUNEn", "Sea use", "Function"]):
        fig.add_annotation(
            x=x_coordinate,
            y=1.075,
            xref="x",
            yref="paper",
            text=column_name,
            showarrow=False,
            align="left",
        )
    fig.update_traces(node_hoverlabel=dict(bgcolor="white"))
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(__df[sankey_columns])

process_data(False)
