#!/usr/bin/env python3
"""
Script di test per verificare la configurazione del database
"""
import os
import sys

print("=" * 60)
print("🔍 TEST CONFIGURAZIONE DATABASE")
print("=" * 60)

# 1. Check variabili d'ambiente
print("\n1️⃣ Variabili d'ambiente:")
print(f"   GEOAPPS_ENV = {os.getenv('GEOAPPS_ENV', 'NOT SET')}")
print(f"   STREAMLIT_SERVER_PORT = {os.getenv('STREAMLIT_SERVER_PORT', 'NOT SET')}")

# 2. Import config
print("\n2️⃣ Importing core.config...")
try:
    # Add current directory to path
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from core import config
    print(f"   ✅ Config imported successfully")
    print(f"   Environment detected: {config.config.environment}")
except Exception as e:
    print(f"   ❌ Error importing config: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 3. Get database config
print("\n3️⃣ Database configuration from config.yaml:")
try:
    db_driver = config.get_config("database.driver", "NOT SET")
    db_host = config.get_config("database.host", "NOT SET")
    db_port = config.get_config("database.port", "NOT SET")
    db_name = config.get_config("database.database", "NOT SET")
    db_user = config.get_config("database.username", "NOT SET")
    
    print(f"   driver: {db_driver}")
    print(f"   host: {db_host}")
    print(f"   port: {db_port}")
    print(f"   database: {db_name}")
    print(f"   username: {db_user}")
except Exception as e:
    print(f"   ❌ Error getting config: {e}")

# 4. Get database URL
print("\n4️⃣ Database URL:")
try:
    db_url = config.get_database_url()
    # Mask password
    import re
    masked_url = re.sub(r'://([^:]+):([^@]+)@', r'://\1:***@', db_url)
    print(f"   {masked_url}")
except Exception as e:
    print(f"   ❌ Error getting database URL: {e}")

# 5. Check defaults.py
print("\n5️⃣ Defaults from defaults.py:")
try:
    from core.defaults import DATABASE_URL as DEFAULT_DB_URL
    import re
    masked_default = re.sub(r'://([^:]+):([^@]+)@', r'://\1:***@', DEFAULT_DB_URL)
    print(f"   {masked_default}")
except Exception as e:
    print(f"   ❌ Error getting default: {e}")

# 6. Check dbconn
print("\n6️⃣ Final URL from dbconn.py:")
try:
    from database.dbconn import DATABASE_URL as FINAL_URL
    import re
    masked_final = re.sub(r'://([^:]+):([^@]+)@', r'://\1:***@', FINAL_URL)
    print(f"   {masked_final}")
except Exception as e:
    print(f"   ❌ Error: {e}")

print("\n" + "=" * 60)
print("✅ Test completato")
print("=" * 60)
