# ⚠️  DEPRECATO: Questo file è stato sostituito da core/config.py
# 
# 🎯 SCOPO: Mantiene solo la compatibilità backward per i fallback nei moduli aggiornati
# 
# 📋 STATO MIGRAZIONE: 
# ✅ Tutti i moduli principali ora usano il sistema centralizzato (core/config.py)
# ✅ Questo file serve solo come fallback di sicurezza nei try/except
# 
# 🔄 PROSSIMI STEP: 
# - Quando tutti i fallback saranno testati, questo file potrà essere rimosso
# - Al momento è necessario per la robustezza del sistema

from pathlib import Path

# Import condizionale per gestire sia environment di sviluppo che container
try:
    from .core.config import get_config, get_data_path, get_api_config
    # Flag per sapere se abbiamo configurazione centralizzata
    HAS_CENTRAL_CONFIG = True
except ImportError:
    # Fallback per ambiente container o standalone
    try:
        from geoapps.core.config import get_config, get_data_path, get_api_config
        HAS_CENTRAL_CONFIG = True
    except ImportError:
        # Fallback definitivo
        HAS_CENTRAL_CONFIG = False
        def get_config(key, default=None):
            return default
        def get_data_path(key):
            return Path(__file__).resolve().parent.parent / "geoapps_storage" / f"{key}.json"
        def get_api_config(key=None):
            return {"url": "https://catalogue.tools4msp.eu/api", "key": "your-api-key-here"}

# Percorsi aggiornati usando configurazione centralizzata
ROOT = Path(__file__).resolve().parent.parent

# Percorsi dati tramite configurazione centralizzata con fallback
if HAS_CENTRAL_CONFIG:
    SCHEMA_PATH = Path(get_data_path("schema"))
    DOMAIN_SIMPL_PATH = Path(get_data_path("domain_simplified"))
    DOMAIN_AREAS_PATH = Path(get_data_path("domain_areas"))
else:
    # Fallback paths
    SCHEMA_PATH = ROOT / "geoapps_storage" / "schema.json"
    DOMAIN_SIMPL_PATH = ROOT / "geoapps_storage" / "domain_areas_simplified.json"
    DOMAIN_AREAS_PATH = ROOT / "geoapps_storage" / "domain_areas.json"

# API Configuration centralizzata
api_config = get_api_config()
API_URL = api_config.get("url", "https://catalogue.tools4msp.eu/api")
API_KEY = api_config.get("key", "your-api-key-here")

# Percorsi dati centralizzati per compatibilità
DATA_PATHS = {
    "schema": SCHEMA_PATH,
    "domain_simplified": DOMAIN_SIMPL_PATH,
    "domain_areas": DOMAIN_AREAS_PATH,
    "storage_root": get_data_path("storage_root") or (ROOT / "geoapps_storage"),
    "parquet_data": get_data_path("parquet_data") or (ROOT / "geoapps_storage" / "remap" / "parquetdata"),
    "static_files": get_data_path("static_files") or (ROOT / "geoapps_storage" / "static")
}



