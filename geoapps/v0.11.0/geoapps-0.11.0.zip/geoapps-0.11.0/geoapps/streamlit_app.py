import streamlit as st
import os
from auth.auth import (
    init_database, 
    is_logged_in, 
    get_current_user, 
    login_form, 
    logout_sidebar,
    get_all_users,
    auto_logout_check,
    get_user_statistics
)# ──────────────────────────────────────────────────────────────
# Page & CSS
# ──────────────────────────────────────────────────────────────
st.set_page_config(page_title="CNR-ISMAR Dashboard", layout="wide")

st.markdown("""
<style>
    .block-container {
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.2rem;
        padding-right: 1.2rem;
    }
    h1, h2, h3, h4, p, .stMarkdown {
        margin-top: 0.25rem !important;
        margin-bottom: 0.35rem !important;
        line-height: 1.2 !important;
    }
    [data-testid="stMetric"] {
        padding-top: 0.25rem !important;
        padding-bottom: 0.25rem !important;
    }
    .stButton > button, .stLinkButton > button {
        padding-top: 0.45rem !important;
        padding-bottom: 0.5rem !important;
        border-radius: 10px !important;
    }
    .element-container, .stColumn {
        padding-top: 0.15rem;
        padding-bottom: 0.15rem;
    }
    img { border-radius: 8px; }

    /* Card più strette e centrate */
    .card-container {
        max-width: 380px;
        margin-left: auto;
        margin-right: auto;
    }
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────────────────────
# Card helper
# ──────────────────────────────────────────────────────────────
def card(
    title: str,
    subtitle: str,
    *,
    accent: str = "#1f77b4",
    image_path: str | None = None,
    button_label: str | None = None,
    button_link: str | None = None,
    key: str | None = None,
):
    """Box con bordo + angoli arrotondati: titolo, sottotitolo, immagine, bottone."""
    clicked = False
    with st.container(border=True):
        st.markdown('<div class="card-container">', unsafe_allow_html=True)

        st.markdown(f'<h3 style="color:{accent}; margin:.2rem 0 .4rem 0;">{title}</h3>', unsafe_allow_html=True)
        if subtitle:
            st.markdown(
                f'<p style="color:#495057; font-size:.95rem; margin:.1rem 0 .6rem 0;">{subtitle}</p>',
                unsafe_allow_html=True,
            )
        if image_path:
            st.image(image_path, use_container_width=True)

        if button_label:
            if button_link:
                st.link_button(button_label, button_link, use_container_width=True)
            else:
                clicked = st.button(button_label, use_container_width=True, key=(key or f"{title}_btn"))

        st.markdown('</div>', unsafe_allow_html=True)
    return clicked

# ──────────────────────────────────────────────────────────────
# Init
# ──────────────────────────────────────────────────────────────
init_database()
auto_logout_check()

if is_logged_in():
    logout_sidebar()
else:
    with st.sidebar:
        login_form()

# ──────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────
st.title("🌍 CNR-ISMAR Data Explorer")

if is_logged_in():
    user_info = get_current_user()
    if user_info:
        st.success(f"Welcome back, **{user_info['full_name']}**! 👋")

        stats = get_user_statistics()
        col_m1, col_m2, col_m3 = st.columns([1, 1, 1])
        with col_m1:
            st.metric("👥 Active Users", f"{stats['active_count']}/{stats['max_users']}")
        with col_m2:
            st.metric("🆓 Available Slots", stats['available_slots'])
        with col_m3:
            st.metric("⏱️ Session Timeout", f"{stats['timeout_minutes']} min")

        st.markdown("---")
        st.markdown("### 🚀 Available Applications")

        # colonne più strette
        left, col_a, spacer, col_b, right = st.columns([0.5, 1, 0.2, 1, 0.5], gap="small")

        with col_a:
            if card(
                title="🌐 CKAN Spatial Explorer",
                subtitle="Full access to spatial datasets with advanced filtering, maps, and analysis tools.",
                accent="#1f77b4",
                image_path="res/ckan_explorer_thumbnail.png",
                button_label="🚀 Launch CKAN Explorer",
                key="ckan_logged",
            ):
                st.switch_page("pages/ckan_spatial.py")

        with col_b:
            card(
                title="📈 ReMAP - MSP out",
                subtitle="Marine Spatial Planning outputs and reporting tools with full member access.",
                accent="#ff7f0e",
                image_path="res/ckan_explorer_thumbnail.png",
                button_label="🚀 Launch ReMAP - MSP out",
                button_link="http://192.168.14.17:8501/ReMAP_MSP_out",
            )

        if user_info['username'] == 'admin':
            st.markdown("---")
            st.markdown("### ⚙️ Admin Panel")
            if st.button("⚙️ Show Admin Panel", use_container_width=True, key="admin_panel"):
                users = get_all_users()
                st.write("### 👥 Registered Users")
                for username, full_name, email, created_at in users:
                    st.write(f"**{username}** - {full_name} ({email}) - Registered: {created_at}")
                st.write("### 🌐 Active Sessions Details")
                for session in stats['active_sessions']:
                    from datetime import datetime
                    login_dt = datetime.fromisoformat(session['login_time'])
                    last_activity_dt = datetime.fromisoformat(session['last_activity'])
                    duration = datetime.now() - login_dt
                    idle_time = datetime.now() - last_activity_dt
                    st.write(f"**{session['username']}** ({session['full_name']})")
                    st.write(f"  • Login: {login_dt.strftime('%H:%M:%S')}")
                    st.write(f"  • Duration: {str(duration).split('.')[0]}")
                    st.write(f"  • Idle: {str(idle_time).split('.')[0]}")
                    st.write("---")

        st.markdown("---")
        st.markdown("### 📖 Available Features")
        st.markdown("""
        - **🌐 CKAN Spatial Explorer**: Explore and filter spatial datasets from CKAN repositories  
        - **📊 Data Analysis**: Advanced data analysis tools (coming soon)  
        - **⚙️ Admin Panel**: User management and system administration
        """)

        if hasattr(st.session_state, 'login_time') and st.session_state.login_time:
            from datetime import datetime
            session_duration = datetime.now() - st.session_state.login_time
            remaining_minutes = stats['timeout_minutes'] - int(session_duration.total_seconds() / 60)
            if remaining_minutes <= 2:
                st.error(f"⚠️ Your session will expire in {remaining_minutes} minutes due to inactivity!")
            elif remaining_minutes <= 5:
                st.warning(f"⏱️ Your session will expire in {remaining_minutes} minutes due to inactivity.")

else:

    stats = get_user_statistics()
    col_m1, col_m2 = st.columns([1, 1])
    with col_m1:
        st.metric("👥 Current Users", f"{stats['active_count']}/{stats['max_users']}")
    with col_m2:
        st.metric("🆓 Available Login Slots", stats['available_slots'])

    with st.expander("📋 Demo Credentials"):
        st.markdown(f"""
        **Sample Login Credentials:**
        - **Admin**: `admin` / `admin123`
        - **Scientist**: `scientist1` / `password123`
        - **Researcher**: `researcher1` / `research789`
        - **Demo**: `demo` / `demo`

        *These are sample credentials for demonstration purposes.*

        **System Limits:**
        - Maximum concurrent users: {stats['max_users']}
        - Session timeout: {stats['timeout_minutes']} minutes of inactivity
        """)

    st.markdown("### 🌐 Public Applications")
    left, col_p1, spacer, col_p2, right = st.columns([0.5, 1, 0.2, 1, 0.5], gap="small")

    with col_p1:
        if card(
            title="🌐 CKAN Spatial Explorer",
            subtitle="Advanced filtering for exploring CKAN Catalogue.",
            accent="#2ca02c",
            image_path="res/ckan_explorer_thumbnail.png",
            button_label="🌐 CKAN Spatial Explorer",
            key="ckan_public",
        ):
            st.switch_page("pages/ckan_spatial.py")

    with col_p2:
        card(
            title="📈 ReMAP - MSP out",
            subtitle="Public access to Marine Spatial Planning outputs and basic reporting tools.",
            accent="#ff7f0e",
            image_path="res/ckan_explorer_thumbnail.png",
            button_label="📈 Access ReMAP Public",
            button_link="http://192.168.14.17:8501/ReMAP_MSP_out",
        )
