# coding: utf-8

import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from math import pi, sqrt
from shapely.ops import polygonize
from upsetplot import from_memberships, plot as upplot, UpSet
from pathlib import Path
from matplotlib.colors import LogNorm, Normalize
from rasterstats import zonal_stats, point_query
# import rectifiedgrid as rg
import pathlib
# from skimage.morphology import skeletonize
from shapely.geometry import LineString, shape
# from skimage.measure import find_contours
from shapely.ops import substring

import warnings
warnings.filterwarnings('ignore')

# from whitebox_workflows import WbEnvironment, download_sample_data
# wbe = WbEnvironment()

map_spid = {
    '2020_background-map_en': 'BEL',
    'FI04001': 'FIN-NB',
    'FI03001': 'FIN-SB',
    'FI01001': 'FIN-GF',
    'FI02001': 'FIN-AI',
    'Jūras plānojums 2030': 'LVA',
    'Juras planojums 2030': 'LVA',
    'POM': 'POL',
    'AWZROV': 'DEU',
    'SE-Östersjön': 'SWE-OS',
    'SE-Västerhavet': 'SWE-VA',
    'SE-Bottniska viken': 'SWE-BO',
    'programma-noordzee-2022-2027-web-toegankelijk': 'NLD',
    'POEM_NOR_2023': 'ESP-NA',
    'POEM_LEBA_2023': 'ESP-LB',
    'POEM_SUD_2023': 'ESP-SA',
    'POEM_CAN_2023': 'ESP-CI',
    'POEM_ESAL_2023': 'ESP-GB',
    'MSP.EE.110001': 'EST',
    'DKMSP': 'DNK',
    'LTMSP': 'LTU',
    'DSF_MED': 'FRA-MD',
    'PGSM_A': 'ITA-AD',
    'PGSM_IMC': 'ITA-IM',
    'PGSM_MO': 'ITA-MO',
}

map_use = {
    'Maritime Traffic flows': 'Traffic',
    'Fishing areas': 'Fishing',
    'Scientific research': 'Research',
    'Tourism and recreation': 'Tourism',
    'Other/miscellaneous': 'Other',
    'Nature Protection Conservation': 'Nature',
    'Military areas': 'Military',
    'Raw material extraction': 'Extraction',
    'Ports': 'Ports',
    'Cables': 'Cables',
    'Pipelines': 'Pipelines',
    'Ocean Energy Facilities': 'Energy',
    'Aquaculture': 'Aquaculture',
    'Cultural heritage': 'Cultural',
    'Wind Farms': 'Wind farms',
    'Undefined': 'Undefined',
    'Oil and Gas': 'Oil & Gas',
    'Disposal areas': 'Disp. areas',
    'Boundaries': 'Boundaries'
}

map_function = {
    'Reserved': 'Res',
    'Priority': 'Pri',
    'Allowed': 'All',
    'Potential': 'Pot',
    'Restricted': 'Rest',
    'Forbidden': 'Forb',
    'Undefined': 'Und'
}


country_codes = {
    'Italy': 'IT',
    'France': 'FR',
    'Belgium': 'BE',
    'Germany': 'DE',
    'Finland': 'FI',
    'Latvia': 'LV',
    'Poland': 'PL',
    'Sweden': 'SE',
    'Netherlands': 'NL',
    'Spain': 'ES',
    'Estonia': 'EE',
    'Denmark': 'DK',
    'Lithuania': 'LT'
}



def non_overlap(_gdf, colname=None, aggfunc=None):
    _nonov = gpd.GeoDataFrame(geometry=list(
        polygonize(_gdf.explode().boundary.unary_union)),
        crs=_gdf.crs
    )
    _nonov = _nonov.clip(_gdf)
    _nonov.geometry = _nonov.geometry.buffer(0)
    _nonov.reset_index(names = 'nonov_id', inplace=True)
    return _nonov[~_nonov.geometry.is_empty]

class Datasets(object):
    # input configuration
    emodnet_msp_file = 'data/EMODnet_HA_MSP_20250124.gdb'
    emodnet_msp_path = Path(emodnet_msp_file)
    emodnet_msp_ze_layer = 'EMODnet_HA_MSP_Zoning_Element_pg_20250124'
    emodnet_msp_plan_layer = 'EMODnet_HA_MSP_Spatial_Plan_20250124'
    wisemarine_ges_files = 'data/MSFD/Article_8*.xlsx'
    mru_file = '/home/menegon/OneDrive_CNR/ISMAR/projects/TEG_MSPData/MSP_MSFD/data/MRU2018_SHP/MarineReportingUnits_MSFD_2018_v2.shp'

    # outputs
    mru_clean_file = 'remap/parquetdata/mru.parquet'
    mru_nonov_file = 'remap/parquetdata/mru_nonov.parquet'
    mru_nonov_file_2024 = 'remap/parquetdata/mru_nonov_2024.parquet'
    ges_file = 'remap/parquetdata/ges.parquet'
    ges_nonov_file = 'remap/parquetdata/ges_nonov.parquet'
    ges_nonov_file_2024 = 'remap/parquetdata/ges_nonov_2024.parquet'
    coverage_file = 'remap/parquetdata/coverage2.parquet'
    coverage_stats_file = 'remap/parquetdata/coverage_stats2.parquet'
    zoning_areas_clean_file = 'remap/parquetdata/zoning_areas_clean2.parquet'
    plans_file = 'remap/parquetdata/spatial_plan_clean2.parquet'
    borders_file = 'remap/parquetdata/borders.parquet'
    aoi_file = 'remap/parquetdata/areas_of_interest.parquet'

    mru_clean_path = Path(mru_clean_file)
    mru_nonov_path = Path(mru_nonov_file)
    mru_nonov_path_2024 = Path(mru_nonov_file_2024)
    ges_path = Path(ges_file)
    ges_nonov_path = Path(ges_nonov_file)
    ges_nonov_path_2024 = Path(ges_nonov_file_2024)
    coverage_path = Path(coverage_file)
    coverage_stats_path = Path(coverage_stats_file)
    zoning_areas_clean_path = Path(zoning_areas_clean_file)
    plans_path = Path(plans_file)
    borders_path = Path(borders_file)
    aoi_path = Path(aoi_file)

    def __init__(self):
        pass

    def get_processes_mss(self):
        if self.plans_path.exists():
            plans = gpd.read_parquet(self.plans_path)
            return plans.MS.unique()
        else:
            return []

    def load_coverage_stats(self):
        if self.coverage_stats_path.exists():
            coverage_stats = pd.read_parquet(self.coverage_stats_path)
        else:
            coverage = self.load_coverage()
            coverage_stats = pd.DataFrame(index=coverage.index)
        return coverage_stats

    def load_borders(self):
        if self.borders_path.exists():
            borders = gpd.read_parquet(self.borders_path)
        else:
            borders = gpd.DataFrame()
        return borders

    def load_mru_nonov(self, year=2018):
        if year==2018:
            _path = self.mru_nonov_path
        elif year==2024:
            _path = self.mru_nonov_path_2024
        if _path.exists():
            mru_nonov = gpd.read_parquet(_path)
        else:
            mru_nonov = gpd.DataFrame()
        return mru_nonov

    def load_ges_nonov(self, filters=None, year=2018):
        if year==2018:
            _path = self.ges_nonov_path
            # _mru_filter = ('MRU', '!=', 'ANS')
            # if filters is None:
            #     filters = _mru_filter
            # else:
            #     filters.append(_mru_filter)
            #     print(filters)
        elif year==2024:
            _path = self.ges_nonov_path_2024
        if _path.exists():
            ges_nonov = pd.read_parquet(_path, filters=filters)
        else:
            ges_nonov = pd.DataFrame()
        return ges_nonov

    def load_aoi(self):
        if self.aoi_path.exists():
            aoi = gpd.read_parquet(self.aoi_path)
        else:
            aoi = gpd.GeoDataFrame()
        return aoi

    def process_aoi(self):
        pelagos = gpd.read_file('data/area_of_interests/Pelagos_Sanctuary_EMODnet_HA_20241204.shp').to_crs(epsg=3035)
        _gdf = pelagos[['geometry']].copy()
        _gdf['label'] = 'Pelagos Sanctuary'
        areas_of_interests = _gdf.copy()

    def process_mru_ges(self, area_m2_threshold=100):
        df_ges = self.load_ges()
        gdf_mru = self.load_mru()

        gdf_mru['geoarea_mru'] = gdf_mru.area / 1000000
        export_cols = ['MarineReportingUnit', 'GESComponent', 'Feature', 'GESAchieved',
                       'Element', 'Element2', 'DescriptionElement', 'ElementStatus',
                       'Parameter', 'ParameterOther',
                       'ThresholdValueUpper', 'ThresholdValueLower', 'ThresholdQualitative', 'ThresholdValueSource',
                       'ValueAchievedUpper', 'ValueAchievedLower', 'ValueUnit', 'ValueUnitOther', 'Trend',
                       'ParameterAchieved', 'Criteria', 'CriteriaStatus',
                       'MS', 'MRU']
        df_ges_small = df_ges.sort_values(['MarineReportingUnit', 'GESComponent', 'Feature', 'Element', 'Parameter'])[
            export_cols]

        gdf_mru_nonov = gpd.GeoDataFrame()
        df_ges_nonov = pd.DataFrame()
        for ms in df_ges_small.MS.unique():
            # for ms in ['Italy', 'Belgium']:
            print("Processing", ms)
            _df = df_ges_small[df_ges_small.MS == ms].copy()
            _gdf = self.merge_ges_mru(_df.drop_duplicates('MRU'), gdf_mru)
            _gdf.geometry = _gdf.geometry.buffer(0)
            nonov_polys = non_overlap(_gdf)
            nonov_polys= nonov_polys[nonov_polys.area > area_m2_threshold]

            gdf_rpoints = nonov_polys.copy()
            gdf_rpoints.geometry = nonov_polys['geometry'].representative_point()

            # rifaccio il _merge con tutte le righe della tabella GES
            _gdf = self.merge_ges_mru(_df, gdf_mru)
            _df = gpd.sjoin(gdf_rpoints, _gdf, how="left", predicate="within")
            _df = _df[export_cols + ['nonov_id', 'geoarea_mru']]
            df_ges_nonov = pd.concat([df_ges_nonov, _df])
            nonov_polys['MS'] = ms
            gdf_mru_nonov = pd.concat([gdf_mru_nonov, nonov_polys])
        df_ges_nonov.to_parquet(self.ges_nonov_path)
        gdf_mru_nonov.to_parquet(self.mru_nonov_path)

    def process_mru_ges_2024(self, area_m2_threshold=100):
        # da generalizzare
        # import reportnet files
        f = 'data/MSFD/2024/DE-ART8_GES.xlsx'
        df_ges = pd.read_excel(f, sheet_name='OverallStatus')
        df_ges['MRU'] = df_ges.MarineReportingUnit
        df_ges['GESachieved'] = df_ges.GESachievedDate
        df_ges['MS'] = 'Germany'
        #
        gdf_mru = gpd.read_file('data/MSFD/2024/MRUs_2024_Germany 1.gpkg')
        gdf_mru.geometry = gdf_mru.simplify(250, preserve_topology=True)
        gdf_mru['thematicId'] = gdf_mru.MarineReportingUnitId

        gdf_mru['geoarea_mru'] = gdf_mru.area / 1000000
        export_cols = ['MarineReportingUnit', 'GESComponent', 'Feature', 'GESAchieved',
                       'Element', 'Element2', 'DescriptionElement', 'ElementStatus',
                       'Parameter', 'ParameterOther',
                       'ThresholdValueUpper', 'ThresholdValueLower', 'ThresholdQualitative', 'ThresholdValueSource',
                       'ValueAchievedUpper', 'ValueAchievedLower', 'ValueUnit', 'ValueUnitOther', 'Trend',
                       'ParameterAchieved', 'Criteria', 'CriteriaStatus',
                       'MS', 'MRU']
        # create missing columns
        for c in export_cols:
            if c not in df_ges.columns:
                df_ges[c] = np.nan

        df_ges_small = df_ges.sort_values(['MarineReportingUnit', 'GESComponent', 'Feature', 'Element', 'Parameter'])[
            export_cols]

        gdf_mru_nonov = gpd.GeoDataFrame()
        df_ges_nonov = pd.DataFrame()
        for ms in df_ges_small.MS.unique():
            # for ms in ['Italy', 'Belgium']:
            print("Processing", ms)
            _df = df_ges_small[df_ges_small.MS == ms].copy()
            _gdf = self.merge_ges_mru(_df.drop_duplicates('MRU'), gdf_mru)
            _gdf.geometry = _gdf.geometry.buffer(0)
            nonov_polys = non_overlap(_gdf)
            nonov_polys= nonov_polys[nonov_polys.area > area_m2_threshold]

            gdf_rpoints = nonov_polys.copy()
            gdf_rpoints.geometry = nonov_polys['geometry'].representative_point()

            # rifaccio il _merge con tutte le righe della tabella GES
            _gdf = self.merge_ges_mru(_df, gdf_mru)
            _df = gpd.sjoin(gdf_rpoints, _gdf, how="left", predicate="within")
            _df = _df[export_cols + ['nonov_id', 'geoarea_mru']]
            df_ges_nonov = pd.concat([df_ges_nonov, _df])
            nonov_polys['MS'] = ms
            gdf_mru_nonov = pd.concat([gdf_mru_nonov, nonov_polys])
        df_ges_nonov.to_parquet(self.ges_nonov_path_2024)
        gdf_mru_nonov.to_parquet(self.mru_nonov_path_2024)

    def load_ges(self):
        if self.ges_path.exists():
            df_ges = pd.read_parquet(self.ges_path)
        else:
            df_ges = pd.DataFrame()
            files = [f for f in pathlib.Path().glob(self.wisemarine_ges_files)]
            for f in files:
                _df = pd.read_excel(f)
                ms = f.stem.split('_')[-1]
                _df['MS'] = ms
                df_ges = pd.concat([df_ges, _df], ignore_index=True)

            df_ges['MRU'] = df_ges.MarineReportingUnit.str.extract('.*\((.*)\).*')[0]
            # cleaning data
            df_ges.GESAchieved.replace('GES achieved', 'GES achieved by 2018')
            df_ges.GESAchieved.replace('GESAchieved', 'GES achieved by 2018')
            df_ges.GESAchieved.replace('GES expected to be achieved later than 2020, no Article 14 exception reported', 'GES not achieved by 2018')
            df_ges.GESAchieved.replace('GES expected to be achieved by 2020', 'GES not achieved by 2018')
            map_ges = {
                'GES achieved': 'GES achieved by 2018',
                'GESAchieved': 'GES achieved by 2018',
                'GES expected to be achieved later than 2020, no Article 14 exception reported': 'GES not achieved by 2018',
                'GES expected to be achieved later than 2020, Article 14 exception reported': 'GES not achieved by 2018',
                'GES expected to be achieved by 2020': 'GES not achieved by 2018',
            }
            df_ges.GESAchieved = df_ges.GESAchieved.replace(map_ges)
            df_ges.to_parquet(self.ges_path)
        return df_ges

    def load_mru(self, simplify_tolerance=1000):
        if self.mru_clean_path.exists():
            gdf_mru = gpd.read_parquet(self.mru_clean_path)
        else:
            print("Creating parquet file")
            cols = ['thematicId', 'nameTxtInt', 'Country', 'geometry', 'spZoneType']
            gdf_mru = gpd.read_file(self.mru_file)[cols].copy()
            countries = country_codes.values()
            gdf_mru = gdf_mru[gdf_mru.Country.isin(countries)].copy()
            print("Reprojecting")
            gdf_mru = gdf_mru.to_crs(epsg=3035)
            print("Buffering")
            gdf_mru.geometry = gdf_mru.buffer(0)
            print("Simplifying")
            gdf_mru.geometry = gdf_mru.geometry.simplify(simplify_tolerance, preserve_topology=True)
            print("Saving")
            gdf_mru.to_parquet(self.mru_clean_path)

        return gdf_mru

    def load_coverage(self):
        if self.coverage_path.exists():
            coverage = gpd.read_parquet(self.coverage_path)
        else:
            coverage = pd.DataFrame()

        # # clean data
        # if 'MS' in coverage.columns:
        #     coverage.MS = coverage.MS.replace('FR', 'France-MED')
        return coverage

    def load_ze(self):
        if self.zoning_areas_clean_path.exists():
            gdf = gpd.read_parquet(self.zoning_areas_clean_path)
        else:
            gdf = pd.DataFrame()

        return gdf

    def load_plans(self):
        if self.plans_path.exists():
            plans = gpd.read_parquet(self.plans_path)
        else:
            plans = pd.DataFrame()
        return plans

    def merge_ges_mru(self, df_ges=None, gdf_mru=None):
        if df_ges is None:
            df_ges = self.load_ges()
        if gdf_mru is None:
            gdf_mru = self.load_mru()

        print("Merging ...")
        gdf_ges = df_ges.merge(gdf_mru, left_on='MRU', right_on='thematicId')

        print("Assiging projection ...")
        return gpd.GeoDataFrame(gdf_ges, geometry='geometry', crs=gdf_mru.crs)



    def process_plans(self, fpath=None, layer=None, mss=None):
        plans = self.load_plans()

        if fpath is None:
            fpath=self.emodnet_msp_path
        if layer is None:
            layer = self.emodnet_msp_plan_layer

        print("Reading source file", fpath)

        plansraw = gpd.read_file(fpath, layer=layer)
        # also to support import from shapefile
        rename_columns = {'LocalID': 'SPID',
                          'Coast_Dist': 'Coast_Dist_M',
                          'Shape_Leng': 'Shape_Length'}
        plansraw.rename(columns=rename_columns, inplace=True)
        plansraw.ValidFrom = plansraw.ValidFrom.astype('datetime64[ns, UTC]')
        plansraw.ValidTo = plansraw.ValidTo.astype('datetime64[ns, UTC]')
        plansraw.BeginLSVer = plansraw.BeginLSVer.astype('datetime64[ns, UTC]')

        if mss is None:
            mss = plansraw.MS.unique()
        for ms, spid in plansraw.loc[plansraw.MS.isin(mss), ['MS', 'SPID']].drop_duplicates().values:
            print("Process plan", ms, spid)
            if 'SPID' in plans.columns and spid in plans.SPID.unique():
                print("SPID Already included, skip")
                continue
            _plans = plansraw[plansraw.SPID == spid].copy().to_crs(epsg=3035)
            print('buffering')
            _plans.geometry = _plans.buffer(0)
            _plans['geoarea'] = _plans.area / 1000000
            plans = pd.concat([plans, _plans], ignore_index=True)
        print("Saving data")
        plans.to_parquet(self.plans_file)


    def process_data(self, fpath=None, layer=None, mss=None):
        gdf = self.load_ze()
        coverage = self.load_coverage()

        if fpath is None:
            fpath=self.emodnet_msp_path
        if layer is None:
            layer = self.emodnet_msp_ze_layer

        print("Reading source file", fpath)
        gdfraw = gpd.read_file(fpath, layer=layer)
        gdfraw.rename(columns={'SeaUseName': 'Sea use',
                               'MS': 'MS',
                               'AreaKm2': 'km2',
                               'SeaUseFct': 'Function'},
                      inplace=True)

        if mss is None:
            mss = gdfraw.MS.unique()

        # process by SPID to avoid memory issues
        for ms, spid in gdfraw.loc[gdfraw.MS.isin(mss), ['MS', 'SPID']].drop_duplicates().values:
            print("Process ze", ms, spid)
            if 'SPID' in gdf.columns and spid in gdf.SPID.unique():
                print("SPID Already included, skip")
                continue

            print("Cleaning geometries / topology")
            _gdf = gdfraw[gdfraw.SPID == spid].copy()
            _gdf.geometry = _gdf.buffer(0)

            _gdf = _gdf.to_crs(epsg=3035).copy()

            # for some geometry we need a couple of buffering
            _invalid_filter = ~_gdf.geometry.is_valid
            _gdf.loc[_invalid_filter, 'geometry'] = _gdf[_invalid_filter].buffer(0)

            print("Create coverage")
            nonov_polys = non_overlap(_gdf)

            print("Get overlay statistics")
            # nonov_polys['use_function'] = (nonov_polys['geometry']
            #                                .representative_point()
            #                                .apply(lambda poly: get_use_function(poly, _gdf)))
            # nonov_polys['category_str'] = nonov_polys.category_list.apply(lambda x: ', '.join(x))
            # nonov_polys[['geometry', 'category_str']].to_file('tmp/gdf_final.shp')
            gdf_rpoints = nonov_polys.copy()
            gdf_rpoints.geometry = nonov_polys['geometry'].representative_point()
            _df = gpd.sjoin(gdf_rpoints, _gdf, how="left", predicate="within")
            _df['use_function'] = list(zip(_df['Sea use'], _df.Function))

            nonov_polys.set_index('nonov_id', inplace=True)
            nonov_polys['use_function'] = _df.groupby('nonov_id').use_function.unique().apply(list)

            print("Calculate area")
            nonov_polys['geoarea'] = nonov_polys.area / 1000000

            _gdf['MS'] = ms
            _gdf['SPID'] = spid
            nonov_polys['MS'] = ms
            nonov_polys['SPID'] = spid
            _gdf = gpd.GeoDataFrame(_gdf, geometry='geometry', crs="EPSG:3035")
            gdf = pd.concat([gdf, _gdf], ignore_index=True)
            nonov_polys = gpd.GeoDataFrame(nonov_polys, geometry='geometry', crs="EPSG:3035")
            coverage = pd.concat([coverage, nonov_polys], ignore_index=True)

        # coverage.MS = coverage.MS.replace('FR', 'France-MED')
        # gdf.MS = gdf.MS.replace('FR', 'France-MED')
        # gdf['Sea use'] = gdf['Sea use'].replace('Aquaculture (include algae)', 'Aquaculture')
        gdf = gpd.GeoDataFrame(gdf, geometry='geometry', crs="EPSG:3035")
        gdf['geoarea'] = gdf.area / 1000000
        gdf.to_parquet(self.zoning_areas_clean_file)

        coverage = gpd.GeoDataFrame(coverage, geometry='geometry', crs="EPSG:3035")
        coverage.to_parquet(self.coverage_file)

    def add_stats(self, name, raster_file, stats=['mean', 'sum'], minarea=None):
        coverage = self.load_coverage()
        _filter = (coverage.index.notna())
        if minarea is not None:
            _filter &= (coverage.area > minarea)
        coverage_stats = self.load_coverage_stats()
        raster = rg.read_raster(raster_file).rio.reproject("epsg: 3035")
        statvals = zonal_stats(coverage[_filter], raster.values, affine=raster.rio.transform(), stats=' '.join(stats))
        for s in stats:
            # init
            coverage_stats[f"{name}_{s}"] = np.nan
            # save values
            coverage_stats.loc[_filter, f"{name}_{s}"] = [a[s] for a in statvals]
        coverage_stats.to_parquet(self.coverage_stats_path)
        return coverage_stats

    def process_borders(self, gdf, buffer_distance=15_000):
        gdf_border = gpd.GeoDataFrame()
        for ms in gdf.MS.unique():
            print(ms)
            _gdf = gdf[gdf.MS == ms].copy()
            _gdf.geometry = _gdf.geometry.simplify(100).buffer(0)
            gdf_b1 = _gdf.copy()
            print("buffer +")
            gdf_b1.geometry = gdf_b1.buffer(buffer_distance)
            print("dissove +")
            gdf_b1_dissolve = gdf_b1.dissolve().reset_index()

            _gdf_border = gdf_b1_dissolve[['MS', 'geometry']].copy()
            _gdf_border.geometry = gdf_b1_dissolve.difference(_gdf.dissolve().reset_index())
            _gdf_border.plot()
            plt.show()
            gdf_border = pd.concat([gdf_border, _gdf_border], ignore_index=True)
            gdf_border.plot()
            plt.show()

        gdf_border.plot(column="MS")
        plt.show()

        boundary_zones = gdf_border.overlay(gdf[['MS', 'geometry']], how="intersection")
        boundary_zones = boundary_zones[boundary_zones.MS_1 != boundary_zones.MS_2]

        boundary_zones_buffer = boundary_zones.copy()
        boundary_zones_buffer.geometry = boundary_zones_buffer.buffer(10000)
        # tolgo duplicati
        boundary_zones_buffer = boundary_zones_buffer.dissolve().explode().reset_index()[['geometry']]

        boundary_zones_buffer.plot()
        plt.show()

        skeleton = vector_skeletonize(boundary_zones_buffer)
        skeleton.to_parquet(self.borders_file)
        return skeleton


def vector_skeletonize(gdf, res=200):
    gdf_skeleton = gpd.GeoDataFrame()
    for idx in gdf.index.unique():
        print("Rasterizing")
        raster =rg.read_df(gdf[gdf.index==idx], res=res)

        print("Skeletonizing - raster")
        _skeleton = skeletonize(raster.values).astype(int)
        _skeleton = np.nan_to_num(_skeleton, nan=0)
        skeleton = raster.copy()
        skeleton.values = _skeleton.astype(float)

        print("Vectorization")
        skeleton.rio.to_raster("/tmp/skeleton.tif")
        r = wbe.read_raster('/tmp/skeleton.tif')
        v = wbe.raster_to_vector_lines(r)
        wbe.write_vector(v, '/tmp/skeleton.shp')
        _gdf_skeleton = gpd.read_file('/tmp/skeleton.shp')
        _gdf_skeleton['orig_index'] = idx
        gdf_skeleton = pd.concat([gdf_skeleton, _gdf_skeleton[['orig_index', 'geometry']]])
    return gdf_skeleton


def get_analysis_sectors(borders, distance=1_000, sector_buffer=30_000):
    sectors = []
    orig_index = []
    for idx, r in borders.iterrows():
        l = r['geometry']
        distances = np.arange(0, l.length, distance)
        if distances[-1] < l.length:
            distances = np.append(distances, l.length)
        for previous, current in zip(distances, distances[1:]):
            ls = substring(l, previous, current)
            sectors.append(ls)
            orig_index.append(idx)

    baselines = (gpd.GeoDataFrame(geometry=sectors, crs=borders.crs)
                 .reset_index())
    baselines['orig_index'] = orig_index
    sectors = baselines.copy()
    sectors.geometry = sectors.buffer(sector_buffer, cap_style="flat")
    return baselines, sectors

#
# datasets = Datasets()
# ze = datasets.load_ze()
#
# buferdist = 15_000
# plans = datasets.load_plans()
# plans_b1 = plans.copy()
# plans_b1.geometry = plans_b1.buffer(buferdist)
# plans_b1_dissolve = plans_b1.dissolve(by="MS").reset_index()
#
# plans_b2 = plans.copy()
# plans_b2.geometry = plans_b1.buffer(-2*buferdist)
# plans_b2_dissolve = plans_b2.dissolve(by="MS").reset_index()
#
# gdf_border = plans_b2_dissolve[['MS', 'geometry']].copy()
# gdf_border.geometry = plans_b1_dissolve.difference(plans_b2_dissolve)
# gdf_border.to_file('/tmp/b.shp')
#
# boundary_zones = gdf_border.overlay(ze[['MS', 'geometry']], how="intersection")
# boundary_zones = boundary_zones[boundary_zones.MS_1 != boundary_zones.MS_2]
# boundary_zones.to_file('/tmp/a.shp')
#
# _boundary_zones = boundary_zones.copy()
# _boundary_zones['MS_border'] = _boundary_zones.apply(lambda row: frozenset([row['MS_1'], row['MS_2']]), axis=1)
# _boundary_zones.geometry = _boundary_zones.buffer(20_000)
# _boundary_zones = _boundary_zones.dissolve(by='MS_border').reset_index()
# _boundary_zones.geometry = _boundary_zones.buffer(-20_000)
# _boundary_zones.plot()
# plt.show()
#
# # _boundary_zones.MS_border = _boundary_zones.MS_border.astype(str)
#
# borders = vector_skeletonize(_boundary_zones)
# borders.geometry = borders.geometry.simplify(1500)
# borders.geometry = borders.geometry.buffer(30_000, cap_style="flat")
#
# contiguous_areas = gpd.GeoDataFrame(
#   geometry=[borders.unary_union]).explode(
#   index_parts=False).reset_index(drop=True)
#
# contiguous_areas = contiguous_areas.reset_index(names="contiguous_area_id")
# contiguous_areas.plot(column="contiguous_area_id")
# contiguous_areas = contiguous_areas.overlay(borders.dissolve(by="orig_index").reset_index(names="orig_index")) #.reset_index(names="orig_index")
# contiguous_areas = contiguous_areas.merge(_boundary_zones[['MS_1', 'MS_2']].reset_index(names='orig_index'), how="left", on=["orig_index"])
# contiguous_areas = gpd.GeoDataFrame(contiguous_areas, geometry='geometry', crs=borders.crs)
# contiguous_areas[['contiguous_area_id', 'orig_index']]
#
# contiguous_areas['label'] = contiguous_areas.MS_1 + ' - ' + contiguous_areas.MS_2
#
# areas_of_interests = pd.concat([areas_of_interests, contiguous_areas[['geometry', 'label']]])
#
# areas_of_interests.to_parquet(datasets.aoi_path)
#
#
# # analisi settori
# # baselines, sectors = get_analysis_sectors(borders.set_index('orig_index'), distance=10_000)
#
#
# # gdf_mru = datasets.load_mru()
# # # gdf_mru.Country.unique()
# #
# # datasets.process_mru_ges(1000)
# # ges_nonov = datasets.load_ges_nonov()[:10000]
# # ges_nonov.reset_index(inplace=True)
# #
# # print("GES (filtered)", ges_nonov.shape)
# # df_filtered = ges_nonov.loc[ges_nonov.index.isin(ges_nonov.groupby(['MS', 'nonov_id'])['geoarea_mru'].idxmin())]
# # print("GES (unique)", df_filtered.shape)
# #
# # import matplotlib.colors as mcolors
# # for i, category in enumerate(np.arange(0, 1.2, 0.2)):
# #     print(f"{category:.1f}")
# # ges_nonov
# #
# # ges_nonov.groupby(['MS', 'nonov_id'])['geoarea_mru'].idxmin().sort_values()
#
# # gdf_mru.plot(alpha=0.2)
# # plt.show()
# # datasets.load_mru_nonov().columns
#
# # datasets.load_ges_nonov()
# # df_ges_duplicated.GESComponent.unique()
# # df_ges.columns
# # c = '(Descriptor) D1 - Biodiversity - fish'
# # f = "Demersal shelf fish"
# # df_filtered = df_ges_duplicated[(df_ges_duplicated.GESComponent==c)&(df_ges_duplicated.Feature==f)]
# # df_filtered = df_filtered.loc[df_filtered.groupby(['MS', 'nonov_id'])['geoarea_mru'].idxmin()]
# # df_ges_duplicated.to_excel('/tmp/a.xlsx')
# # df_merged = gdf_mru_nonov.merge(df_filtered, on=['MS', 'nonov_id'], how='inner')
# # df_merged.plot()
# # plt.show()
# # df_merged[df_merged.area>100].plot()
# # df_merged.area.hist(bins=50, log=True)
# # plt.show()
# # df_merged.GESAchieved.unique()
#
# # Test per vedere se trova tutte le MRU
# # df_ges[~df_ges.MRU.isin(gdf_mru.thematicId)].MRU.unique()
# # gdf_mru[~gdf_mru.thematicId.isin(df_ges.MRU)].thematicId.unique()
# # ['SEA_007', 'D5)']
# # #
# # print(gdf_ges)
#
# # coverage = datasets.load_coverage()
# # ze = datasets.load_ze()
# # ze.columns
# # datasets.process_plans(mss=['Italy', 'Belgium', 'Germany'])
# # datasets.process_data(mss=['Italy', 'Belgium', 'Germany'])
#
# # datasets.process_plans()
# # datasets.process_data()
#
# # # load France
# # datasets.process_plans('data/EMODnet_HA_MSP_20250312_FR.gdb', 'EMODnet_HA_MSP_Spatial_Plan_20250312_FR', mss=['France'])
# # datasets.process_data('data/EMODnet_HA_MSP_20250312_FR.gdb', 'EMODnet_HA_MSP_Zoning_Element_pg_20250312_FR', mss=['France'])
#
# # cargo_file = '/home/menegon/OneDrive_CNR/ISMAR/projects/archive/MBPC-SAIS-EBSA/casestudy/downloaded/EMODnet_HA_Routes_Density_2021/wid6-cargo-all_europe-yearly-20210101000000_20211231235959-tdm-grid.tif'
#
# # datasets.add_stats('cargo', cargo_file)
