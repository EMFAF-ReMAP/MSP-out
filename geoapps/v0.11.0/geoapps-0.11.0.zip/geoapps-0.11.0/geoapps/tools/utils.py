import pandas as pd
import streamlit as st
from time import sleep
from streamlit.runtime.scriptrunner import get_script_run_ctx
import hashlib
import plotly.express as px
import matplotlib.pyplot as plt
import uuid
import os
import plotly.graph_objects as go

# Import default values
try:
    from core.defaults import UTILS_SECRET as DEFAULT_UTILS_SECRET, STATIC_DIR as DEFAULT_STATIC_DIR
except ImportError:
    DEFAULT_UTILS_SECRET = "d201931ffe4698a5a089f3e1380c27b9"
    DEFAULT_STATIC_DIR = "/var/geoapps/geoapps_storage/statics/published/"

# Import condizionale per gestire sia environment di sviluppo che container
try:
    from ..core.config import get_secret
except ImportError:
    # Fallback per ambiente container o standalone
    try:
        from geoapps.core.config import get_secret
    except ImportError:
        # Fallback definitivo se la configurazione non è disponibile
        def get_secret(key, default=None):
            import os
            return os.environ.get(key.upper(), default)

# Secret centralizzato tramite configurazione
secret = get_secret("utils_secret", DEFAULT_UTILS_SECRET)


def hex_to_rgba(hex_color, opacity):
    hex_color = hex_color.lstrip('#')
    r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    return f'rgba({r}, {g}, {b}, {opacity})'

def get_current_page_name():
    """Get current page name - simplified version without deprecated API"""
    try:
        ctx = get_script_run_ctx()
        if ctx is None:
            return "Unknown Page"
        # Fallback to a simple approach since get_pages is deprecated
        return "ReMAP MSP out"
    except Exception:
        return "ReMAP MSP out"


def make_login():
    with st.sidebar:
        if st.session_state.get("logged_in", False):
            st.write("**User:** tools4msp")
            st.write("")

            if st.button("Log out"):
                logout()

        elif get_current_page_name() != "index":
            # If anyone tries to access a secret page without being logged in,
            # redirect them to the login page
            st.switch_page("index.py")

        if not st.session_state.get("logged_in", False):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            
            checksum = hashlib.md5(f"{username}{password}".encode('utf-8')).hexdigest()

            if st.button("Log in", type="primary"):
                if checksum == secret:
                    st.session_state.logged_in = True
                    st.success("Logged in successfully!")
                    sleep(1)
                    st.switch_page("index.py")
                else:
                    st.error("Incorrect username or password")

        st.divider()

def make_header():
    """
    Create a consistent header with logo, logout, and navigation for all pages.
    """
    from auth.auth import is_logged_in, get_current_user, logout_user
    
    # Hide default Streamlit navigation
    st.markdown("""
        <style>
            /* Hide the default Streamlit navigation */
            [data-testid="stSidebarNav"] {
                display: none;
            }
        </style>
    """, unsafe_allow_html=True)
    
    with st.sidebar:
        col1, col2 = st.columns([2, 9])

        with col1:
            st.image("https://catalogue.tools4msp.eu/logo.png")
            
        with col2:
            st.write("# Tools4MSP GeoApps")
        
        
        # Apps menu if logged in
        if is_logged_in():
            st.write("### Apps")
            st.page_link("streamlit_app_demo.py", label="🏠 Home")
            st.page_link("pages/ReMAP_MSP_out.py", label="📈 ReMAP - MSP out")
            st.page_link("pages/ReMAP_MSP_MSFD.py", label="📊 ReMAP - MSP & MSFD")
            st.page_link("pages/CKAN_Explorer.py", label="🗺️ CKAN Explorer")
            
            
            # Logout button at the end
            if st.button("🚪 Logout", use_container_width=True, key="logout_header"):
                logout_user()
                st.rerun()
        
        st.divider()



def logout():
    st.session_state.logged_in = False
    st.info("Logged out successfully!")
    sleep(0.5)
    st.switch_page("index.py")


def set_sankey_data(df, columns, valcol, colorscale=px.colors.qualitative.Set3, flow_mode='source', color_map=None, opacity=0.6):
    __df = df.groupby(columns).geoarea.sum().to_frame().reset_index()
    # st.write("sankey flows", __df.shape)
    _labels = pd.Series()
    # overwrite column value to avoid overlap: vengono aggiunti degli spazi
    for i, c in enumerate(columns):
        __df[c] = __df[c] + ' '*i
        _labels = pd.concat([_labels, __df[c]])  
    labels = list(_labels.unique())

    # Creazione di un dizionario per mappare le etichette agli indici
    label_index = {label: index for index, label in enumerate(labels)}

    # Creazione delle liste per le origini, destinazioni e valori
    sources = []
    targets = []
    values = []
    link_colors = []
    sourceinfo = []

    if flow_mode == 'source':
        colorcol = columns[0]
    elif flow_mode == 'dest':
        colorcol = columns[-1]
    if color_map is None:
        _color_map = {origin: colorscale[i % len(colorscale)] for i, origin in enumerate(__df[colorcol].str.strip().unique())}
    else:
        # colone per evitare
        _color_map = color_map.copy()
        # add opacity
        for k, v in _color_map.items():
            _color_map[k] = hex_to_rgba(v, opacity)
    # per ciascuna colonna aggiuntiva creo i link considerando il colore dalla prima colonna
    sourcecol = columns[0]
    groupcols = [sourcecol]
    for i, c in enumerate(columns[1:]):
        targetcol = c
        groupcols += [targetcol]
    
        # Riempimento delle liste con i dati del DataFrame
        for _, row in __df.groupby(columns).sum(valcol).reset_index().sort_values(groupcols).iterrows():
            print("########", row)
            sources.append(label_index[row[sourcecol]])  # Indice della sorgente
            targets.append(label_index[row[targetcol]])      # Indice della destinazione
            values.append(row[valcol])                        # Valore per lo spessore
            link_colors.append(_color_map.get(row[colorcol].strip(), '#000000'))
            sourceinfo.append(row[columns[0]])
                
        sourcecol = targetcol
    return labels, sources, targets, values, link_colors, sourceinfo


# Use default value for STATIC_DIR
STATIC_DIR = DEFAULT_STATIC_DIR


def public_plotly_result(fig, prefix='plot'):
    token = str(uuid.uuid4())[:15]
    filename = f"{prefix}_{token}.html"
    filepath = os.path.join(STATIC_DIR, filename)
    
    # salva il grafico come HTML statico
    fig.write_html(filepath, include_plotlyjs="cdn")
        
    # crea URL relativo (se Streamlit serve static/)
    file_url = f"https://statics.geoapps.tools4msp.eu/published/{filename}"
        
    st.success(f"Chart saved as `{filename}` ✅")
    st.markdown(f"[🔗 Open chart ]({file_url})")
        
    # embed diretto nel layout
    st.components.v1.html(
        f'<iframe src="{file_url}" width="100%" height="500" frameborder="0"></iframe>',
        height=520,
    )

def publish_result(fig, prefix='plot'):
    token = str(uuid.uuid4())[:15]

    if isinstance(fig, go.Figure):
        filename = f"{prefix}_{token}.html"
        filepath = os.path.join(STATIC_DIR, filename)
        fig.write_html(filepath, include_plotlyjs="cdn")
    elif hasattr(fig, "savefig"):
        filename = f"{prefix}_{token}.png"
        filepath = os.path.join(STATIC_DIR, filename)
        fig.savefig(filepath, bbox_inches="tight")
        plt.close(fig)

    file_url = f"https://statics.geoapps.tools4msp.eu/published/{filename}"
        
    st.success(f"Chart saved as `{filename}` ✅")
    st.markdown(f"[🔗 Open chart ]({file_url})")
        
    st.components.v1.html(
        f'<iframe src="{file_url}" width="100%" height="500" frameborder="0"></iframe>',
        height=520,
    )

# verifica se la pagina è caricata per la prima volta oppure se è
# stata aperta dopo essere arrivati da un'altra pagina
def check_pageload(page_name: str):
    current_page = page_name
    prev_page = st.session_state.get("_current_page")

    # se è una pagina nuova, resetta lo stato
    if prev_page != current_page:
        st.session_state["_current_page"] = current_page
        return True
    return False
