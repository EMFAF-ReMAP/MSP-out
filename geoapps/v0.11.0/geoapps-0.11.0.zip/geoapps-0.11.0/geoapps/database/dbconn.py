from sqlalchemy import create_engine, text, select
import pandas as pd
import geopandas as gpd

# Import defaults first
try:
    from ..core.defaults import DATABASE_URL as DEFAULT_DATABASE_URL
except ImportError:
    try:
        from geoapps.core.defaults import DATABASE_URL as DEFAULT_DATABASE_URL
    except ImportError:
        DEFAULT_DATABASE_URL = "postgresql://remap:remap@172.17.0.1:5432/remap"

# Database URL configuration with proper priority
import os
import sys

def _get_database_url():
    """Get database URL with proper priority: ConfigManager → env var → defaults"""
    # Priority 1: Try ConfigManager (respects GEOAPPS_ENV from config.yaml)
    try:
        # Try relative import first (works in package context)
        try:
            from ..core.config import get_database_url
        except (ImportError, ValueError):
            # Fallback to absolute import
            from geoapps.core.config import get_database_url
        
        url = get_database_url()
        if url and "None" not in str(url):
            sys.stderr.write(f"✅ [dbconn.py] Got URL from ConfigManager: {url.replace('remap:remap', 'remap:***')}\n")
            sys.stderr.flush()
            return url
    except Exception as e:
        sys.stderr.write(f"⚠️ [dbconn.py] ConfigManager unavailable: {e}\n")
        sys.stderr.flush()
    
    # Priority 2: Environment variable override (optional, for special cases)
    env_url = os.getenv("DATABASE_URL")
    if env_url:
        sys.stderr.write(f"✅ [dbconn.py] Got DATABASE_URL from environment variable\n")
        sys.stderr.flush()
        return env_url
    
    # Priority 3: Fallback to defaults.py
    sys.stderr.write(f"⚠️ [dbconn.py] Using fallback DEFAULT_DATABASE_URL\n")
    sys.stderr.flush()
    return DEFAULT_DATABASE_URL

# Get DATABASE_URL
DATABASE_URL = _get_database_url()

# Store URL but don't create engine yet (lazy initialization)
_DATABASE_URL = DATABASE_URL

# Log final URL for debugging (mask password)
import re
masked_url = re.sub(r'://([^:]+):([^@]+)@', r'://\1:***@', str(_DATABASE_URL))
sys.stderr.write(f"🔧 [dbconn.py] Will use DATABASE_URL: {masked_url}\n")
sys.stderr.flush()

# Lazy initialization of engine
_engine = None

def get_engine():
    """Get database engine with lazy initialization"""
    global _engine
    if _engine is None:
        sys.stderr.write(f"🔧 [dbconn.py] Creating SQLAlchemy engine...\n")
        sys.stderr.flush()
        _engine = create_engine(_DATABASE_URL)
    return _engine

# For backward compatibility
engine = property(lambda self: get_engine())

# But also create it immediately for modules that expect it
engine = get_engine()

# Legacy: mantengo le vecchie stringhe commentate per riferimento
#engine = create_engine("postgresql://remap:remap@localhost:5432/remap")
#engine = create_engine("postgresql://remap:remap@host.docker.internal:5436/remap")


from sqlalchemy import Column, BigInteger, Text, Index
from sqlalchemy.ext.declarative import declarative_base
from geoalchemy2 import Geometry

from typing import Optional
from sqlalchemy import BigInteger, Text, Index, Float, DateTime, Double, Integer, Boolean
from sqlalchemy.sql.functions import Function
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from geoalchemy2 import Geometry, functions as geofunc
from sqlalchemy.orm import Session


class Base(DeclarativeBase):
        pass


class ZoningAreasMRUNonv2024(Base):
    __tablename__ = "zoning_areas_mru_nonov_2024"
    
    zoning_areas_index = Column(Integer, primary_key=True)
    mru_nonov_id = Column(Integer, primary_key=True)
    MS = Column(Text)
    geometry = Column(Geometry(geometry_type="GEOMETRY", srid=3035))

class ZoningAreasMRUNonv(Base):
    __tablename__ = "zoning_areas_mru_nonov"
    
    zoning_areas_index = Column(Integer, primary_key=True)
    mru_nonov_id = Column(Integer, primary_key=True)
    MS = Column(Text)
    geometry = Column(Geometry(geometry_type="GEOMETRY", srid=3035))

                    
class Coverage(Base):
    __tablename__ = "coverage"
    __table_args__ = {"schema": "public"}

    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    geometry: Mapped[str | None] = mapped_column(Geometry("MULTIPOLYGON", 3035))
    use_function: Mapped[str | None] = mapped_column(Text)
    geoarea: Mapped[float | None] = mapped_column(Float)
    MS: Mapped[str | None] = mapped_column(Text)
    SPID: Mapped[str | None] = mapped_column(Text)

                                        
class CoverageNoBoundaries(Base):
    __tablename__ = "coverage_noboundaries"
    __table_args__ = {"schema": "public"}
    
    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    MS: Mapped[str | None] = mapped_column(Text)
    SPID: Mapped[str | None] = mapped_column(Text)
    geoarea: Mapped[float | None] = mapped_column(Float)
    use_function: Mapped[str | None] = mapped_column(Text)
    geometry: Mapped[str | None] = mapped_column(Geometry("MULTIPOLYGON", 3035))
    Sea_use: Mapped[str | None] = mapped_column("Sea use", Text)  # colonna con spazio
    Function: Mapped[str | None] = mapped_column(Text)


class CoverageUF(Base):
    __tablename__ = "coverage_uf"
    __table_args__ = {"schema": "public"}
    
    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    MS: Mapped[str | None] = mapped_column(Text)
    SPID: Mapped[str | None] = mapped_column(Text)
    geoarea: Mapped[float | None] = mapped_column(Float)
    use_function: Mapped[str | None] = mapped_column(Text)
    geometry: Mapped[str | None] = mapped_column(Geometry("MULTIPOLYGON", 3035))
    Sea_use: Mapped[str | None] = mapped_column("Sea use", Text)  # colonna con spazio
    Function: Mapped[str | None] = mapped_column(Text)


class AreasOfInterest(Base):
    __tablename__ = "areas_of_interest"

    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    geometry: Mapped[Optional[str]] = mapped_column(Geometry("MULTIPOLYGON", srid=3035))
    label: Mapped[Optional[str]] = mapped_column(Text)


class ZoningAreas(Base):
    __tablename__ = "zoning_areas"

    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    LocalID: Mapped[str | None] = mapped_column(Text)
    VersionID: Mapped[str | None] = mapped_column(Text)
    OffSource: Mapped[str | None] = mapped_column(Text)
    MS: Mapped[str | None] = mapped_column(Text)
    HilucLU: Mapped[str | None] = mapped_column(Text)
    HilucsMSP: Mapped[str | None] = mapped_column(Text)
    Sea_use: Mapped[str | None] = mapped_column("Sea use", Text)  # nome con spazio
    Function: Mapped[str | None] = mapped_column(Text)
    SeaUseDsc: Mapped[str | None] = mapped_column(Text)
    OriginUN: Mapped[str | None] = mapped_column(Text)
    OriginUNEn: Mapped[str | None] = mapped_column(Text)
    RegNature: Mapped[str | None] = mapped_column(Text)
    VertDistr: Mapped[str | None] = mapped_column(Text)
    ProcStepG: Mapped[str | None] = mapped_column(Text)
    hilucsPres: Mapped[int | None] = mapped_column(BigInteger)
    SpecLanUs: Mapped[str | None] = mapped_column(Text)
    SpecPres: Mapped[str | None] = mapped_column(Text)
    BackgMap: Mapped[str | None] = mapped_column(Text)
    ValidFrom: Mapped[str | None] = mapped_column(Text)
    ValidTo: Mapped[str | None] = mapped_column(Text)
    PrevMSPPla: Mapped[str | None] = mapped_column(Text)
    BeginLSVer: Mapped[str | None] = mapped_column(Text)
    EndLSVer: Mapped[str | None] = mapped_column(Text)
    DimInd: Mapped[str | None] = mapped_column(Text)
    SPID: Mapped[str | None] = mapped_column(Text)
    OffDoc: Mapped[str | None] = mapped_column(Text)
    Coast_Dist_M: Mapped[float | None] = mapped_column(Float)
    km2: Mapped[float | None] = mapped_column(Float)
    Shape_Length: Mapped[float | None] = mapped_column(Float)
    Shape_Area: Mapped[float | None] = mapped_column(Float)
    geometry: Mapped[str | None] = mapped_column(Geometry("MULTIPOLYGON", 3035))
    Coast_Dist: Mapped[float | None] = mapped_column(Float)
    geoarea: Mapped[float | None] = mapped_column(Float)
    Shape_Leng: Mapped[float | None] = mapped_column(Float)
    OBJECTID: Mapped[float | None] = mapped_column(Float)
    ms_1: Mapped[str | None] = mapped_column(Text)
    zoneVocati: Mapped[float | None] = mapped_column(Float)
    layer: Mapped[str | None] = mapped_column(Text)
    path: Mapped[str | None] = mapped_column(Text)


class Plans(Base):
    __tablename__ = "plans"

    index: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    SPID: Mapped[str | None] = mapped_column(Text)
    VersionID: Mapped[str | None] = mapped_column(Text)
    OffSource: Mapped[str | None] = mapped_column(Text)
    MS: Mapped[str | None] = mapped_column(Text)
    OffTitle: Mapped[str | None] = mapped_column(Text)
    LevelSpPla: Mapped[str | None] = mapped_column(Text)
    PlanTyNam: Mapped[str | None] = mapped_column(Text)
    ProcStepG: Mapped[str | None] = mapped_column(Text)
    BackgMap: Mapped[str | None] = mapped_column(Text)
    Ordinance: Mapped[str | None] = mapped_column(Text)
    ValidFrom: Mapped[str | None] = mapped_column(DateTime(timezone=True))
    ValidTo: Mapped[str | None] = mapped_column(DateTime(timezone=True))
    AltTitle: Mapped[str | None] = mapped_column(Text)
    BeginLSVer: Mapped[str | None] = mapped_column(DateTime(timezone=True))
    EndLSVer: Mapped[str | None] = mapped_column(Text)
    OffDoc: Mapped[str | None] = mapped_column(Text)
    Coast_Dist_M: Mapped[float | None] = mapped_column(Float)
    AreaKm2: Mapped[float | None] = mapped_column(Float)
    Shape_Length: Mapped[float | None] = mapped_column(Float)
    Shape_Area: Mapped[float | None] = mapped_column(Float)
    geometry: Mapped[str | None] = mapped_column(Geometry("MULTIPOLYGON", 3035))
    geoarea: Mapped[float | None] = mapped_column(Float)
    geoarea_noboundaries: Mapped[float | None] = mapped_column(Float)
    geoarea_coverage: Mapped[float | None] = mapped_column(Float)
    Coast_Dist: Mapped[float | None] = mapped_column(Float)
    layer: Mapped[str | None] = mapped_column(Text)
    path: Mapped[str | None] = mapped_column(Text)
    SPID_ORIG: Mapped[str | None] = mapped_column(Text)


class GES(Base):
    __tablename__ = "ges"

    index = Column(BigInteger, primary_key=True, index=True)
    Id = Column(BigInteger)
    MarineReportingUnit = Column(Text)
    GESComponent = Column(Text)
    Feature = Column(Text)
    GESExtentUnit = Column(Text)
    GESAchieved = Column(Text)
    AssessmentsPeriod = Column(Text)
    DescriptionOverallStatus = Column(Text)
    IntegrationRuleTypeCriteria = Column(Text)
    IntegrationRuleDescriptionCriteria = Column(Text)
    IntegrationRuleDescriptionReferenceCriteria = Column(Text)
    IntegrationRuleTypeParameter = Column(Text)
    IntegrationRuleDescriptionParameter = Column(Text)
    IntegrationRuleDescriptionReferenceParameter = Column(Text)
    PressureCode = Column(Text)
    TargetCode = Column(Text)
    Element = Column(Text)
    Element2 = Column(Text)
    ElementSource = Column(Text)
    ElementCode = Column(Text)
    Element2Code = Column(Text)
    ElementCodeSource = Column(Text)
    Element2CodeSource = Column(Text)
    DescriptionElement = Column(Text)
    ElementStatus = Column(Text)
    Criteria = Column(Text)
    CriteriaStatus = Column(Text)
    DescriptionCriteria = Column(Text)
    IdOverallStatus = Column(Float)
    Parameter = Column(Text)
    ParameterOther = Column(Text)
    ThresholdValueUpper = Column(Float)
    ThresholdValueLower = Column(Float)
    ThresholdQualitative = Column(Text)
    ThresholdValueSource = Column(Text)
    ThresholdValueSourceOther = Column(Text)
    ValueAchievedUpper = Column(Float)
    ValueAchievedLower = Column(Float)
    ValueUnit = Column(Text)
    ValueUnitOther = Column(Text)
    ProportionThresholdValue = Column(Float)
    ProportionThresholdValueUnit = Column(Text)
    ProportionValueAchieved = Column(Float)
    Trend = Column(Text)
    ParameterAchieved = Column(Text)
    DescriptionParameter = Column(Text)
    IndicatorCode = Column(Text)
    MS = Column(Text)
    MRU = Column(Text)


class MRUNonov(Base):
    __tablename__ = "mru_nonov"

    index = Column(BigInteger, primary_key=True, index=True)
    nonov_id = Column(BigInteger)
    geometry = Column(Geometry(geometry_type="MULTIPOLYGON", srid=3035))
    MS = Column(Text)

class MRUNonov2024(Base):
    __tablename__ = "mru_nonov_2024"

    index = Column(BigInteger, primary_key=True, index=True)
    nonov_id = Column(BigInteger)
    geometry = Column(Geometry(geometry_type="MULTIPOLYGON", srid=3035))
    MS = Column(Text)

class GESNonov(Base):
    __tablename__ = "ges_nonov"

    index = Column(BigInteger, primary_key=True, index=True)
    MarineReportingUnit = Column(Text)
    GESComponent = Column(Text)
    Feature = Column(Text)
    GESAchieved = Column(Text)
    Element = Column(Text)
    Element2 = Column(Text)
    DescriptionElement = Column(Text)
    ElementStatus = Column(Text)
    Parameter = Column(Text)
    ParameterOther = Column(Text)
    ThresholdValueUpper = Column(Float)
    ThresholdValueLower = Column(Float)
    ThresholdQualitative = Column(Text)
    ThresholdValueSource = Column(Text)
    ValueAchievedUpper = Column(Float)
    ValueAchievedLower = Column(Float)
    ValueUnit = Column(Text)
    ValueUnitOther = Column(Text)
    Trend = Column(Text)
    ParameterAchieved = Column(Text)
    Criteria = Column(Text)
    CriteriaStatus = Column(Text)
    MS = Column(Text)
    MRU = Column(Text)
    nonov_id = Column(BigInteger)
    geoarea_mru = Column(Float)

    # FeatureDistinct = Column(Boolean, default=False)
    # ElementDistinct = Column(Boolean, default=False)
    # ParameterDistinct = Column(Boolean, default=False)
    # CriteriaDistinct = Column(Boolean, default=False)
                                                                    

class GESNonov2024(Base):
    __tablename__ = "ges_nonov_2024"

    index = Column(BigInteger, primary_key=True)
    MRU = Column(Text)
    GESComponent = Column(Text)
    Feature = Column(Text)
    Element = Column(Text)
    Element2 = Column(Text)
    ElementStatus = Column(Text)
    DescriptionElement = Column(Text)
    MarineReportingUnit = Column(Text)
    GESAchieved = Column(Text)
    Parameter = Column(Float)
    ParameterOther = Column(Float)
    ThresholdValueUpper = Column(Float)
    ThresholdValueLower = Column(Float)
    ThresholdQualitative = Column(Float)
    ThresholdValueSource = Column(Float)
    ValueAchievedUpper = Column(Float)
    ValueAchievedLower = Column(Float)
    ValueUnit = Column(Float)
    ValueUnitOther = Column(Float)
    Trend = Column(Float)
    ParameterAchieved = Column(Float)
    Criteria = Column(Float)
    CriteriaStatus = Column(Float)
    MS = Column(Text)
    nonov_id = Column(Float)
    geoarea_mru = Column(Float)

    # FeatureDistinct = Column(Boolean, default=False)
    # ElementDistinct = Column(Boolean, default=False)
    # ParameterDistinct = Column(Boolean, default=False)
    # CriteriaDistinct = Column(Boolean, default=False)
    

from typing import Any, Dict, Optional, Callable
from sqlalchemy import select, func
from sqlalchemy.orm import Session
import pandas as pd
import geopandas as gpd
from sqlalchemy import and_, or_, not_

def add_where(stmt, model, filters):
    clauses = []
    for col_name, value in filters.items():
        print(model, col_name, value)
        if col_name == 'ST_intersects':
            col = getattr(model, "geometry", None)
        else:
            col = getattr(model, col_name, None)
        print(col)
        if col is not None:
            if isinstance(value, list):
                clauses.append(col.in_(value))
            elif col_name == 'ST_intersects':
                clauses.append(geofunc.ST_Intersects(col, value))
            else:
                clauses.append(col == value)
    where_clause = and_(*clauses) if clauses else None
    if where_clause is not None:
        stmt = stmt.where(where_clause)
    return stmt

                                            
class QueryManager:
    _queries: Dict[str, Callable[[Dict[str, Any]], Any]] = {}
    _filters = {}

    def __init__(self, engine, geom_col: str = "geometry"):
        self.engine = engine
        self.geom_col = geom_col

    @classmethod
    def register_query(cls, name: str):
        """Decorator per registrare una query predefinita"""
        
        def decorator(func: Callable[[Dict[str, Any]], Any]):
            cls._queries[name] = func
            return func

        return decorator

    def set_filter(self, col, val):
        self._filters[col] = val

    def get_query(self, name, filters):
        if name not in self._queries:
            raise ValueError(f"Query '{name}' non registrata")
        stmt_func = self._queries[name]
        return stmt_func(filters or self._filters)

    def read(self, stmt, mode="df", index_col=None):
        if mode == "gdf":
            return gpd.read_postgis(stmt, self.engine, geom_col=self.geom_col, index_col=index_col)
        elif mode == "df":
            return pd.read_sql(stmt, self.engine, index_col=index_col)
        elif mode == "list":
            with Session(self.engine) as session:
                return session.scalars(stmt).all()
        else:
            raise ValueError("Il nome della query deve iniziare con 'list_', 'df_' o 'gdf_'")

    def run(self, name: str, filters: Optional[Dict[str, Any]] = None, mode="df", index_col=None) -> Any:
        stmt = self.get_query(name, filters)
        return self.read(stmt, mode, index_col)


@QueryManager.register_query("aois")
def q_aois(filters):
    stmt = select(AreasOfInterest.label).order_by(AreasOfInterest.label)
    stmt = add_where(stmt, AreasOfInterest, filters)
    return stmt

@QueryManager.register_query("aoisgeo")
def q_aois(filters):
    stmt = select(AreasOfInterest.index, AreasOfInterest.label, AreasOfInterest.geometry)
    stmt = add_where(stmt, AreasOfInterest, filters)
    return stmt

@QueryManager.register_query("ze_distinct")
def q_ze_distinct(filters):
    stmt = select(ZoningAreas.index, ZoningAreas.MS, ZoningAreas.SPID, ZoningAreas.Sea_use, ZoningAreas.Function)
    stmt = add_where(stmt, ZoningAreas, filters)
    stmt = stmt.distinct(ZoningAreas.MS, ZoningAreas.SPID, ZoningAreas.Sea_use, ZoningAreas.Function)
    return stmt

@QueryManager.register_query("ze")
def q_ze(filters):
    stmt = select(ZoningAreas.index, ZoningAreas.MS, ZoningAreas.SPID, ZoningAreas.Sea_use, ZoningAreas.Function, ZoningAreas.geoarea)
    stmt = add_where(stmt, ZoningAreas, filters)
    return stmt

@QueryManager.register_query("ze_geo")
def q_ze_geo(filters):
    stmt = select(ZoningAreas.index, ZoningAreas.MS, ZoningAreas.SPID, ZoningAreas.Sea_use, ZoningAreas.Function, ZoningAreas.geometry)
    stmt = add_where(stmt, ZoningAreas, filters)
    return stmt

@QueryManager.register_query("ze_count")
def q_ze_count(filters):
    stmt = select(ZoningAreas.index, ZoningAreas.MS, ZoningAreas.SPID, ZoningAreas.Sea_use, ZoningAreas.Function, ZoningAreas.geoarea)
    stmt = add_where(stmt, ZoningAreas, filters)
    return stmt

@QueryManager.register_query("plans")
def q_plans(filters):
    stmt = select(Plans.index, Plans.MS, Plans.SPID, Plans.OffTitle)
    stmt = add_where(stmt, Plans, filters)
    return stmt

@QueryManager.register_query("ges_distinct")
def q_ges_distinct(filters):
    stmt = select(GES.index, GES.MS, GES.GESComponent, GES.Feature, GES.Element, GES.Criteria, GES.Parameter)
    stmt = add_where(stmt, ZoningAreas, filters)
    stmt = stmt.distinct(GES.MS, GES.GESComponent, GES.Feature, GES.Element, GES.Criteria, GES.Parameter)
    return stmt

@QueryManager.register_query("ges_2024_distinct")
def q_ges_2024_distinct(filters):
    stmt = select(GESNonov2024.index, GESNonov2024.MS, GESNonov2024.GESComponent, GESNonov2024.Feature, GESNonov2024.Element, GESNonov2024.Criteria, GESNonov2024.Parameter)
    stmt = add_where(stmt, ZoningAreas, filters)
    stmt = stmt.distinct(GESNonov2024.MS, GESNonov2024.GESComponent, GESNonov2024.Feature, GESNonov2024.Element, GESNonov2024.Criteria, GESNonov2024.Parameter)
    return stmt


# qm = QueryManager(engine)

# print(getattr(ZoningAreas, "MS", None))

# qm.set_filter('MS', 'Italy')

# stmt = select(ZoningAreas.MS, func.count().label("count")).group_by(ZoningAreas.MS)
# stmt = add_where(stmt, "ZoningAreas", qm._filters)

# print(qm.read(stmt, 'df', 'MS'))

# # GeoDataFrame filtrato
# gdf = qm.run("aois")
# print(gdf)

# df = qm.run("df_aois")
# print(df)

# # Lista
# labels = qm.run("list_labels")
# print(labels)

                        
# sqlqueries = {
#     'ze': 'select distinct "MS", "SPID", "Sea use", "Function" from zoning_areas'
#     # 'aois': 
#     }

# def db_select(query):
#     sql = sqlqueries.get(query)
#     if query.startswith("geo"):
#         return gpd.read_postgis(sql, engine, geom_col="geometry")
#     return pd.read_sql(sql, con=engine)

