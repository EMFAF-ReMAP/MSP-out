# 🔐 Role-Based Access Control (RBAC) Guide

Sistema di controllo accessi basato su ruoli e permessi per GeoApps.

---

## 📋 Indice

1. [Overview](#overview)
2. [Ruoli Disponibili](#ruoli-disponibili)
3. [Permessi Disponibili](#permessi-disponibili)
4. [Come Usare nelle Pagine](#come-usare-nelle-pagine)
5. [Pattern Comuni](#pattern-comuni)
6. [Esempi Pratici](#esempi-pratici)
7. [Migrazione Futura](#migrazione-futura)

---

## Overview

Il sistema RBAC consente di:
- **Identificare il ruolo** dell'utente corrente
- **Verificare i permessi** prima di eseguire operazioni
- **Mostrare/nascondere elementi UI** in base ai permessi
- **Bloccare l'esecuzione** di pagine/funzioni protette

### Come Funziona

1. **Inferenza del ruolo dal username** (temporaneo):
   - `admin` → `UserRole.ADMIN`
   - `scientist1`, `scientist2` → `UserRole.SCIENTIST`
   - `researcher1`, `researcher2` → `UserRole.RESEARCHER`
   - `analyst1`, `analyst2` → `UserRole.ANALYST`
   - `guest1`, `guest2` → `UserRole.GUEST`
   - `demo`, `demo1-5` → `UserRole.DEMO`

2. **Mapping ruoli → permessi**:
   - Ogni ruolo ha un set di permessi predefinito
   - I permessi vengono verificati al runtime

---

## Ruoli Disponibili

### 👑 ADMIN (Administrator)
**Username:** `admin`

**Permessi:**
- ✅ Tutti i permessi disponibili
- Pubblicazione diretta senza approvazione
- Gestione utenti e configurazione sistema

**Casi d'uso:**
- Amministratori di sistema
- Super user con accesso completo

---

### 🔬 SCIENTIST (Scientist)
**Username pattern:** `scientist*`

**Permessi:**
- ✅ VIEW_DATA - Visualizzare dati
- ✅ DOWNLOAD_DATA - Scaricare dati
- ✅ UPLOAD_DATA - Caricare nuovi dati
- ✅ PUBLISH_REQUEST - Richiedere pubblicazione (con approvazione admin)

**Casi d'uso:**
- Ricercatori scientifici
- Personale che produce e analizza dati

---

### 🔍 RESEARCHER (Researcher)
**Username pattern:** `researcher*`

**Permessi:**
- ✅ VIEW_DATA
- ✅ DOWNLOAD_DATA
- ✅ UPLOAD_DATA
- ✅ PUBLISH_REQUEST

**Casi d'uso:**
- Ricercatori
- Collaboratori scientifici

---

### 📊 ANALYST (Analyst)
**Username pattern:** `analyst*`

**Permessi:**
- ✅ VIEW_DATA
- ✅ DOWNLOAD_DATA
- ✅ PUBLISH_REQUEST

**Casi d'uso:**
- Analisti che lavorano con i dati
- Personale che non produce dati ma li analizza

---

### 👤 GUEST (Guest)
**Username pattern:** `guest*`

**Permessi:**
- ✅ VIEW_DATA
- ✅ DOWNLOAD_DATA

**Casi d'uso:**
- Utenti esterni
- Collaboratori temporanei
- Consultazione dati

---

### 🎯 DEMO (Demo User)
**Username pattern:** `demo*`

**Permessi:**
- ✅ VIEW_DATA

**Limitazioni:**
- ❌ NO download
- ❌ NO upload
- ❌ NO pubblicazione
- Limite di accessi simultanei (MAX_CONCURRENT_USERS)

**Casi d'uso:**
- Utenti anonimi in demo
- Preview senza registrazione

---

## Permessi Disponibili

### 📊 Data Permissions

#### VIEW_DATA
- **Descrizione**: Visualizzare dati e applicazioni
- **Ruoli**: Tutti

#### DOWNLOAD_DATA
- **Descrizione**: Scaricare dataset e risultati
- **Ruoli**: Admin, Scientist, Researcher, Analyst, Guest

#### UPLOAD_DATA
- **Descrizione**: Caricare nuovi dati
- **Ruoli**: Admin, Scientist, Researcher

#### DELETE_DATA
- **Descrizione**: Eliminare dati esistenti
- **Ruoli**: Admin

---

### 📤 Publishing Permissions

#### PUBLISH_DIRECT
- **Descrizione**: Pubblicare direttamente senza approvazione
- **Ruoli**: Admin
- **Esempio**: Pubblicare risultati su portale pubblico

#### PUBLISH_REQUEST
- **Descrizione**: Richiedere pubblicazione con approvazione admin
- **Ruoli**: Scientist, Researcher, Analyst
- **Esempio**: Inviare richiesta per pubblicare dataset

---

### ⚙️ Admin Permissions

#### MANAGE_USERS
- **Descrizione**: Gestire utenti (creazione, modifica, eliminazione)
- **Ruoli**: Admin

#### VIEW_LOGS
- **Descrizione**: Visualizzare log di sistema e audit trail
- **Ruoli**: Admin

#### SYSTEM_CONFIG
- **Descrizione**: Modificare configurazione di sistema
- **Ruoli**: Admin

---

## Come Usare nelle Pagine

### Setup Base

```python
import streamlit as st
from auth import (
    require_app_login,
    get_current_user_role,
    has_permission,
    is_admin,
    Permission,
    UserRole
)

# Setup pagina
st.set_page_config(page_title="My Page", layout="wide")

# Guard: richiede login
require_app_login()

# Ottieni username e ruolo
username = st.session_state.get("username")
role = get_current_user_role()
```

---

## Pattern Comuni

### Pattern 1: Check Permission e UI Condizionale

**Caso d'uso**: Mostrare/nascondere bottoni in base ai permessi

```python
st.subheader("📤 Publishing")

# Admin: bottone pubblicazione diretta
if has_permission(Permission.PUBLISH_DIRECT):
    if st.button("🚀 Publish Now", type="primary"):
        publish_data()
        st.success("✅ Published!")

# Altri utenti: bottone richiesta pubblicazione
elif has_permission(Permission.PUBLISH_REQUEST):
    if st.button("📨 Request Publication"):
        request_publication()
        st.info("✅ Request sent to admin")

# Utenti senza permessi
else:
    st.warning("🚫 No publishing permissions")
```

---

### Pattern 2: Guard Function

**Caso d'uso**: Bloccare accesso a intera pagina/sezione

```python
from auth import require_permission, require_admin

# Blocca se utente non ha permesso UPLOAD_DATA
require_permission(Permission.UPLOAD_DATA, 
                   error_message="You cannot upload data")

# Oppure richiede admin
require_admin(error_message="Admin only area")

# Il codice qui sotto viene eseguito solo se check passa
st.write("Upload interface...")
uploaded_file = st.file_uploader("Upload file")
```

---

### Pattern 3: Check Admin

**Caso d'uso**: Sezione admin con tools avanzati

```python
if is_admin():
    st.success("👑 Admin Panel")
    
    with st.expander("Admin Tools"):
        if st.button("Manage Users"):
            show_user_management()
        
        if st.button("View Logs"):
            show_system_logs()
else:
    st.warning("Admin access only")
```

---

### Pattern 4: Logica Basata su Ruolo

**Caso d'uso**: Comportamenti diversi per ruoli diversi

```python
role = get_current_user_role()

if role == UserRole.ADMIN:
    # Admin vede tutto
    data = load_all_data()
elif role == UserRole.SCIENTIST:
    # Scientist vede solo i propri dati
    data = load_user_data(username)
elif role == UserRole.DEMO:
    # Demo vede sample limitato
    data = load_sample_data()
else:
    data = load_public_data()

st.dataframe(data)
```

---

### Pattern 5: Download Condizionale

**Caso d'uso**: Permettere download solo a certi utenti

```python
# Mostra sempre i dati
st.dataframe(results)

# Download solo per utenti autorizzati
if has_permission(Permission.DOWNLOAD_DATA):
    csv = results.to_csv(index=False)
    st.download_button(
        label="⬇️ Download CSV",
        data=csv,
        file_name="results.csv",
        mime="text/csv"
    )
else:
    st.info("🔒 Download available for registered users only")
```

---

## Esempi Pratici

### Esempio 1: Pagina di Upload con Pubblicazione

```python
import streamlit as st
from auth import (
    require_app_login,
    has_permission,
    Permission
)

st.set_page_config(page_title="Data Upload", layout="wide")
require_app_login()

st.title("📤 Data Upload & Publishing")

# Verifica permesso upload
if not has_permission(Permission.UPLOAD_DATA):
    st.error("🚫 You don't have upload permissions")
    st.stop()

# Form upload
uploaded_file = st.file_uploader("Choose a file")

if uploaded_file:
    # Process file
    st.success("File processed!")
    
    # Sezione pubblicazione
    st.subheader("Publish Dataset")
    
    if has_permission(Permission.PUBLISH_DIRECT):
        # Admin: pubblicazione immediata
        if st.button("🚀 Publish Now"):
            publish_dataset(uploaded_file)
            st.success("✅ Dataset published!")
    
    elif has_permission(Permission.PUBLISH_REQUEST):
        # Altri: richiesta pubblicazione
        reason = st.text_area("Reason for publishing")
        if st.button("📨 Request Publication"):
            send_publish_request(uploaded_file, reason)
            st.success("✅ Request sent to administrator")
    
    else:
        st.info("Contact admin to publish this dataset")
```

---

### Esempio 2: Admin Panel

```python
import streamlit as st
from auth import require_app_login, require_admin

st.set_page_config(page_title="Admin Panel", layout="wide")
require_app_login()

# Blocca se non admin
require_admin()

st.title("⚙️ Administration Panel")

tab1, tab2, tab3 = st.tabs(["Users", "Logs", "Config"])

with tab1:
    st.subheader("👥 User Management")
    # User management interface
    
with tab2:
    st.subheader("📊 System Logs")
    # Log viewer
    
with tab3:
    st.subheader("⚙️ Configuration")
    # System config
```

---

### Esempio 3: Dashboard con Sezioni Condizionali

```python
import streamlit as st
from auth import (
    require_app_login,
    get_current_user_role,
    has_permission,
    is_admin,
    Permission,
    UserRole,
    show_user_badge
)

st.set_page_config(page_title="Dashboard", layout="wide")
require_app_login()

# Mostra badge utente in sidebar
show_user_badge()

st.title("📊 Data Dashboard")

# Sezione 1: Visualizzazione (tutti)
st.subheader("📈 Data Visualization")
display_charts()

# Sezione 2: Download (escluso demo)
if has_permission(Permission.DOWNLOAD_DATA):
    st.subheader("💾 Export Data")
    show_download_options()

# Sezione 3: Upload (scientist+)
if has_permission(Permission.UPLOAD_DATA):
    st.subheader("📤 Upload New Data")
    show_upload_form()

# Sezione 4: Admin tools
if is_admin():
    st.subheader("⚙️ Admin Tools")
    show_admin_tools()
```

---

## Migrazione Futura

### Da Inferenza Username a Campo Role

Attualmente il sistema inferisce il ruolo dal username (es. `scientist1` → `SCIENTIST`).

In futuro, si può migrare a un campo `role` nel database:

#### Step 1: Aggiungere colonna role

```python
# In auth/auth.py - init_database()
cursor.execute("""
    ALTER TABLE users 
    ADD COLUMN role TEXT DEFAULT 'guest'
""")
```

#### Step 2: Popolare ruoli esistenti

```python
# Script di migrazione
conn = sqlite3.connect(DATABASE_PATH)
cursor = conn.cursor()

# Inferire ruoli da username esistenti
cursor.execute("UPDATE users SET role = 'admin' WHERE username = 'admin'")
cursor.execute("UPDATE users SET role = 'scientist' WHERE username LIKE 'scientist%'")
cursor.execute("UPDATE users SET role = 'researcher' WHERE username LIKE 'researcher%'")
cursor.execute("UPDATE users SET role = 'analyst' WHERE username LIKE 'analyst%'")
cursor.execute("UPDATE users SET role = 'guest' WHERE username LIKE 'guest%'")
cursor.execute("UPDATE users SET role = 'demo' WHERE username LIKE 'demo%'")

conn.commit()
```

#### Step 3: Modificare `get_user_role()` in `auth/roles.py`

```python
def get_user_role(username: str) -> UserRole:
    """Get role from database instead of inferring from username"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        role_str = row[0]
        try:
            return UserRole(role_str)
        except ValueError:
            return UserRole.GUEST
    
    return UserRole.GUEST
```

#### Step 4: UI per modificare ruoli

Aggiungere in admin panel la possibilità di cambiare ruolo agli utenti.

---

## 🔧 Testing

Per testare il sistema RBAC:

```bash
# Avvia l'app
docker-compose up -d

# Apri la pagina di esempio
http://localhost:8501/RBAC_Example

# Testa con diversi utenti:
# - admin / Admin2025! (tutti i permessi)
# - scientist1 / password123 (no publish direct)
# - guest1 / Guest@CNR1 (solo view e download)
# - demo / demo (solo view)
```

---

## 📚 Reference API

### Funzioni Principali

```python
# Get role
get_current_user_role() -> Optional[UserRole]
get_user_role(username: str) -> UserRole

# Check permissions
has_permission(perm: Permission, username: Optional[str] = None) -> bool
has_any_permission(perms: List[Permission], username: Optional[str] = None) -> bool
has_all_permissions(perms: List[Permission], username: Optional[str] = None) -> bool

# Check admin
is_admin(username: Optional[str] = None) -> bool

# Guard functions (stop execution if check fails)
require_permission(perm: Permission, error_message: Optional[str] = None)
require_role(role: UserRole, error_message: Optional[str] = None)
require_admin(error_message: Optional[str] = None)

# UI helpers
get_role_display_name(role: UserRole) -> str
show_user_badge()  # Display user role badge in sidebar
```

---

## ❓ FAQ

**Q: Posso avere utenti con permessi custom?**  
A: Attualmente no, i permessi sono legati ai ruoli. Per custom permissions, devi modificare `ROLE_PERMISSIONS` in `auth/roles.py`.

**Q: Come aggiungo un nuovo permesso?**  
A: 
1. Aggiungi in `Permission` enum
2. Aggiungi ai ruoli appropriati in `ROLE_PERMISSIONS`

**Q: Come creo un nuovo ruolo?**  
A:
1. Aggiungi in `UserRole` enum
2. Aggiungi mapping in `ROLE_PERMISSIONS`
3. Aggiungi logica in `infer_role_from_username()` se usi inferenza

**Q: I demo users hanno limitazioni oltre ai permessi?**  
A: Sì, hanno anche:
- Limite accessi simultanei (`MAX_CONCURRENT_USERS`)
- Possibile timeout sessione più breve
- Gestione coda se tutti gli slot sono occupati

---

## 🎯 Best Practices

1. **Usa guard functions per proteggere pagine intere**:
   ```python
   require_permission(Permission.UPLOAD_DATA)
   ```

2. **Usa check condizionali per UI elementi**:
   ```python
   if has_permission(Permission.DOWNLOAD_DATA):
       st.download_button(...)
   ```

3. **Fornisci feedback chiaro agli utenti**:
   ```python
   if not has_permission(perm):
       st.error("You don't have permission")
       st.info("Contact admin for access")
   ```

4. **Usa `show_user_badge()` per trasparenza**:
   - Utenti vedono chiaramente il loro ruolo
   - Vedono i loro permessi

5. **Testa con diversi ruoli durante sviluppo**

6. **Documenta quali permessi servono per ogni feature**

---

## 📞 Support

Per domande o problemi:
- Consulta esempi in `pages/RBAC_Example.py`
- Controlla la documentazione in `auth/roles.py`
- Contatta il team di sviluppo
