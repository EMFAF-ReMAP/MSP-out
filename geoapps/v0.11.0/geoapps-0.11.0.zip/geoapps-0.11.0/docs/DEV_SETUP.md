# Come configurare l'ambiente di sviluppo

## ✅ Soluzione Finale - Variabile d'ambiente DATABASE_URL

Per impostare l'ambiente di sviluppo su Windows/Mac, usa la variabile d'ambiente `DATABASE_URL` nel file `docker-compose-local.yml`:

```yaml
environment:
  - GEOAPPS_ENV=development
  - DATABASE_URL=postgresql://remap:remap@host.docker.internal:5436/remap
```

### Ordine di priorità in dbconn.py:

1. **Variabile d'ambiente `DATABASE_URL`** (impostata da docker-compose)
2. **ConfigManager** (legge da config.yaml in base a GEOAPPS_ENV)
3. **defaults.py** (fallback per produzione Linux)

### Perché serve la variabile d'ambiente?

Il `ConfigManager` viene inizializzato correttamente e legge `config.yaml`, MA il modulo `dbconn.py` viene importato molto presto nel ciclo di vita dell'applicazione, a volte prima che il ConfigManager sia completamente inizializzato. 

La variabile d'ambiente garantisce che `dbconn.py` abbia sempre l'URL corretto sin dall'inizio, senza dover dipendere dal timing di inizializzazione del ConfigManager.

### Test

Per verificare che la configurazione funzioni:

```bash
docker-compose -f docker-compose-local.yml run --rm streamlit python -c "
import os
print('DATABASE_URL:', os.getenv('DATABASE_URL'))
import sys
sys.path.insert(0, '/var/geoapps')
from geoapps.database.dbconn import DATABASE_URL
print('DB URL in dbconn:', DATABASE_URL)
"
```

Output atteso:
```
DATABASE_URL: postgresql://remap:remap@host.docker.internal:5436/remap
✅ [dbconn.py] Got DATABASE_URL from environment variable
DATABASE_URL in dbconn: postgresql://remap:remap@host.docker.internal:5436/remap
```

### Produzione (Linux)

In produzione, **NON** impostare `DATABASE_URL` come variabile d'ambiente. 

Il sistema userà automaticamente i defaults.py:
```python
DATABASE_URL = "postgresql://remap:remap@172.17.0.1:5432/remap"
```

Oppure puoi sovrascriverlo in `secrets.yaml`:
```yaml
production:
  database_url: "postgresql://user:pass@custom-host:5432/db"
```
