# 🎫 Demo Queue Anti-Spam Implementation

## 📋 Summary

Implementato sistema anti-spam per la coda demo con limite massimo di 20 utenti e timeout automatico.

---

## ✅ Modifiche Implementate

### 1. Costante Configurabile

**File: `geoapps/core/defaults.py`**

```python
MAX_DEMO_QUEUE_SIZE = 20  # Maximum number of users allowed in demo queue (anti-spam)
```

- ✅ Limite massimo utenti in coda: **20 persone**
- ✅ Configurabile tramite `config.yaml` sotto `auth.max_demo_queue_size`
- ✅ Valore di default: 20

---

### 2. Controllo Anti-Spam nella Funzione Queue

**File: `geoapps/auth/auth.py`**

#### Modifiche a `add_to_demo_queue()`:

```python
def add_to_demo_queue(browser_id: str) -> int:
    """
    - Raises ValueError if queue is full (exceeds MAX_DEMO_QUEUE_SIZE).
    """
    # Check if browser is already in queue
    cur.execute("SELECT id FROM demo_queue WHERE browser_id = ? AND is_active = 1", (browser_id,))
    already_in_queue = cur.fetchone() is not None

    # Compute current queue size
    cur.execute("SELECT COUNT(*) FROM demo_queue WHERE is_active = 1")
    current_queue_size = cur.fetchone()[0]
    
    # If not already in queue and queue is full, reject
    if not already_in_queue and current_queue_size >= MAX_DEMO_QUEUE_SIZE:
        raise ValueError(f"Queue is full. Maximum {MAX_DEMO_QUEUE_SIZE} users allowed in queue.")
```

**Logica:**
- ✅ Se utente già in coda → può rimanere (no doppio conteggio)
- ✅ Se utente nuovo E coda piena → **ValueError**
- ✅ Se coda non piena → accetta normalmente

---

### 3. Statistiche Coda Aggiornate

**File: `geoapps/auth/auth.py`**

#### Modifiche a `get_queue_stats()`:

Ora ritorna informazioni estese:

```python
{
    "total_in_queue": 15,            # Utenti in coda
    "estimated_wait": 150,           # Minuti stimati
    "max_queue_size": 20,            # Limite massimo
    "is_queue_full": False,          # Boolean: coda piena?
    "available_queue_spots": 5       # Posti liberi rimasti
}
```

**Vantaggi:**
- ✅ UI può mostrare stato coda
- ✅ Warning quando quasi piena
- ✅ Blocco automatico quando piena

---

### 4. Cleanup Automatico Queue Scadute

**File: `geoapps/auth/auth.py`**

#### Nuova funzione `cleanup_expired_queue()`:

```python
def cleanup_expired_queue():
    """Remove expired queue entries (users waiting longer than DEMO_QUEUE_TIMEOUT_MINUTES)."""
    expiry_time = datetime.now() - timedelta(minutes=DEMO_QUEUE_TIMEOUT_MINUTES)
    cursor.execute(
        "UPDATE demo_queue SET is_active = 0 WHERE reservation_time < ? AND is_active = 1",
        (expiry_time.isoformat(),),
    )
```

**Comportamento:**
- ✅ Timeout: **30 minuti** (configurabile via `DEMO_QUEUE_TIMEOUT_MINUTES`)
- ✅ Utenti in coda da più di 30 min vengono rimossi automaticamente
- ✅ Chiamata ogni volta che si apre la pagina demo
- ✅ Log: mostra quanti utenti sono stati rimossi

---

### 5. UI Aggiornata con Status Coda

**File: `geoapps/streamlit_app_demo.py`**

#### A. Metric con stato coda:

```python
if queue_stats["total_in_queue"] > 0:
    queue_status = f"{queue_stats['total_in_queue']}/{queue_stats['max_queue_size']}"
    if queue_stats["is_queue_full"]:
        st.metric("🎫 Queue (FULL)", queue_status, delta="Queue is full", delta_color="inverse")
    else:
        st.metric("🎫 People in queue", queue_status)
```

**Mostra:**
- `🎫 People in queue: 15/20` (quando non piena)
- `🎫 Queue (FULL): 20/20 ⚠️ Queue is full` (quando piena)

#### B. Warning dinamici:

```python
if queue_stats["is_queue_full"]:
    st.error(f"❌ Queue is full ({queue_stats['max_queue_size']} people max)")
    st.info("💡 Please try again later or create an account for unlimited access.")
elif queue_stats["available_queue_spots"] <= 5:
    st.warning(f"⚠️ Queue is almost full! Only {queue_stats['available_queue_spots']} spots remaining.")
```

**Livelli:**
- 🟢 **Normale** (6+ posti): Info standard
- 🟡 **Quasi piena** (1-5 posti): Warning arancione
- 🔴 **Piena** (0 posti): Errore rosso + bottone disabilitato

#### C. Bottone condizionale:

```python
if not is_in_demo_queue(st.session_state.client_id) and not queue_stats["is_queue_full"]:
    if st.button("🎫 Join the queue", key="join_queue", type="primary"):
        # ...
```

**Comportamento:**
- ✅ Bottone "Join the queue" appare solo se coda NON piena
- ✅ Se coda piena → bottone non appare
- ✅ Messaggi di errore user-friendly

#### D. Error handling migliorato:

```python
try:
    position = add_to_demo_queue(st.session_state.client_id)
    st.success(f"✅ Reservation confirmed! Your position is #{position}")
except ValueError as e:
    # Queue is full
    st.error(f"❌ {str(e)}")
    st.info("💡 Please try again later or create an account for unlimited access.")
except Exception as e:
    # Other errors
    st.error(f"❌ Could not join the queue: {e}")
```

---

## 🎯 Configurazione

### Config File (`config.yaml`)

```yaml
auth:
  max_concurrent_users: 5
  session_timeout_minutes: 10
  max_demo_queue_size: 20        # ← NUOVO
  demo_queue_timeout_minutes: 30 # Timeout coda
```

### Valori Default (`core/defaults.py`)

```python
MAX_DEMO_QUEUE_SIZE = 20           # Maximum queue size
DEMO_QUEUE_TIMEOUT_MINUTES = 30    # Queue entry expiration
```

---

## 📊 Comportamento Sistema

### Scenario 1: Coda Normale (< 20 utenti)

1. Utente clicca "Join the queue"
2. Sistema controlla: `current_queue_size < 20` ✅
3. Utente aggiunto in posizione N
4. Mostra: "✅ Reservation confirmed! Your position is #N"

### Scenario 2: Coda Quasi Piena (15-19 utenti)

1. UI mostra: "⚠️ Queue is almost full! Only 3 spots remaining."
2. Bottone "Join the queue" ancora abilitato
3. Utente può ancora unirsi

### Scenario 3: Coda Piena (20 utenti)

1. UI mostra: "❌ Queue is full (20 people max)"
2. Bottone "Join the queue" **NON appare**
3. Suggerimento: "Create an account for unlimited access"
4. Se utente già in coda → può rimanere

### Scenario 4: Timeout Automatico

1. Utente in coda da > 30 minuti
2. `cleanup_expired_queue()` viene chiamata
3. Utente rimosso automaticamente
4. Coda si libera per nuovi utenti
5. Log: "🧹 Cleaned up 3 expired queue entries"

---

## 🛡️ Protezione Anti-Spam

### Problema Risolto:
❌ **Prima**: Utenti potevano spammare la coda infinitamente  
✅ **Dopo**: Limite rigido di 20 utenti + timeout automatico

### Meccanismi di Protezione:

1. **Limite Fisso**: MAX_DEMO_QUEUE_SIZE = 20
2. **Timeout Automatico**: 30 minuti di attesa massima
3. **Cleanup Periodico**: Ogni page load
4. **Check Pre-Insert**: Controllo PRIMA di aggiungere
5. **Error Handling**: ValueError con messaggio chiaro
6. **UI Preventiva**: Bottone nascosto quando piena

---

## 🔍 Testing

### Test 1: Raggiungere il Limite

```python
# Simula 20 utenti in coda
for i in range(20):
    add_to_demo_queue(f"browser_{i}")

# 21° utente
try:
    add_to_demo_queue("browser_21")
except ValueError as e:
    print(f"✅ Correctly rejected: {e}")
    # Output: "Queue is full. Maximum 20 users allowed in queue."
```

### Test 2: Verifica Statistiche

```python
stats = get_queue_stats()
print(f"Queue: {stats['total_in_queue']}/{stats['max_queue_size']}")
print(f"Full: {stats['is_queue_full']}")
print(f"Free spots: {stats['available_queue_spots']}")
```

### Test 3: Cleanup Timeout

```python
# Aggiungi utente 30+ minuti fa
conn = sqlite3.connect(DATABASE_PATH)
cur = conn.cursor()
old_time = (datetime.now() - timedelta(minutes=35)).isoformat()
cur.execute(
    "INSERT INTO demo_queue (browser_id, reservation_time, is_active) VALUES (?, ?, 1)",
    ("old_browser", old_time)
)
conn.commit()

# Cleanup
cleanup_expired_queue()

# Verifica rimosso
cur.execute("SELECT is_active FROM demo_queue WHERE browser_id = ?", ("old_browser",))
assert cur.fetchone()[0] == 0  # ✅ Deactivated
```

---

## 📈 Monitoring

### Metriche da Monitorare:

1. **Queue Size**: Quante volte raggiunge il limite
2. **Rejections**: Quanti utenti vengono rifiutati
3. **Timeout Rate**: Quanti utenti vengono rimossi per timeout
4. **Average Wait Time**: Tempo medio in coda

### Query Database:

```sql
-- Utenti attualmente in coda
SELECT COUNT(*) FROM demo_queue WHERE is_active = 1;

-- Utenti in coda da più di 10 minuti
SELECT COUNT(*) FROM demo_queue 
WHERE is_active = 1 
AND datetime(reservation_time) < datetime('now', '-10 minutes');

-- Storico join alla coda (ultime 24h)
SELECT COUNT(*) FROM demo_queue 
WHERE datetime(reservation_time) > datetime('now', '-1 day');
```

---

## 🚀 Deploy

### Restart Required?

**NO** - Modifiche hot-reloadable:
- ✅ Config changes: reload automatico
- ✅ Code changes: riavvio Streamlit
- ✅ Database schema: invariata

### Deployment Steps:

```bash
# 1. Pull changes
git pull origin main

# 2. Restart containers
docker-compose restart

# 3. Verify
docker-compose logs -f streamlit | grep -i queue
```

### Rollback (se necessario):

```bash
# Revert config
git checkout HEAD~1 -- geoapps/core/defaults.py

# Temporary override
docker-compose exec streamlit \
  python -c "from auth.auth import MAX_DEMO_QUEUE_SIZE; print(MAX_DEMO_QUEUE_SIZE)"
```

---
