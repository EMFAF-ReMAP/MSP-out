# Docker Setup Guide

## File Docker Compose

Il progetto ha due file docker-compose per gestire ambienti diversi:

### 1. `docker-compose.yml` - Produzione Linux

Configurato per ambiente di **produzione su server Linux**.

**Caratteristiche:**
- Rete Traefik per reverse proxy e SSL
- Domini pubblici con certificati Let's Encrypt
- URL database: `172.17.0.1:5432` (gateway Docker Linux)
- Nessuna variabile `GEOAPPS_ENV` (default = production)

**Utilizzo:**
```bash
docker-compose up -d
```

### 2. `docker-compose-local.yml` - Development Windows/Mac

Configurato per **development locale su Windows/Mac**.

**Caratteristiche:**
- Porte esposte direttamente (8503, 8080)
- DNS fix per Windows (8.8.8.8)
- `extra_hosts` per `host.docker.internal`
- URL database: `host.docker.internal:5436` (da config.yaml)
- **Variabile ambiente: `GEOAPPS_ENV=development`**

**Utilizzo:**
```bash
docker-compose -f docker-compose-local.yml up
```

## Configurazione Database per Ambiente

### Produzione Linux (default in `defaults.py`)
```python
DATABASE_URL = "postgresql://remap:remap@172.17.0.1:5432/remap"
```
- **Host**: `172.17.0.1` (gateway rete Docker bridge)
- **Port**: `5432` (porta standard PostgreSQL)

### Development Windows (override in `config.yaml`)
```yaml
development:
  database:
    host: "host.docker.internal"  # Magic hostname per Docker Desktop
    port: 5436  # Porta custom PostgreSQL su Windows
```

## Come funziona il sistema di configurazione

1. **Nessuna config presente** → Usa `defaults.py` (Produzione Linux)
2. **`config.yaml` presente + `GEOAPPS_ENV=development`** → Usa sezione `development:` dal config
3. **`config.yaml` presente + `GEOAPPS_ENV=production`** → Usa sezione `production:` dal config
4. **`secrets.yaml` presente** → Override per password e API keys

### Priorità di caricamento

```
secrets.yaml > config.yaml > defaults.py
       ↓              ↓            ↓
   (sensible)    (environment)  (production)
```

## Quick Start

### Development su Windows
```bash
# 1. Assicurati che PostgreSQL sia in ascolto su porta 5436
# 2. Lancia il container
docker-compose -f docker-compose-local.yml up

# L'app sarà disponibile su:
# - Streamlit: http://localhost:8503
# - Static files: http://localhost:8080
```

### Produzione su Linux
```bash
# 1. Assicurati che PostgreSQL sia accessibile su 172.17.0.1:5432
# 2. Lancia i container
docker-compose up -d

# L'app sarà disponibile su:
# - https://geoapps.tools4msp.eu (via Traefik)
# - https://statics.geoapps.tools4msp.eu (static files)
```

## Configurazione Files

### ❌ NON servono file .env

Il progetto **NON usa file .env**. Tutta la configurazione è gestita tramite:

1. **docker-compose-local.yml** o **docker-compose.yml** → Variabile `GEOAPPS_ENV`
2. **config.yaml** → Configurazioni per environment
3. **secrets.yaml** → Password e API keys

Se vedi riferimenti a `.env` o `.env.example` nella documentazione vecchia, **ignorali**.

## Troubleshooting

### Windows: "Cannot connect to database"
- ✅ Verifica che PostgreSQL sia in esecuzione
- ✅ Controlla che la porta 5436 sia aperta
- ✅ Verifica che `GEOAPPS_ENV=development` sia impostato nel docker-compose-local.yml (è già presente)
- ✅ Controlla il config.yaml abbia la sezione `development:` con host e port corretti
- ❌ NON creare file .env (non vengono letti dal sistema)

### Linux: "Connection refused to 172.17.0.1"
- ✅ Verifica che PostgreSQL sia in ascolto su `0.0.0.0` o `172.17.0.1`
- ✅ Controlla il firewall del server
- ✅ Verifica che il container possa raggiungere la rete host
- ✅ Usa `docker network inspect bridge` per verificare il gateway

### Config non viene caricato
- ✅ Verifica che `config.yaml` sia montato nel container (vedere volumes in docker-compose)
- ✅ Controlla i log del container: `docker-compose logs streamlit`
- ✅ Verifica i permessi del file config.yaml (deve essere leggibile)

## Migrazione da dev a produzione

1. **Non modificare** `defaults.py` con configurazioni temporanee
2. Testa in development con `docker-compose-local.yml`
3. Per deploy in produzione:
   - Usa `docker-compose.yml` (senza `-f`)
   - PostgreSQL deve essere accessibile su `172.17.0.1:5432`
   - Oppure override in `secrets.yaml` production:
     ```yaml
     production:
       database:
         host: "custom-host"
         port: 5432
     ```

## Best Practices

✅ **DO:**
- Usa `docker-compose-local.yml` per development
- Imposta `GEOAPPS_ENV=development` in environment variables
- Mantieni `defaults.py` ottimizzato per produzione
- Usa `secrets.yaml` per credenziali reali

❌ **DON'T:**
- Non committare `secrets.yaml`
- Non modificare `defaults.py` per configurazioni temporanee
- Non hardcodare IP/porte nel codice
- Non usare `docker-compose.yml` per development locale
