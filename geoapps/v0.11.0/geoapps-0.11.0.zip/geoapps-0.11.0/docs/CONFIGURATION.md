# Configuration Management

## Overview

GeoApps usa un sistema di configurazione **a DUE LIVELLI** (NO .env files):

1. **`core/defaults.py`**: Valori di default hardcoded nel codice (ambiente PRODUZIONE Linux)
2. **`config.yaml`**: Configurazione per environment specifici (committato in Git)
3. **`secrets.yaml`**: Password e API keys sensibili (NON committato, gitignored)

### Filosofia di configurazione

- **Default = Produzione Linux**: Se non esiste `config.yaml` o manca una configurazione, l'applicazione usa i default ottimizzati per produzione su Linux
- **Development esplicito**: Le configurazioni specifiche per Windows/Mac vanno nel `config.yaml` sotto `development:`
- **Secrets separati**: Password e chiavi API vanno sempre in `secrets.yaml` (non committato)
- **NO .env files**: Le variabili d'ambiente sono gestite direttamente da docker-compose, non servono file .env

### Variabili d'ambiente

L'**UNICA** variabile d'ambiente necessaria è `GEOAPPS_ENV` che seleziona quale sezione del config.yaml usare:

```yaml
# In docker-compose-local.yml
environment:
  - GEOAPPS_ENV=development  # Usa sezione development: dal config.yaml
```

Tutte le altre configurazioni vanno nei file YAML (config.yaml o secrets.yaml), **NON** in variabili d'ambiente o file .env.

## File defaults.py

Il file `geoapps/core/defaults.py` contiene tutti i valori di fallback usati quando la configurazione non è disponibile o non specifica un valore.

### Parametri disponibili:

#### Autenticazione & Sessioni
- `MAX_CONCURRENT_USERS`: Numero massimo di utenti demo simultanei (default: 2)
- `SESSION_TIMEOUT_MINUTES`: Timeout sessione in minuti (default: 10)
- `DEMO_QUEUE_TIMEOUT_MINUTES`: Timeout coda demo in minuti (default: 30)

#### Database
- `DATABASE_PATH`: Path del database SQLite per auth (default: "geoapps_storage/auth.db")
- `SQLITE_TIMEOUT`: Timeout SQLite in secondi (default: 10.0)
- `SQLITE_MAX_RETRIES`: Numero di retry per SQLite (default: 5)
- `SQLITE_RETRY_SLEEP`: Pausa tra retry in secondi (default: 0.2)

#### Sicurezza
- `UTILS_SECRET`: Secret per utils (default: generato)
- `COOKIE_SECRET`: Secret per cookie encryption (default: "change_this_secret_key")
- `COOKIE_PREFIX`: Prefisso per i cookie (default: "cnr_demo_")

#### Storage
- `STATIC_DIR`: Directory per file statici pubblicati
- `STORAGE_DIR`: Directory root per storage

## Configurazione in config.yaml

Per sovrascrivere i default, aggiungi i parametri in `config.yaml`:

```yaml
common:
  auth:
    max_concurrent_users: 5  # Numero di slot demo
    session_timeout_minutes: 15  # Timeout sessione
    database_path: "geoapps_storage/auth.db"
  
  database:
    sqlite_timeout: 15.0
    sqlite_max_retries: 10
```

## Come funziona il caricamento

1. Il codice importa i valori da `core/defaults.py`
2. Se disponibile, carica `config.yaml` e sovrascrive i default
3. Se disponibile, carica `secrets.yaml` per i valori sensibili
4. Se la config non è disponibile, usa i default

## Esempio: Modificare il numero di slot demo

### Opzione 1: Via config.yaml (raccomandato)
```yaml
common:
  auth:
    max_concurrent_users: 10  # 10 slot demo
```

### Opzione 2: Via environment variable
```bash
export AUTH_MAX_CONCURRENT_USERS=10
```

### Opzione 3: Modificare defaults.py (sconsigliato)
Modifica direttamente `geoapps/core/defaults.py`:
```python
MAX_CONCURRENT_USERS = 10
```

## File modificati

I seguenti file sono stati aggiornati per usare il sistema centralizzato:

- `geoapps/auth/auth.py`: Carica config per parametri di autenticazione
- `geoapps/auth/access_guard.py`: Usa defaults per cookie management
- `geoapps/tools/utils.py`: Usa defaults per secrets e paths

## Environment Detection

L'ambiente viene rilevato tramite **l'UNICA variabile d'ambiente necessaria**: `GEOAPPS_ENV`

**Questa variabile è già configurata nei file docker-compose**, non devi creare file .env:

```yaml
# In docker-compose-local.yml (Windows/Mac development)
environment:
  - GEOAPPS_ENV=development

# In docker-compose.yml (Linux production)
# Nessuna variabile → default = production
```

### Uso manuale (se non usi Docker):

```bash
# Produzione (default se non impostato)
# Usa: 172.17.0.1:5432 (Docker Linux)
streamlit run geoapps/streamlit_app_demo.py

# Development (Windows/Mac)
# Usa: host.docker.internal:5436 (da config.yaml)
export GEOAPPS_ENV=development  # Linux/Mac
set GEOAPPS_ENV=development     # Windows CMD
$env:GEOAPPS_ENV="development"  # Windows PowerShell
streamlit run geoapps/streamlit_app_demo.py
```

### Database URLs per ambiente

| Ambiente | Host | Port | Default in |
|----------|------|------|------------|
| **Produzione (Linux)** | `172.17.0.1` | `5432` | `defaults.py` |
| **Development (Windows)** | `host.docker.internal` | `5436` | `config.yaml` |
| **Development (Mac)** | `host.docker.internal` | `5436` | `config.yaml` |

## Best Practices

1. ✅ **Usa config.yaml** per configurazione specifica dell'ambiente development/staging
2. ✅ **Usa secrets.yaml** per valori sensibili (password, API keys)
3. ✅ **Lascia defaults.py** ottimizzato per produzione Linux
4. ✅ **Imposta GEOAPPS_ENV=development** per ambienti non-Linux
5. ❌ **Non committare secrets.yaml** (è in .gitignore)
6. ❌ **Non hardcodare secrets** nel codice
7. ❌ **Non modificare defaults.py** per configurazioni temporanee

## Testing

Per testare con diversi valori:

```bash
# Test con 5 slot demo
echo "common:\n  auth:\n    max_concurrent_users: 5" > config.yaml
docker-compose up

# Verifica nei log:
# "MAX_CONCURRENT_USERS loaded from config: 5"
```
