# Docker Compose Templates

Docker Compose configurations for different environments.

## Templates

### `docker-compose.local.yaml`
Development on Windows/Mac
- Ports: 8503 (Streamlit), 8080 (static)
- Hot reload enabled
- Database: `host.docker.internal:5436`

### `docker-compose.production.yaml`
Production on Linux with Traefik
- Traefik reverse proxy + SSL
- Domains: `geoapps.tools4msp.eu`
- Database: `172.17.0.1:5432`

### `docker-compose.static.yaml`
Static files only (nginx)
- Port 8080
- No Streamlit app

## Usage

**Development:**
```bash
cp docker/docker-compose.local.yaml docker-compose.yml
```

**Production:**
```bash
cp docker/docker-compose.production.yaml docker-compose.yml
```

**Static only:**
```bash
docker-compose -f docker/docker-compose.static.yaml up -d
```

## Notes

- `docker-compose.yml` in root is NOT committed
- Templates in `docker/` ARE committed
