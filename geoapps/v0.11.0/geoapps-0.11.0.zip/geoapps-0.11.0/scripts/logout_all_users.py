#!/usr/bin/env python3
"""
Script per sloggare tutti gli utenti e pulire la coda demo
Usa questo script quando vuoi resettare completamente lo stato delle sessioni

NOTA: Questo script accede direttamente al database SQLite
Non richiede dipendenze Streamlit pesanti
"""

import sys
import os
import sqlite3

def main():
    """Logout di tutti gli utenti e pulizia coda tramite SQLite diretto"""
    # Path corretto dalla cartella scripts
    project_root = os.path.dirname(os.path.dirname(__file__))
    db_path = os.path.join(project_root, 'geoapps_storage', 'auth.db')
    
    print("🔄 Script Logout Diretto (SQLite)")
    print(f"📂 Database: {db_path}")
    
    if not os.path.exists(db_path):
        print("❌ Database non trovato!")
        print("💡 Esegui prima: python scripts/init_auth.py")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("🚪 Logout di tutti gli utenti e pulizia coda...")
        cursor.execute('UPDATE user_sessions SET is_active = 0')
        cursor.execute('UPDATE demo_queue SET is_active = 0')
        conn.commit()
        
        # Verifica
        cursor.execute('SELECT COUNT(*) FROM user_sessions WHERE is_active = 1')
        active_sessions = cursor.fetchone()[0]
        cursor.execute('SELECT COUNT(*) FROM demo_queue WHERE is_active = 1')
        active_queue = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"✅ Sessioni attive: {active_sessions}")
        print(f"✅ Coda attiva: {active_queue}")
        print("✅ Completato! Tutti gli utenti sono stati sloggati e la coda è stata pulita.")
        
    except Exception as e:
        print(f"❌ Errore: {e}")

if __name__ == "__main__":
    main()