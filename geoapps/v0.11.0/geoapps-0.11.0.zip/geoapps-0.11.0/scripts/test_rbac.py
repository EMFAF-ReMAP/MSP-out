#!/usr/bin/env python3
"""
Test script per verificare il sistema RBAC con ruoli nel database.
"""

import sys
from pathlib import Path

# Setup path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "geoapps"))

from auth.auth import init_database, get_all_users, authenticate_user
from auth.roles import get_user_role, UserRole, get_role_display_name, ROLE_PERMISSIONS

def print_separator(char="═", length=80):
    print(char * length)

def test_database_migration():
    """Test that database has role column and users have roles"""
    print_separator()
    print("🔧 Testing Database Migration")
    print_separator()
    
    # Initialize database (will run migration if needed)
    init_database()
    print("✅ Database initialized")
    
    # Get all users
    users = get_all_users()
    print(f"\n👥 Found {len(users)} users:")
    print(f"{'Username':<15} {'Full Name':<25} {'Email':<30} {'Role':<12}")
    print("-" * 85)
    
    for username, full_name, email, role, created_at in users:
        print(f"{username:<15} {full_name:<25} {email:<30} {role:<12}")
    
    return True

def test_authentication_with_role():
    """Test that authentication returns role"""
    print_separator()
    print("🔐 Testing Authentication with Roles")
    print_separator()
    
    test_users = [
        ("admin", "Admin2025!", "admin"),
        ("scientist1", "password123", "scientist"),
        ("guest1", "Guest@CNR1", "guest"),
        ("demo", "demo", "demo"),
    ]
    
    for username, password, expected_role in test_users:
        user_info = authenticate_user(username, password)
        if user_info:
            actual_role = user_info.get("role", "unknown")
            status = "✅" if actual_role == expected_role else "❌"
            print(f"{status} {username}: role={actual_role} (expected: {expected_role})")
        else:
            print(f"❌ {username}: Authentication failed")
    
    return True

def test_role_lookup():
    """Test get_user_role function"""
    print_separator()
    print("🔍 Testing Role Lookup")
    print_separator()
    
    test_users = [
        "admin", "scientist1", "researcher1", "analyst1", "guest1", "demo"
    ]
    
    for username in test_users:
        role = get_user_role(username)
        display_name = get_role_display_name(role)
        print(f"• {username:<15} → {role.value:<12} ({display_name})")
    
    return True

def test_permissions_matrix():
    """Show permissions matrix for all roles"""
    print_separator()
    print("🔑 Permissions Matrix")
    print_separator()
    
    from auth.roles import Permission
    
    all_roles = list(UserRole)
    all_permissions = list(Permission)
    
    # Header
    print(f"{'Permission':<25}", end="")
    for role in all_roles:
        print(f"{role.value[:5]:<6}", end="")
    print()
    print("-" * (25 + 6 * len(all_roles)))
    
    # Rows
    for perm in all_permissions:
        perm_name = perm.value.replace("_", " ").title()[:24]
        print(f"{perm_name:<25}", end="")
        
        for role in all_roles:
            role_perms = ROLE_PERMISSIONS.get(role, [])
            has_perm = perm in role_perms
            symbol = "✅" if has_perm else "  "
            print(f"{symbol:<6}", end="")
        print()
    
    return True

def test_role_specific_features():
    """Test role-specific features"""
    print_separator()
    print("🎯 Testing Role-Specific Features")
    print_separator()
    
    from auth.roles import has_permission, Permission
    
    test_cases = [
        ("admin", Permission.PUBLISH_DIRECT, True),
        ("scientist1", Permission.PUBLISH_DIRECT, False),
        ("scientist1", Permission.PUBLISH_REQUEST, True),
        ("guest1", Permission.DOWNLOAD_DATA, True),
        ("demo", Permission.DOWNLOAD_DATA, False),
        ("demo", Permission.VIEW_DATA, True),
    ]
    
    print(f"{'Username':<15} {'Permission':<25} {'Expected':<10} {'Result'}")
    print("-" * 60)
    
    for username, permission, expected in test_cases:
        # Simulate having the role
        role = get_user_role(username)
        role_perms = ROLE_PERMISSIONS.get(role, [])
        has_perm = permission in role_perms
        
        status = "✅" if has_perm == expected else "❌"
        print(f"{username:<15} {permission.value:<25} {expected!s:<10} {status} {has_perm}")
    
    return True

def main():
    print_separator("═")
    print("🚀 RBAC System Test Suite")
    print("   Role-Based Access Control with Database Roles")
    print_separator("═")
    print()
    
    tests = [
        test_database_migration,
        test_authentication_with_role,
        test_role_lookup,
        test_permissions_matrix,
        test_role_specific_features,
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"\n❌ Test failed with error: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
        print()
    
    print_separator("═")
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    print_separator("═")
    
    if failed == 0:
        print("\n🎉 All tests passed! RBAC system is working correctly.")
        return 0
    else:
        print(f"\n⚠️ {failed} test(s) failed. Please check the output above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
