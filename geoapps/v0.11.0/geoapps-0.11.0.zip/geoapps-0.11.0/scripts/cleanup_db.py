import sqlite3
import os

# Path corretto dalla cartella scripts - aggiornato per geoapps_storage
db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'geoapps_storage', 'auth.db')

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print('Cleaning all sessions...')
cursor.execute('UPDATE user_sessions SET is_active = 0')
cursor.execute('UPDATE demo_queue SET is_active = 0')
conn.commit()

print('Verifying cleanup...')
cursor.execute('SELECT COUNT(*) FROM user_sessions WHERE is_active = 1')
active_sessions = cursor.fetchone()[0]
cursor.execute('SELECT COUNT(*) FROM demo_queue WHERE is_active = 1')
active_queue = cursor.fetchone()[0]

print(f'Active sessions: {active_sessions}')
print(f'Active queue: {active_queue}')

conn.close()
print('Done!')