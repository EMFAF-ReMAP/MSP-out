# 📜 Scripts Authentication - Guida d'Uso

Questa cartella contiene gli script per gestire il sistema di autenticazione dell'applicazione GeApps.

## 🎯 **Filosofia di Design**
- **Streamlit**: Solo Docker (ambiente controllato e riproducibile)
- **Scripts**: Solo ambiente locale (accesso diretto al filesystem, nessuna dipendenza pesante)
- **Separazione pulita**: Scripts NON inclusi nel container Docker

## 🔧 Script Disponibili

### 1. `init_auth.py` ✅ 
**Scopo**: Inizializza il database di autenticazione con utenti di esempio  
**Esecuzione**: `python scripts/init_auth.py` (dalla root del progetto)  
**Dipendenze**: Solo SQLite (built-in Python)  
**Uso**: Prima configurazione o reset completo del database

### 2. `cleanup_db.py` ✅
**Scopo**: Pulisce tutte le sessioni attive nel database  
**Esecuzione**: `python scripts/cleanup_db.py` (dalla root del progetto)  
**Dipendenze**: Solo SQLite (built-in Python)  
**Uso**: Reset veloce delle sessioni senza ricreare il database

### 3. `logout_all_users.py` ✅
**Scopo**: Logout di tutti gli utenti tramite SQLite diretto  
**Esecuzione**: `python scripts/logout_all_users.py` (dalla root del progetto)  
**Dipendenze**: Solo SQLite (built-in Python)  
**Uso**: Logout completo senza dipendenze Streamlit

### 4. `test_auth_system.py` ✅
**Scopo**: Test completo del sistema di autenticazione  
**Esecuzione**: `python scripts/test_auth_system.py` (dalla root del progetto)  
**Dipendenze**: Solo SQLite (built-in Python)  
**Uso**: Verifica che il sistema auth funzioni correttamente

### 5. `generate_domain_area_grid.py` ✅
**Scopo**: Genera griglia di aree di dominio per l'app  
**Esecuzione**: `python scripts/generate_domain_area_grid.py` (dalla root del progetto)  
**Dipendenze**: GeoPandas, Shapely (installa con `pip install -r requirements.txt`)  
**Uso**: Rigenerazione dati geospaziali

## 🗂️ Percorsi Database

**Percorso unificato**: `geoapps_storage/auth.db`  
**Accesso**: Diretto dal filesystem (scripts locali)

## 🐳 Streamlit con Docker

**Avvio applicazione**:
```bash
# Avvia container
docker-compose -f docker-compose-local.yml up

# Accedi a: http://localhost:8503
```

**Controllo logs**:
```bash
docker-compose -f docker-compose-local.yml logs streamlit
```

## 📋 Workflow Consigliato

### Setup Iniziale
```bash
# 1. Crea database con utenti di esempio
python scripts/init_auth.py

# 2. Avvia Streamlit in Docker
docker-compose -f docker-compose-local.yml up
```

### Durante Sviluppo
```bash
# Reset veloce sessioni (mentre Docker è attivo)
python scripts/cleanup_db.py

# Oppure logout completo
python scripts/logout_all_users.py

# Test sistema auth
python scripts/test_auth_system.py
```

### Debugging
```bash
# Verifica stato database
python scripts/test_auth_system.py

# Reset completo
python scripts/init_auth.py
```

## ⚡ Quick Reference

```bash
# Setup completo
python scripts/init_auth.py
docker-compose -f docker-compose-local.yml up

# Reset sessioni
python scripts/logout_all_users.py

# Cleanup veloce  
python scripts/cleanup_db.py
```

## 🏗️ Vantaggi di questa Architettura

✅ **Scripts leggeri**: Solo SQLite, nessuna dipendenza pesante  
✅ **Streamlit isolato**: Ambiente Docker controllato  
✅ **Filesystem diretto**: Scripts accedono direttamente ai dati  
✅ **Manutenzione semplice**: Un solo modo per ogni operazione  
✅ **Performance**: Scripts veloci senza overhead container